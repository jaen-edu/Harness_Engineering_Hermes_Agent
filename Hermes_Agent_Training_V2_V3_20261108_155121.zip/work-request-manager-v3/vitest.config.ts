import { defineConfig } from 'vitest/config';
import { resolve } from 'node:path';

export default defineConfig({
  resolve: {
    // 단위 테스트가 client/src 컴포넌트를 import할 때 루트와 client의 React 이중 인스턴스를 방지
    // client/src 컴포넌트는 변환되므로 alias가 적용되어 루트 React 인스턴스로 통일된다.
    // (react-dom/@testing-library는 externalized되어 루트 인스턴스를 그대로 사용 → 단일 인스턴스 보장)
    alias: [
      { find: /^react$/, replacement: resolve(__dirname, 'node_modules/react') },
      { find: /^react-dom(\/.*)?$/, replacement: resolve(__dirname, 'node_modules/react-dom') + '$1' },
      { find: /^react\/(.*)$/, replacement: resolve(__dirname, 'node_modules/react') + '/$1' },
    ],
  },
  test: {
    environment: 'node',
    include: ['tests/unit/**/*.test.ts', 'tests/unit/**/*.test.tsx', 'tests/integration/**/*.test.mjs'],
    globals: true,
  },
});
