import { useState } from 'react';
import { RequestList } from './features/requests/RequestList';
import { Dashboard } from './features/dashboard/Dashboard';

type Tab = 'requests' | 'dashboard';

export default function App() {
  const [tab, setTab] = useState<Tab>('requests');
  return (
    <div className="app">
      <header className="app-header">
        <h1>AI Work Request Manager</h1>
        <nav aria-label="탭">
          <button
            type="button"
            className={`tab${tab === 'requests' ? ' active' : ''}`}
            aria-current={tab === 'requests' ? 'page' : undefined}
            data-testid="tab-requests"
            onClick={() => setTab('requests')}
          >
            Requests
          </button>
          <button
            type="button"
            className={`tab${tab === 'dashboard' ? ' active' : ''}`}
            aria-current={tab === 'dashboard' ? 'page' : undefined}
            data-testid="tab-dashboard"
            onClick={() => setTab('dashboard')}
          >
            Dashboard
          </button>
        </nav>
      </header>
      <main className="app-main">
        {tab === 'requests' ? <RequestList /> : <Dashboard />}
      </main>
    </div>
  );
}
