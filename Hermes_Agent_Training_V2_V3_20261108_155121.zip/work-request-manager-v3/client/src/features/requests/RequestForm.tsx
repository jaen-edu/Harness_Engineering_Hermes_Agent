import { useState } from 'react';
import type { Request } from '../../api/client';
import { createRequest, errorMessage } from '../../api/client';

// UI08-04: 취소 클릭 시 등록 없이 폼을 닫는다.
// UI08-05: 유효한 입력 등록 성공 시 부모가 폼을 닫는다(onClose).
// UI08-06: 오류 발생 시 폼을 유지한다(닫지 않음).
export function RequestForm({ onCreated, onClose }: { onCreated: (r: Request) => void; onClose: () => void }) {
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const submit = async (e: React.FormEvent<HTMLFormElement>) => {
    e.preventDefault();
    const form = e.currentTarget;
    const fd = new FormData(form);
    setBusy(true);
    setError('');
    try {
      const created = await createRequest({
        title: String(fd.get('title') ?? '').trim(),
        requester: String(fd.get('requester') ?? '').trim(),
        description: String(fd.get('description') ?? '').trim(),
        assignee: String(fd.get('assignee') ?? '').trim(),
        priority: String(fd.get('priority') ?? 'medium'),
      });
      form.reset();
      onCreated(created);
      onClose();
    } catch (err) {
      // 실패 시 폼을 닫지 않고 오류를 표시한다
      setError(errorMessage(err));
    } finally {
      setBusy(false);
    }
  };

  return (
    <form className="request-form" data-testid="request-form" onSubmit={submit} aria-labelledby="new-request-heading">
      <h3 id="new-request-heading">새 요청 등록</h3>
      <label>
        제목
        <input name="title" required aria-label="제목" />
      </label>
      <label>
        요청자
        <input name="requester" required aria-label="요청자" />
      </label>
      <label>
        담당자
        <input name="assignee" aria-label="담당자" />
      </label>
      <label>
        우선순위
        <select name="priority" defaultValue="medium" aria-label="우선순위">
          <option value="low">낮음</option>
          <option value="medium">보통</option>
          <option value="high">높음</option>
        </select>
      </label>
      <label>
        설명
        <textarea name="description" required rows={2} aria-label="설명" />
      </label>
      {error && (
        <p className="error-text" role="alert" data-testid="form-error">
          {error}
        </p>
      )}
      <div className="form-actions">
        <button type="submit" className="btn btn-primary" disabled={busy} data-testid="submit-request">
          등록
        </button>
        <button type="button" className="btn" onClick={onClose} disabled={busy} data-testid="cancel-request">
          취소
        </button>
      </div>
    </form>
  );
}
