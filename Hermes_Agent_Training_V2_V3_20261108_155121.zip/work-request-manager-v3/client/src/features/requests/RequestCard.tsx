import { useState } from 'react';
import type { Request } from '../../api/client';
import { patchRequest, errorMessage } from '../../api/client';
import { PRIORITY_LABELS, STATUS_LABELS } from './RequestList';

export function RequestCard({ request, onChanged }: { request: Request; onChanged: (r: Request) => void }) {
  const [editing, setEditing] = useState(false);
  const [error, setError] = useState('');
  const [busy, setBusy] = useState(false);

  const applyPatch = async (patch: Partial<Request>) => {
    setBusy(true);
    setError('');
    try {
      onChanged(await patchRequest(request.id, patch));
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setBusy(false);
    }
  };

  const changeStatus = (status: string) => {
    void applyPatch({ status: status as Request['status'] });
  };

  return (
    <article className="request-card" data-testid="request-card" aria-label={`요청 ${request.id}`}>
      <div className="request-meta">
        <span className="badge badge-status">{STATUS_LABELS[request.status]}</span>
        <span className={`badge badge-priority-${request.priority}`}>우선순위: {PRIORITY_LABELS[request.priority]}</span>
      </div>
      <h3>{request.title}</h3>
      <p>{request.description}</p>
      <div className="request-meta">
        <span>요청자: {request.requester}</span>
        <span>담당자: {request.assignee || '미지정'}</span>
      </div>
      <div className="request-actions">
        <label>
          <span className="sr-only">상태 변경</span>
          <select
            aria-label={`상태 변경 ${request.id}`}
            value={request.status}
            onChange={(e) => changeStatus(e.target.value)}
            disabled={busy}
          >
            <option value="todo">할 일</option>
            <option value="in_progress">진행 중</option>
            <option value="done">완료</option>
          </select>
        </label>
        <button type="button" className="btn" aria-expanded={editing} onClick={() => setEditing((v) => !v)}>
          {editing ? '수정 취소' : '수정'}
        </button>
      </div>
      {error && (
        <p className="error-text" role="alert">
          {error}
        </p>
      )}
      {editing && (
        <form
          data-testid="edit-form"
          onSubmit={(e) => {
            e.preventDefault();
            const fd = new FormData(e.currentTarget);
            void applyPatch({
              title: String(fd.get('title') ?? '').trim(),
              priority: String(fd.get('priority') ?? '') as Request['priority'],
              assignee: String(fd.get('assignee') ?? '').trim(),
            });
            setEditing(false);
          }}
        >
          <label>
            제목
            <input name="title" defaultValue={request.title} required />
          </label>
          <label>
            담당자
            <input name="assignee" defaultValue={request.assignee} />
          </label>
          <label>
            우선순위
            <select name="priority" defaultValue={request.priority}>
              <option value="low">낮음</option>
              <option value="medium">보통</option>
              <option value="high">높음</option>
            </select>
          </label>
          <button type="submit" className="btn btn-primary" disabled={busy}>
            저장
          </button>
        </form>
      )}
    </article>
  );
}
