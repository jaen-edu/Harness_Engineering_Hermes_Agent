import { useEffect, useMemo, useState } from 'react';
import type { Request } from '../../api/client';
import { listRequests, errorMessage } from '../../api/client';
import { RequestForm } from './RequestForm';
import { RequestCard } from './RequestCard';

export const PRIORITY_LABELS: Record<string, string> = { low: '낮음', medium: '보통', high: '높음' };
export const STATUS_LABELS: Record<string, string> = { todo: '할 일', in_progress: '진행 중', done: '완료' };

const DEFAULT_ITEMS: Request[] = [
  { id: 'req-001', title: '로그인 오류 수정', description: '세션 만료 후 로그인이 실패하는 문제', requester: '김민준', assignee: '박서연', priority: 'high', status: 'todo', createdAt: '2025-01-01T09:00:00.000Z', updatedAt: '2025-01-01T09:00:00.000Z' },
  { id: 'req-002', title: '보고서 내보내기', description: 'CSV 내보내기 기능 추가', requester: '이도윤', assignee: '정하은', priority: 'medium', status: 'in_progress', createdAt: '2025-01-02T09:00:00.000Z', updatedAt: '2025-01-02T09:00:00.000Z' },
  { id: 'req-003', title: '사용자 가이드 작성', description: '신규 사용자용 온보딩 가이드', requester: '최지우', assignee: '김민준', priority: 'low', status: 'done', createdAt: '2025-01-03T09:00:00.000Z', updatedAt: '2025-01-03T09:00:00.000Z' },
];

const STATUS_ORDER: Record<string, string> = { todo: '0', in_progress: '1', done: '2' };

export function RequestList() {
  const [items, setItems] = useState<Request[]>(DEFAULT_ITEMS);
  const [q, setQ] = useState('');
  const [statusFilter, setStatusFilter] = useState('');
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(true);
  // UI08-01: 최초 진입 시 등록 폼은 숨김 상태다.
  const [formOpen, setFormOpen] = useState(false);

  const fetchAll = async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listRequests();
      setItems(data);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  };

  useEffect(() => {
    void fetchAll();
  }, []);

  const filtered = useMemo(() => {
    const needle = q.trim().toLowerCase();
    return items
      .filter((r) => (statusFilter ? r.status === statusFilter : true))
      .filter((r) => (needle ? `${r.title} ${r.description}`.toLowerCase().includes(needle) : true))
      .sort((a, b) => (STATUS_ORDER[a.status] ?? '9').localeCompare(STATUS_ORDER[b.status] ?? '9'));
  }, [items, q, statusFilter]);

  const replaceItem = (r: Request) => setItems((prev) => prev.map((x) => (x.id === r.id ? r : x)));

  const resetFilters = () => {
    setQ('');
    setStatusFilter('');
  };

  return (
    <section aria-label="Requests" className="request-list">
      <h2>Requests</h2>
      <div className="request-toolbar">
        <div className="filters">
          <label>
            <span className="sr-only">검색</span>
            <input
              type="search"
              placeholder="검색어를 입력하세요"
              aria-label="검색"
              value={q}
              onChange={(e) => setQ(e.target.value)}
            />
          </label>
          <label>
            <span className="sr-only">상태 필터</span>
            <select aria-label="상태 필터" value={statusFilter} onChange={(e) => setStatusFilter(e.target.value)}>
              <option value="">전체</option>
              <option value="todo">할 일</option>
              <option value="in_progress">진행 중</option>
              <option value="done">완료</option>
            </select>
          </label>
          <button type="button" className="btn" onClick={resetFilters}>
            필터 초기화
          </button>
        </div>
        {/* UI08-02: 검색·필터 영역 옆의 [새 요청] 버튼 */}
        <button
          type="button"
          className="btn btn-primary"
          data-testid="new-request-btn"
          aria-expanded={formOpen}
          aria-controls="new-request-panel"
          onClick={() => setFormOpen(true)}
        >
          새 요청
        </button>
      </div>
      {/* UI08-03: [새 요청] 클릭 시 빈 등록 폼이 같은 페이지에 표시된다 */}
      {formOpen && (
        <div id="new-request-panel">
          <RequestForm onCreated={(r) => setItems((prev) => [...prev, r])} onClose={() => setFormOpen(false)} />
        </div>
      )}
      {error && (
        <p className="error-text" role="alert">
          {error}
        </p>
      )}
      {loading ? (
        <p className="muted">로딩 중…</p>
      ) : filtered.length === 0 ? (
        <p className="muted">표시할 요청이 없습니다.</p>
      ) : (
        <div className="card-grid" data-testid="request-cards">
          {filtered.map((r) => (
            <RequestCard key={r.id} request={r} onChanged={replaceItem} />
          ))}
        </div>
      )}
    </section>
  );
}
