// StatsPanel.tsx — 상태 필터 + 활성 필터 표시
// 필터 변경 시 지표·건수 화면이 결정적으로 갱신되고 활성 필터가 명시적으로 표시된다.
import type { StatusFilter } from './stats';
import { STATUSES } from './stats';
import { STATUS_LABELS_IN } from './labels';

export function StatsPanel({
  statusFilter,
  onFilterChange,
}: {
  statusFilter: StatusFilter;
  onFilterChange: (s: StatusFilter) => void;
}) {
  const activeLabel =
    statusFilter === '' ? '전체' : STATUS_LABELS_IN[statusFilter as keyof typeof STATUS_LABELS_IN];
  return (
    <div className="dashboard-controls">
      <label>
        <span className="sr-only">상태 필터</span>
        <select
          aria-label="대시보드 상태 필터"
          data-testid="dashboard-status-filter"
          value={statusFilter}
          onChange={(e) => onFilterChange(e.target.value as StatusFilter)}
        >
          <option value="">전체</option>
          {STATUSES.map((s) => (
            <option key={s} value={s}>
              {STATUS_LABELS_IN[s]}
            </option>
          ))}
        </select>
      </label>
      <p className="active-filter" data-testid="active-filter" aria-live="polite">
        활성 필터: {activeLabel}
      </p>
    </div>
  );
}
