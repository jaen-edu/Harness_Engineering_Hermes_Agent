// useStats.ts — GET /api/requests 원본 데이터 → 지표 계산 훅
// 별도 저장소/별도 API를 두지 않고 Requests 탭과 같은 단일 데이터 원본을 사용한다.
import { useCallback, useEffect, useMemo, useState } from 'react';
import type { Request } from '../../api/client';
import { listRequests, errorMessage } from '../../api/client';
import {
  computeFilteredStats,
  EMPTY_STATS,
  type RequestStats,
  type StatusFilter,
} from './stats';

export function useStats() {
  const [items, setItems] = useState<Request[]>([]);
  const [statusFilter, setStatusFilter] = useState<StatusFilter>('');
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');

  const refresh = useCallback(async () => {
    setLoading(true);
    setError('');
    try {
      const data = await listRequests();
      setItems(data);
    } catch (e) {
      setError(errorMessage(e));
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => {
    void refresh();
  }, [refresh]);

  // 상태 필터 적용 시 필터된 요청 집합을 기준으로 지표·분포를 함께 계산
  const stats: RequestStats = useMemo(
    () => computeFilteredStats(items, statusFilter),
    [items, statusFilter],
  );

  return {
    items,
    stats: loading && items.length === 0 ? EMPTY_STATS : stats,
    statusFilter,
    setStatusFilter,
    loading,
    error,
    refresh,
  };
}
