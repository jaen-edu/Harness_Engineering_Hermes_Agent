// stats.ts — Dashboard 지표·분포 계산 순수 모듈 (단위 테스트 대상)
// Requests 탭과 동일한 API 데이터(GET /api/requests) 구조에 직접 의존한다.
import type { Request } from '../../api/client';

export type StatusKey = 'todo' | 'in_progress' | 'done';
export type PriorityKey = 'low' | 'medium' | 'high';
export type StatusFilter = '' | StatusKey;

export type RequestStats = {
  total: number;
  todo: number;
  in_progress: number;
  done: number;
  priority: Record<PriorityKey, number>;
};

export const STATUSES: StatusKey[] = ['todo', 'in_progress', 'done'];
export const PRIORITIES: PriorityKey[] = ['low', 'medium', 'high'];

export const EMPTY_STATS: RequestStats = {
  total: 0,
  todo: 0,
  in_progress: 0,
  done: 0,
  priority: { low: 0, medium: 0, high: 0 },
};

/** 상태 필터 적용: '' 이면 전체, 아니면 해당 상태의 요청만 남긴다. */
export function filterByStatus(items: Request[], status: StatusFilter): Request[] {
  if (!status) return items;
  return items.filter((r) => r.status === status);
}

/**
 * 요청 배열 → 지표·분포 계산.
 * - 빈 배열은 안전하게 모두 0 (0 나눗셈 없음)
 * - 불변 조건: low + medium + high === total
 */
export function computeStats(items: Request[]): RequestStats {
  const stats: RequestStats = {
    total: 0,
    todo: 0,
    in_progress: 0,
    done: 0,
    priority: { low: 0, medium: 0, high: 0 },
  };
  for (const r of items) {
    stats.total += 1;
    if ((STATUSES as string[]).includes(r.status)) {
      stats[r.status as StatusKey] += 1;
    }
    if ((PRIORITIES as string[]).includes(r.priority)) {
      stats.priority[r.priority as PriorityKey] += 1;
    }
  }
  return stats;
}

/** 필터된 집합 기준 지표 계산 (필터 → 통계 한 번에) */
export function computeFilteredStats(items: Request[], status: StatusFilter): RequestStats {
  return computeStats(filterByStatus(items, status));
}

/** 불변 조건 검사: 우선순위 합계 == 전체 건수 */
export function prioritySumMatchesTotal(stats: RequestStats): boolean {
  return stats.priority.low + stats.priority.medium + stats.priority.high === stats.total;
}
