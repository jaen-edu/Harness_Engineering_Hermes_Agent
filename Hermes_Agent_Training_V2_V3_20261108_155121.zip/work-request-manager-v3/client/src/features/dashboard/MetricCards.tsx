// MetricCards.tsx — 전체/할 일/진행 중/완료 지표 카드
import type { RequestStats } from './stats';
import { STATUS_LABELS_IN } from './labels';

export function MetricCards({ stats }: { stats: RequestStats }) {
  const cards = [
    { key: 'total', label: '전체', value: stats.total },
    { key: 'todo', label: STATUS_LABELS_IN.todo, value: stats.todo },
    { key: 'in_progress', label: STATUS_LABELS_IN.in_progress, value: stats.in_progress },
    { key: 'done', label: STATUS_LABELS_IN.done, value: stats.done },
  ];
  return (
    <div className="metric-grid" data-testid="metric-cards">
      {cards.map((c) => (
        <div
          key={c.key}
          className="metric-card"
          data-testid={`stat-${c.key}`}
          aria-label={`${c.label} ${c.value}건`}
        >
          <span className="metric-label">{c.label}</span>
          <span className="metric-value" data-testid={`stat-${c.key}-value`}>
            {c.value}
          </span>
        </div>
      ))}
    </div>
  );
}
