// PriorityDistribution.tsx — 우선순위(low/medium/high) 분포 카드
// 불변 조건: low + medium + high === total (합계=전체 일치 표시)
import type { RequestStats } from './stats';
import { PRIORITIES } from './stats';
import { PRIORITY_LABELS_IN } from './labels';

export function PriorityDistribution({ stats }: { stats: RequestStats }) {
  const sum = PRIORITIES.reduce((acc, p) => acc + stats.priority[p], 0);
  return (
    <div
      className="priority-distribution"
      data-testid="priority-distribution"
      aria-label={`우선순위 분포: 합계 ${sum}건 / 전체 ${stats.total}건`}
    >
      {PRIORITIES.map((p) => (
        <div key={p} className="metric-card" data-testid={`priority-${p}`}>
          <span className="metric-label">{PRIORITY_LABELS_IN[p]}</span>
          <span className="metric-value" data-testid={`priority-${p}-value`}>
            {stats.priority[p]}
          </span>
        </div>
      ))}
      <p className="muted" data-testid="priority-sum">
        합계 {sum} / 전체 {stats.total}
      </p>
    </div>
  );
}
