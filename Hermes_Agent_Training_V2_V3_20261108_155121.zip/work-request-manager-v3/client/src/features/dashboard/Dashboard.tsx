// Dashboard.tsx — Dashboard 탭 컨테이너 (지표 카드 + 분포 + 필터)
import { useStats } from './useStats';
import { MetricCards } from './MetricCards';
import { PriorityDistribution } from './PriorityDistribution';
import { StatsPanel } from './StatsPanel';

export function Dashboard() {
  const { stats, statusFilter, setStatusFilter, loading, error, refresh } = useStats();

  return (
    <section aria-label="Dashboard" className="dashboard">
      <h2>Dashboard</h2>
      <StatsPanel statusFilter={statusFilter} onFilterChange={setStatusFilter} />
      {error && (
        <p className="error-text" role="alert">
          {error}
        </p>
      )}
      {loading ? (
        <p className="muted">로딩 중…</p>
      ) : (
        <>
          <MetricCards stats={stats} />
          <PriorityDistribution stats={stats} />
          {stats.total === 0 && (
            <p className="empty-state" data-testid="empty-state" role="status">
              등록된 요청이 없습니다 — Requests 탭에서 첫 요청을 등록하세요
            </p>
          )}
        </>
      )}
      <button type="button" className="btn" onClick={() => void refresh()} data-testid="dashboard-refresh">
        새로고침
      </button>
    </section>
  );
}
