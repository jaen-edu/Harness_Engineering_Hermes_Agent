// labels.ts — Dashboard 표시 라벨 (Requests 탭 라벨과 동일한 한국어 표기)
export const STATUS_LABELS_IN = {
  todo: '할 일',
  in_progress: '진행 중',
  done: '완료',
} as const;

export const PRIORITY_LABELS_IN = {
  low: '낮음',
  medium: '보통',
  high: '높음',
} as const;
