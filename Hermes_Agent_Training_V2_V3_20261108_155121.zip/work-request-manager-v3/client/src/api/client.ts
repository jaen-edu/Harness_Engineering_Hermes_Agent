export type Request = {
  id: string;
  title: string;
  description: string;
  requester: string;
  assignee: string;
  priority: 'low' | 'medium' | 'high';
  status: 'todo' | 'in_progress' | 'done';
  createdAt: string;
  updatedAt: string;
};

export type ApiError = { code: string; field?: string; message?: string; errors?: ApiError[] };

async function handle(res: Response) {
  const text = await res.text();
  let data: unknown = null;
  if (text) {
    try {
      data = JSON.parse(text);
    } catch {
      data = null;
    }
  }
  if (!res.ok) {
    const err = (data as { error?: ApiError } | null)?.error;
    throw new ApiErrorImpl(
      err?.code ?? 'UNKNOWN_ERROR',
      err?.message ?? `요청이 실패했습니다 (HTTP ${res.status})`,
      err?.errors,
    );
  }
  return data as { items: Request[] } | Request;
}

export class ApiErrorImpl extends Error {
  code: string;
  field?: string;
  errors?: ApiError[];
  constructor(code: string, message: string, errors?: ApiError[]) {
    super(message);
    this.code = code;
    this.errors = errors;
  }
}

export async function listRequests(params: { q?: string; status?: string } = {}): Promise<Request[]> {
  const qs = new URLSearchParams();
  if (params.q) qs.set('q', params.q);
  if (params.status) qs.set('status', params.status);
  const data = await handle(await fetch(`/api/requests${qs.toString() ? `?${qs}` : ''}`));
  return (data as { items: Request[] }).items;
}

export async function createRequest(input: {
  title: string;
  description: string;
  requester: string;
  assignee?: string;
  priority?: string;
}): Promise<Request> {
  return (await handle(await fetch('/api/requests', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  }))) as Request;
}

export async function patchRequest(id: string, patch: Partial<Request>): Promise<Request> {
  return (await handle(await fetch(`/api/requests/${id}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(patch),
  }))) as Request;
}

export const ERROR_MESSAGES: Record<string, string> = {
  VALIDATION_REQUIRED_FIELD: '필수 입력값이 비어 있습니다. 모든 항목을 입력하세요.',
  VALIDATION_INVALID_PRIORITY: '우선순위 값이 올바르지 않습니다.',
  VALIDATION_INVALID_STATUS: '상태 값이 올바르지 않습니다.',
  VALIDATION_INVALID_JSON: '요청 형식이 올바르지 않습니다.',
  NOT_FOUND: '존재하지 않는 요청입니다.',
  VALIDATION_EMPTY_PATCH: '수정할 내용을 지정하세요.',
  UNKNOWN_ERROR: '알 수 없는 오류가 발생했습니다.',
};

export function errorMessage(e: unknown): string {
  if (e instanceof ApiErrorImpl) {
    return ERROR_MESSAGES[e.code] ?? e.message;
  }
  return '네트워크 오류가 발생했습니다. 서버 상태를 확인하세요.';
}
