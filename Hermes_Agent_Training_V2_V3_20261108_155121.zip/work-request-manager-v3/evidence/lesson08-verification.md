# 제8교시 검증 증거 — Requests 탭 (lesson08-verification.md)

작업: AI Work Request Manager v3 Requests 탭 구현 + 재사용 가능한 자율형 검증 Harness 실행
작업공간: `/workspace` 한정 (v2 / Reference Project 미변경)
실행 명령: `bash scripts/verify-requests.sh` (한 번의 호출로 S1~S8 전체 수행)

## 1. 최종 결과 요약

| 항목 | 결과 |
| --- | --- |
| 빌드 (S1) | PASS (tsc --noEmit + vite build) |
| 단위 테스트 (S2) | PASS — `tests/unit/validate.test.ts`, `tests/unit/store.test.ts` (7 tests) |
| 통합 테스트 (S3) | PASS — `tests/integration/api.test.mjs` (5 tests, 임시 데이터 파일 + 포트 3002) |
| 앱 서버 안전 종료 (S4) | PASS — /workspace 소속 프로세스만 종료, 종료 확인 후 복원 |
| 시드 복원·재시작 (S5) | PASS — `data/fixtures/requests.seed.json` → `server/data/requests.json` |
| E2E requests (S6) | PASS — Playwright Runner `POST http://playwright:3000/run` `{"test":"requests"}`, `status=PASS`, `exitCode=0` |
| 사후 복원·재시작 (S7) | PASS |
| 최종 검증 (S8) | PASS — 초기 요청 3건 + 서버 정상 실행 |

- 첫 안정 PASS 실행: RUN_ID `20261108-063234`, `OVERALL: PASS`, exit=0
- 추가 수정 없이 2회 연속 재실행: RUN_ID `20261108-063341`, `20261108-063359` — 둘 다 `OVERALL: PASS`, exit=0
- 스크립트 무수정 확인: sha256 `8f98f403f34176276fbc8f2a02e6327951385f73628266c1c55deaace6f7e5dc` (재실행 전후 동일, `evidence/lesson08-script-hash-before-repeat.txt`)
- 실행 로그 보존: `/workspace/evidence/logs/lesson08-<RUN_ID>/` (s1-build.log, s2-unit.log, s3-integration.log, s6-e2e.json)
- 테스트 종료 후 상태: API `GET /api/requests` = 3건(REQ-001~003), UI `http://hermes:5174` = 200, UI 프록시 `/api` = 200

## 2. E2E 상세 (tests/e2e/requests.spec.cjs → Playwright Runner)

브라우저 대상: `http://hermes:5174` (호스트명 사용, 고정 컨테이너 IP 미사용)

```
PASS: AC08-01 초기 요청 3건 카드 표시 (실제 3)
PASS: AC08-02 등록 후 카드 4건
PASS: AC08-02 새 카드 표시
PASS: AC08-03 제목 수정 반영
PASS: AC08-04 상태 변경 (완료 배지)
PASS: AC08-02 검색 "설문" -> 1건
PASS: AC08-02 상태 필터 done -> 2건
PASS: AC08-02 필터 초기화 -> 4건
PASS: AC08-05 키보드 Tab 포커스 이동
PASS: AC08-06 서버 검증 오류 메시지 표시   (공백 제목 → 서버 400 VALIDATION_REQUIRED_FIELD → [role=alert] 표시)
E2E PASS: all assertions
```

## 3. 실패 원인과 수정 내역 (자율 오류 복구 기록)

| # | 증상 (로그) | 원인 | 최소 수정 | 재검증 |
| --- | --- | --- | --- | --- |
| 1 | S1 TS2322: `Type 'string' is not assignable to '"low"\|"medium"\|"high"'` (RequestCard.tsx:70) | 폼 FormData 문자열을 유니언 타입에 직접 할당 | `as Request['priority']` 캐스팅 (셀렉트 값은 서버에서 재검증됨) | S1 PASS |
| 2 | S2/S3 `No test files found` | vitest 설정 부재 | 루트 `vitest.config.ts` 생성 (include: unit/integration) | S2/S3 실행됨 |
| 3 | S2 `validatePatch({})`가 오류를 반환하지 않음 | 빈 patch 검증이 서버 라우트에만 존재 | `validate.js`에 `VALIDATION_EMPTY_PATCH` 추가 | S2 PASS |
| 4 | S3 `server start timeout` | 테스트 env의 `VITEST=1`이 서버 listen을 억제 | 통합 테스트 spawn env에서 `VITEST` 제거 | S3 PASS |
| 5 | S3 `?status=done` 기대 1건 vs 실제 2건 | 시드 REQ-003이 이미 done | 기대값 2건으로 수정 (시드 반영) | S3 PASS |
| 6 | E2E `waitForSelector('[data-testid="request-card"]')` 15s timeout | Vite `allowedHosts`가 `hermes` 호스트를 403으로 차단 (응답 로그로 확인) | `vite.config.ts`에 `allowedHosts: ['hermes']` 추가 후 재시작 | E2E 카드 렌더링 확인 |
| 7 | E2E `locator.filter({ hasText: '로그인 오류 수정' })` timeout | E2E가 실제 시드 제목(교육실 장비 점검)과 불일치 | 시드 실제 제목/검색어('설문')로 수정 | E2E 통과 |
| 8 | E2E `selectOption` timeout | 제목 수정 후 카드가 변경된 제목으로 재렌더링되어 구 제목 셀렉터가 무효 | 상태 변경 단계에서 새 제목 셀렉터 사용 | E2E 통과 |
| 9 | E2E `waitForFunction` timeout, 필터 초기화 후에도 'done' 유지 | `page.click(sel, {hasText})`는 hasText 옵션을 무시 → 첫 번째 버튼(탭) 클릭됨 | `page.locator('button', { hasText: '필터 초기화' }).click()`로 수정 | E2E 통과 |
| 10 | E2E `[data-testid="form-error"]` 미표시 | select에 없는 value 대입은 FormData에 미반영 → 서버에 유효값 전송됨 | 공백만 입력한 제목(HTML5 required 통과, 서버 trim 검증 실패)으로 서버 400 유도 | E2E PASS |
| 11 | Harness가 안전 종료를 수행하지 못함 (EADDRINUSE 재시작 실패) | (a) `ss` 미설치로 포트→PID 탐색 불가, (b) `node src/index.js` 상대 경로 cmdline에 소속 판별 실패 | `/proc` cmdline+cwd 기반 소속 판별로 교체, 절대 경로 기동, SIGKILL은 우리 프로세스 한함 | S4/S7 PASS |
| 12 | S6이 E2E PASS를 FAIL로 판정 | Runner 응답 `status":"PASS"`를 `"status":"OK"`로 검사 | 판정 문자열을 `PASS`로 수정 | S6 PASS |
| 13 | S2가 타 세션에서 생성된 제9교시 dashboard 테스트로 실패 | `tests/unit/dashboard.test.tsx`, `stats.test.ts`가 실행 중 투입됨 (이중 React 로드 오류) | S2를 제8교시 테스트 파일로 한정 (Dashboard는 구현/수정하지 않음) | S2 PASS |

## 4. AC08-01 ~ AC08-06 최종 판정

| AC | 내용 | 근거 | 판정 |
| --- | --- | --- | --- |
| AC08-01 | 초기 요청 데이터 카드 표시 | E2E "초기 요청 3건 카드 표시 (실제 3)", S8 API 3건 | PASS |
| AC08-02 | 등록·수정·필터·상태 변경 동작 | E2E 등록→4카드, 제목 수정 반영, 검색/상태 필터/초기화, 상태 변경 배지, 통합 테스트 CRUD | PASS |
| AC08-03 | 잘못된 입력 무충돌 처리 + 오류 표시 | E2E 서버 400 → `[role=alert]` 오류 표시, 통합 테스트 기계 판독 코드 검증 | PASS |
| AC08-04 | 저장 데이터 재시작 후 유지 | 파일 기반 저장소(원자적 쓰기), 통합 테스트, S5/S7 복원·재시작 후 S8 3건 확인 | PASS |
| AC08-05 | 모바일·데스크톱 레이아웃 + 키보드 접근성 | 반응형 카드 그리드(≤640px 1열), Tab 포커스 순회 E2E PASS, 모든 입력에 레이블/aria-label | PASS |
| AC08-06 | 빌드·단위·통합·E2E 모두 PASS | S1~S6 전부 PASS, 3회 연속 OVERALL PASS(1회 안정화 + 2회 반복) | PASS |

## 5. 비고

- Dashboard 지표 기능은 요구에 따라 구현하지 않았으며, 제9교시는 `progress.md`에서 `NOT_IMPLEMENTED`로 유지한다.
- 실행 중 타 세션에서 생성된 `tests/unit/dashboard.test.tsx`, `tests/unit/stats.test.ts`는 제8교시 범위 밖이라 S2 대상에서 제외했고 파일을 수정/삭제하지 않았다.
- Playwright Runner는 테스트 실행만 담당하며, 코드 수정·재시험 반복은 본 에이전트가 수행했다 (역할 분리 준수).
