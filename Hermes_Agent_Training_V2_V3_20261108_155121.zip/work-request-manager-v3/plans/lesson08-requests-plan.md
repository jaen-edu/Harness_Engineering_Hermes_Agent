# 제8교시 구현 계획 — Requests 탭 (lesson08-requests-plan.md)

> 상태: **계획 문서 (제7교시 산출물)**. 본 문서는 구현 계획이며 아직 코드는 존재하지 않습니다.
> 모든 미작성 테스트·기능은 `NOT_IMPLEMENTED`로 기록하고, 실제 실행 로그로 확인된 결과만 PASS로 표시합니다.

## 0. 범위와 제약

- 작업 범위: `/workspace` 한정. v2 및 Reference Project는 읽기·쓰기·심볼릭 링크 모두 금지 (AGENTS.md).
- 프런트엔드 프로젝트 루트: `client/` (React + TypeScript + Vite). 프런트엔드 소스는 `client/src/`에만 배치.
- **프로젝트 루트(`/workspace/src/`)에 별도 `src/`를 계획·생성하지 않음.**
- 백엔드 API 및 영속 저장소: `server/`. 테스트: `tests/unit/`, `tests/integration/`, `tests/e2e/`. 증거: `evidence/` 및 `progress.md`.
- UI 디자인 토큰은 `docs/ui-guidelines.md` 준수 (기본색 `#2563EB`, 배경 `#F8FAFC`, 카드 `#FFFFFF`, 본문 `#0F172A`, 보조 `#64748B`, 테두리 `#E2E8F0`, 반경 12px, 간격 4/8/12/16/24/32px, 포커스 표시 ≥2px).
- 인수 기준 AC08-01~AC08-06은 `specs/acceptance-criteria.md`에 고정된 그대로 사용하며 임의로 약화하지 않음.

## 1. 역할 분리 (필수 명시)

- **Hermes Agent**: 애플리케이션 코드 작성·수정, 단위/통합 테스트 작성·실행, 빌드, 실패 원인 분석, 수정, 동일 테스트 재실행, 증거 기록을 전담한다.
- **Playwright Runner**(`http://playwright:3000`, Docker 내부): **테스트 실행만 담당한다.** `POST /run`에 `{"test":"requests"}`를 요청하면 `tests/e2e/requests.spec.cjs`를 실행하고 결과(종료 코드, 출력)를 반환한다. Playwright가 애플리케이션 코드를 수정하거나 재시험 반복을 주도하지 않는다.

## 2. 예정 파일 경로 (제8교시에 실제 생성할 파일)

| 경로 | 용도 |
| --- | --- |
| `client/package.json`, `client/index.html`, `client/vite.config.ts`, `client/tsconfig.json` | 프런트엔드 프로젝트 루트 설정 (루트 `src/` 없음) |
| `client/src/main.tsx`, `client/src/App.tsx` | 진입점, 탭 셸(`Requests | Dashboard`) |
| `client/src/api/client.ts` | REST 클라이언트(서버 API 래퍼) |
| `client/src/features/requests/RequestList.tsx`, `RequestCard.tsx`, `RequestForm.tsx`, `RequestFilter.tsx` | Requests 탭 UI (카드 그리드, 등록 폼, 검색·상태 필터) |
| `client/src/styles/tokens.css` | 디자인 토큰 변수 |
| `server/package.json`, `server/src/index.ts` (또는 `.js`) | Node.js 백엔드 API 엔트리 |
| `server/src/routes/requests.ts` | `GET/POST/PATCH /api/requests` 라우팅 + 서버 측 검증 |
| `server/src/store/store.ts`, `server/src/store/file-store.ts` | 영속 저장소(JSON 파일 기반; 메모리 전용은 영속성으로 주장하지 않음) |
| `server/src/validate.ts` | 필드 검증 + 기계 판독 가능 오류 코드 |
| `server/data/requests.json` | 초기 데이터 및 영속 파일 (재시작 후 유지 검증 대상) |
| `tests/unit/validate.test.ts`, `tests/unit/store.test.ts` | 검증 로직/저장소 단위 테스트 |
| `tests/unit/requestList.test.tsx` | 카드 렌더링·필터 단위 테스트 (React Testing Library) |
| `tests/integration/api-requests.test.ts` | API 통합 테스트 (등록/수정/상태 변경/검증 오류/영속성) |
| `tests/e2e/requests.spec.cjs` | Playwright E2E (Runner 계약 준수, 실패 시 0 아닌 종료 코드) |
| `evidence/lesson08-*.md` | 실행 명령, PASS/FAIL 출력, 변경 파일, 남은 문제 기록 |

## 3. 구현 순서

1. **서버 골격**: `server/`에 Node.js API 생성. 라우트: `GET /api/requests`(목록+필터 파라미터), `POST /api/requests`(등록), `PATCH /api/requests/:id`(제목·우선순위·담당자 수정 및 상태 변경), `GET /health`.
2. **영속 저장소**: JSON 파일 기반 저장소(`server/data/requests.json`). 메모리 캐시 + 파일 쓰기(원자적 쓰기: 임시 파일 → rename). 메모리 상태만으로 영속성을 주장하지 않음.
3. **초기 데이터**: 저장소 첫 기동 시 시드 데이터(id 포함, `todo/in_progress/done`, `low/medium/high` 다양성 확보) 기록. 이후 기동 시 기존 파일 우선.
4. **서버 측 검증**: `title`, `requester`, `description` 공백 제거 후 비어 있으면 안 됨 → `400` + 기계 판독 코드(`VALIDATION_REQUIRED_FIELD`, `VALIDATION_INVALID_PRIORITY`, `VALIDATION_INVALID_STATUS`, `NOT_FOUND` 등). 실패를 숨기지 않음.
5. **클라이언트 골격**: `client/` Vite + React + TS 설정. `App.tsx` 탭 셸, 토큰 CSS.
6. **Requests 탭 UI**: 초기 데이터 카드 렌더링(제목·담당자·우선순위·상태), 등록 폼(오류를 UI에 표시), 검색어+상태 필터+초기화 버튼, 인라인 수정(제목·우선순위·담당자) 및 상태 변경. 변경 결과는 새로고침 없이 즉시 반영(서버 응답 후 낙관적 아님: 응답 기반 갱신).
7. **반응형/접근성**: 데스크톱 2~3열 그리드, 모바일(≤640px) 1열, 가로 스크롤 방지, 모든 입력에 레이블, 키보드 포커스 표시(≥2px), 색상만으로 의미 전달 금지.
8. **단위 테스트 작성·실행** → **통합 테스트 작성·실행** → **E2E 파일 작성 후 Playwright Runner로 `requests` 실행** → 빌드 확인.
9. **수정·재검증 반복**(아래 §6 정책) → `evidence/` 기록 → `progress.md` 갱신.

## 4. 초기 데이터와 서버 측 검증·영속성 처리 (상세)

### 초기 데이터
- 시드 데이터는 `server/src/seed.ts`에서 정의하고 첫 기동 시 `server/data/requests.json`에 기록. 예: 6건 (상태 3종 × 최소 2건, 우선순위 3종 모두 포함). `id`는 안정적인 형식(예: `req-001`…)으로 고정.
- 앱 최초 로드 시 `GET /api/requests`로 초기 데이터를 받아 카드로 표시 (AC08-01).

### 서버 측 검증 (필수 — 클라이언트 검증만으로 대체 불가)
- `POST /api/requests`: 필수 3필드(`title`, `requester`, `description`) trim 후 비어 있으면 `400 {"error":{"code":"VALIDATION_REQUIRED_FIELD","field":"<필드명>"}}`.
- `priority`는 `low|medium|high` 외 값이면 `400 {"error":{"code":"VALIDATION_INVALID_PRIORITY"}}` (생략 시 서버 기본값 `medium`).
- `PATCH`: `status`는 `todo|in_progress|done` 외 값이면 `400 {"code":"VALIDATION_INVALID_STATUS"}`; 존재하지 않는 id면 `404 {"code":"NOT_FOUND"}`.
- 클라이언트는 오류 응답의 코드를 받아 폼 하단/카드 내에 사용자 언어 오류 메시지로 표시 (AC08-03).

### 영속성 (AC08-04)
- 모든 쓰기(POST/PATCH)는 즉시 파일 저장. 서버 재시작 → `GET /api/requests`로 변경 내용 유지 확인.
- 통합 테스트가 임시 데이터 파일로 재시작 시나리오(저장 → 새 스토어 인스턴스 → 재로드)를 검증.

## 5. AC08-01~AC08-06 검증 방법

| AC | 내용 | 단위 | 통합 | E2E (`tests/e2e/requests.spec.cjs`) |
| --- | --- | --- | --- | --- |
| AC08-01 | 초기 요청 데이터 카드 표시 | `tests/unit/requestList.test.tsx`: 시드 데이터 렌더링 시 카드 개수·제목·담당자·우선순위·상태 확인 | `tests/integration/api-requests.test.ts`: `GET /api/requests`가 시드 6건 반환 | 초기 로드 후 카드 개수 및 첫 카드 텍스트 어설션 |
| AC08-02 | 등록·수정·필터·상태 변경 동작 | `tests/unit/validate.test.ts`(유효 입력 통과), `requestList.test.tsx`(필터 로직) | POST→PATCH(제목·우선순위·담당자·status)→GET으로 변경 확인, 필터 파라미터 동작 | 폼으로 요청 등록 → 카드 즉시 표시, 인라인 수정·상태 변경 후 새로고침 없이 UI 반영, 검색어/상태 필터 적용 및 초기화 |
| AC08-03 | 잘못된 입력 무충돌 처리 + 오류 표시 | `validate.test.ts`: 빈 title/requester/description, 잘못된 priority/status → 오류 코드 매칭 | POST 빈 title → 400 + `VALIDATION_REQUIRED_FIELD` | 빈 값 제출 → UI 오류 메시지 표시 및 크래시 없음 확인 |
| AC08-04 | 재시작 후 저장 유지 | `tests/unit/store.test.ts`: 파일 쓰기→새 인스턴스 로드 일치 | 임시 파일 스토어로 쓰기→재생성→동일 데이터 | (통합으로 대체 검증; E2E는 서버 재시작이 Runner 계약 밖이므로 통합 테스트에서 증빙하고 결과를 evidence에 기록) |
| AC08-05 | 모바일·데스크톱 레이아웃 + 키보드 접근성 | `requestList.test.tsx`: 레이블 존재, 포커스 가능 요소 확인 | — | Playwright 뷰포트 375px(1열)/1280px(2~3열) 스크린샷, Tab 순회 및 포커스 스타일 확인, 가로 스크롤 없음 확인 |
| AC08-06 | 빌드 + 단위·통합 + E2E 모두 PASS | `npm test (unit)` 실행 로그 | `npm run test:integration` 실행 로그 | Playwright `POST /run {"test":"requests"}` → `status=PASS`, `exitCode=0` 확인. 모든 출력은 `evidence/`에 원문 기록 |

E2E 실행 결과는 Playwright Runner의 실제 응답(종료 코드·출력)으로만 판정하며, 로그로 확인하지 않은 테스트는 PASS로 표시하지 않는다. 아직 작성 전인 테스트는 `NOT_IMPLEMENTED`로 기록한다.

## 6. 실패 시 수정·재검증 정책 (역할 분리 포함)

- **책임**: Hermes가 코드 수정과 재시험 반복을 담당한다. Playwright는 테스트 실행만 담당한다.
- **반복 절차**: (1) 실패 로그 분석 → (2) 최소 수정(범위 최소화, 명세 위반 수정 금지) → (3) 동일 테스트 재실행 → (4) 결과를 `evidence/`에 기록.
- **재시도 상한**: 문제당 최대 **3회**. 3회 내 미해결 시 반복을 중단하고 `evidence/`에 실패 로그 원문·시도 내역과 함께 차단 요인을 보고한다.
- 인수 기준 약화(테스트 생략, 어설션 삭제, 기준 명세 수정)로 통과시키지 않는다.
- 미실행 테스트는 결과 표에 `NOT_IMPLEMENTED`로 명시한다.
