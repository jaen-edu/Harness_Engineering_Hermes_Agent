# 제9교시 구현 계획 — Dashboard 탭 (lesson09-dashboard-plan.md)

> 상태: **계획 문서 (제7교시 산출물)**. 본 문서는 구현 계획이며 아직 코드는 존재하지 않습니다.
> 모든 미작성 테스트·기능은 `NOT_IMPLEMENTED`로 기록하고, 실제 실행 로그로 확인된 결과만 PASS로 표시합니다.

## 0. 범위와 제약

- 작업 범위: `/workspace` 한정. v2 및 Reference Project는 읽기·쓰기·심볼릭 링크 모두 금지 (AGENTS.md).
- 프런트엔드 루트 `client/`, 소스 `client/src/`, 백엔드 `server/`, 테스트 `tests/unit|integration|e2e/`, 증거 `evidence/` — 제8교시 계획과 동일한 구조. **프로젝트 루트 별도 `src/` 없음.**
- 제8교시에서 완성된 `server/` API와 Requests 탭 위에 Dashboard 탭만 추가한다. 서버 라우트 재설계는 최소화하고 데이터 소스를 공유한다.
- UI 토큰·반응형·접근성 지침은 `docs/ui-guidelines.md` 그대로 재사용 (Requests 탭과 동일한 디자인 토큰).
- AC09-01~AC09-06은 `specs/acceptance-criteria.md` 고정 기준 사용, 약화 금지.

## 1. 역할 분리 (필수 명시)

- **Hermes Agent**: 코드 작성·수정, 단위/통합 테스트 작성·실행, 빌드, 실패 원인 분석, 최소 수정, 동일 테스트 재실행, 증거 기록을 전담한다.
- **Playwright Runner**(`http://playwright:3000`): **테스트 실행만 담당한다.** `POST /run`에 `{"test":"dashboard"}`를 요청하면 `tests/e2e/dashboard.spec.cjs`를 실행하고 실제 종료 코드·출력을 반환한다. 애플리케이션 코드 수정이나 재시험 반복은 하지 않는다.

## 2. 예정 파일 경로 (제9교시에 실제 생성/추가할 파일)

| 경로 | 용도 |
| --- | --- |
| `client/src/features/dashboard/Dashboard.tsx` | Dashboard 탭 컨테이너 (지표 카드 + 분포 + 필터) |
| `client/src/features/dashboard/MetricCards.tsx` | 전체/할 일/진행 중/완료 지표 카드 |
| `client/src/features/dashboard/PriorityDistribution.tsx` | 우선순위(low/medium/high) 분포 카드 |
| `client/src/features/dashboard/StatsPanel.tsx` | 상태 필터 + 요약/활성 필터 표시 |
| `client/src/features/dashboard/useStats.ts` | 요청 데이터 → 지표 계산 훅(순수 함수로 분리) |
| `client/src/features/dashboard/stats.ts` | 지표·분포 계산 순수 모듈 (단위 테스트 대상, 0 나눗셈 없음) |
| `client/src/features/requests/*` | 제8교시에서 생성; 재사용(수정은 최소) |
| `client/src/styles/tokens.css` | 제8교시 토큰 재사용 |
| `server/src/routes/requests.ts` | 기존 API 재사용 (필요 시 `GET /api/requests/stats` 최소 추가 여부는 구현 시 결정; 없으면 클라이언트가 `GET /api/requests` 원본 데이터로 직접 계산) |
| `tests/unit/stats.test.ts` | 지표·분포 계산 단위 테스트 |
| `tests/unit/dashboard.test.tsx` | Dashboard 렌더링·필터 갱신 단위 테스트 |
| `tests/integration/api-requests.test.ts` | 제8교시 테스트 확장: 변경 후 통계 원본 일치 재검증 |
| `tests/e2e/dashboard.spec.cjs` | Playwright E2E (Runner 계약, 실패 시 0 아닌 종료 코드) |
| `evidence/lesson09-*.md` | 실행 명령, PASS/FAIL, 변경 파일, 남은 문제 기록 |

## 3. Requests와 공유하는 데이터 소스

- **단일 원본**: `server/data/requests.json`(제8교시 영속 저장소) — Dashboard는 별도 저장소/별도 API 데이터를 두지 않는다.
- Dashboard는 `GET /api/requests`로 받은 **동일한 요청 데이터**에서 지표를 계산한다 (`specs/dashboard.md`: "모든 건수는 Requests 탭과 동일한 요청 데이터에서 계산").
- 계산 로직은 `client/src/features/dashboard/stats.ts`의 순수 함수로 분리해 Requests 데이터 구조(`id, title, ..., priority, status, createdAt, updatedAt`)에 직접 의존한다.
- 요청 추가·수정 이후 탭 이동/새로고침 시 Dashboard가 최신 `GET /api/requests`를 다시 가져와 재계산한다 (AC09-04). 같은 세션 내 탭 전환은 공유 상태/재페치로 반영을 보장한다.

## 4. 구현 순서

1. **지표 계산 모듈(순수 함수)**: `stats.ts` — `total`, `todo`, `in_progress`, `done` 건수와 `low/medium/high` 분포 계산. 빈 배열에 대한 안전 처리(합계 0, 분모 0 방지 — 비율 표시 시 0으로 나누지 않음).
2. **지표 카드 UI**: 전체/할 일/진행 중/완료 4개 카드. 동일 토큰·반경·간격 사용.
3. **우선순위 분포 카드**: low/medium/high 건수 + (합계=전체) 일치 표시.
4. **상태 필터**: 상태 필터 변경 시 지표·건수 화면이 결정적으로 갱신되고 활성 필터가 명시적으로 표시됨 (예: "활성 필터: 진행 중").
5. **빈 상태 처리**: 데이터 0건이면 지표 0 표시 + 의미 있는 빈 상태 안내 문구("등록된 요청이 없습니다 — Requests 탭에서 첫 요청을 등록하세요").
6. **반영 보장**: Requests 탭에서 추가·수정 → 상태 갱신 → 탭 이동·새로고침 후 Dashboard에 반영되는지 통합·E2E로 검증.
7. **반응형/접근성**: 데스크톱 2~3열, 모바일 1열, 레이블·포커스 표시, 가로 스크롤 방지 (Requests와 동일 기준).
8. **단위 → 통합 → E2E(`dashboard`) → 빌드** 순서로 검증, 실패 시 §6 정책 적용, `evidence/` 기록.

## 5. AC09-01~AC09-06 검증 방법

| AC | 내용 | 단위 | 통합 | E2E (`tests/e2e/dashboard.spec.cjs`) |
| --- | --- | --- | --- | --- |
| AC09-01 | 지표 건수가 원본 데이터와 결정적으로 일치 | `tests/unit/stats.test.ts`: 고정 입력 배열 → 기대 건수(total/todo/in_progress/done) 정확 매칭, 빈 배열 → 모두 0 | `GET /api/requests` 응답을 stats로 계산한 값과 UI 렌더링 값 일치 재검증 | 실제 서버 데이터 로드 후 각 지표 카드 숫자가 데이터 개수와 일치하는지 어설션 |
| AC09-02 | 우선순위별 건수 합계 = 전체 건수 | `stats.test.ts`: low+medium+high 분포 합 == total (여러 케이스, 빈 배열 포함) | 통합 데이터로 분포 합계 일치 확인 | Dashboard 화면에서 분포 합계와 전체 카드 값 비교 어설션 |
| AC09-03 | 빈 데이터·0건 표시 | `stats.test.ts` 빈 입력 케이스, `dashboard.test.tsx` 빈 상태 문구 렌더링 | 빈 저장소 API 응답 시 오류 없음 | 요청 전부 제거/빈 상태 시나리오에서 0건 표시 + 빈 상태 안내 문구 존재 확인, 0 나눗셈 오류 없음 |
| AC09-04 | Requests 변경이 Dashboard에 반영 | `dashboard.test.tsx`: 데이터 갱신 후 지표 재계산 | POST/PATCH 후 통계 원본 일치 (통합 확장 테스트) | E2E: Requests에서 요청 등록(또는 상태 변경) → Dashboard 탭 이동 → 새로고침 후 반영 확인 |
| AC09-05 | 데스크톱·모바일 레이아웃 + 키보드 접근성 | `dashboard.test.tsx`: 접근 가능한 이름·레이블 확인 | — | 뷰포트 375px(1열)/1280px(2~3열) 확인, Tab 순회·포커스 표시 확인, 가로 스크롤 없음 |
| AC09-06 | 빌드 + 단위·통합 + E2E 모두 PASS | `npm test (unit)` 로그 | `npm run test:integration` 로그 | Playwright `POST /run {"test":"dashboard"}` → `status=PASS`, `exitCode=0` 확인. 원문 출력은 `evidence/`에 기록 |

E2E 판정은 Playwright Runner의 실제 응답으로만 하며, 로그로 확인하지 않은 테스트는 PASS로 표시하지 않는다. 작성 전 테스트는 `NOT_IMPLEMENTED`로 기록한다.

## 6. 실패 시 수정·재검증 정책 (역할 분리 포함)

- **책임**: Hermes가 코드 수정과 재시험 반복을 담당한다. Playwright는 테스트 실행만 담당한다.
- **반복 절차**: (1) 실패 로그 분석 → (2) 최소 수정(명세 위반 수정 금지, 인수 기준 약화 금지) → (3) 동일 테스트 재실행 → (4) 결과를 `evidence/`에 기록.
- **재시도 상한**: 문제당 최대 **3회**. 3회 내 미해결 시 반복을 중단하고 실패 로그 원문·시도 내역과 함께 차단 요인을 보고한다.
- 미실행 테스트는 결과 표에 `NOT_IMPLEMENTED`로 명시한다.
- 테스트 파일의 존재만으로 완료로 판단하지 않고, 실제 종료 코드와 검증 결과를 확인한다 (`specs/acceptance-criteria.md`).
