#!/usr/bin/env bash
# verify-requests.sh — AI Work Request Manager v3 제8교시 자율형 검증 Harness
# 한 번의 호출로 빌드→단위→통합→안전종료→시드복원·재시작→E2E→사후복원→최종검증을 수행한다.
set -u
export LC_ALL=C

ROOT=/workspace
SEED="$ROOT/data/fixtures/requests.seed.json"
DATA="$ROOT/server/data/requests.json"
SERVER_LOG="$ROOT/evidence/lesson08-server.log"
VITE_LOG="$ROOT/evidence/lesson08-vite.log"
API_PORT=3001
UI_PORT=5174

RUN_ID=$(date +%Y%m%d-%H%M%S)
LOGDIR="$ROOT/evidence/logs/lesson08-$RUN_ID"
mkdir -p "$LOGDIR"

FAILED=0

log() { echo "[$(date +%T) verify-requests $RUN_ID] $*"; }
step() { echo "[$(date +%T) STEP $RUN_ID] $1"; }
fail() { echo "[$(date +%T) STEP $RUN_ID] $1: FAIL — $2"; FAILED=1; }
pass() { echo "[$(date +%T) STEP $RUN_ID] $1: PASS — $2"; }

# ---- 프로세스 식별: 이 작업공간(/workspace/server, /workspace/client) 소속만 종료 대상 ----
is_ours() {
  local pid="$1" cmd cwd
  cmd=$(tr -d '\0' < "/proc/$pid/cmdline" 2>/dev/null || true)
  case "$cmd" in
    */workspace/server/*|*/workspace/client*) return 0 ;;
  esac
  cwd=$(readlink "/proc/$pid/cwd" 2>/dev/null || true)
  case "$cwd" in
    "$ROOT/server"|"$ROOT/server/"*|"$ROOT/client"|"$ROOT/client/"*) return 0 ;;
  esac
  return 1
}

alive() { [ -d "/proc/$1" ]; }

collect_ours() {
  local d pid
  for d in /proc/[0-9]*; do
    pid=${d#/proc/}
    is_ours "$pid" && echo "$pid"
  done
}

safe_kill() {
  local label="$1" pids pid any=0 i left
  pids=$(collect_ours)
  if [ -z "$pids" ]; then
    echo "[STEP $RUN_ID] $label: 종료 대상 프로세스 없음"
    return 0
  fi
  for pid in $pids; do kill "$pid" 2>/dev/null && any=1; done
  if [ "$any" -eq 0 ]; then
    echo "[STEP $RUN_ID] $label: SIGTERM 전송 실패"
    return 1
  fi
  # 안전 종료 확인: 최대 10초 대기
  for i in $(seq 1 10); do
    sleep 1
    left=""
    for pid in $pids; do alive "$pid" && left="$left $pid"; done
    if [ -z "$left" ]; then
      echo "[STEP $RUN_ID] $label: 안전 종료 확인 완료"
      return 0
    fi
  done
  # SIGKILL은 우리 프로세스에 한해 필요 시에만 사용
  for pid in $pids; do alive "$pid" && kill -9 "$pid" 2>/dev/null; done
  sleep 1
  for pid in $pids; do
    if alive "$pid"; then
      echo "[STEP $RUN_ID] $label: 종료 확인 실패 (pid=$pid)"
      return 1
    fi
  done
  echo "[STEP $RUN_ID] $label: SIGKILL 후 종료 확인 완료"
  return 0
}

restore_seed() {
  rm -f "$DATA.tmp"
  cp "$SEED" "$DATA"
}

start_server() {
  (cd "$ROOT/server" && nohup node "$ROOT/server/src/index.js" >> "$SERVER_LOG" 2>&1 &)
  (cd "$ROOT/client" && nohup node "$ROOT/client/node_modules/vite/bin/vite.js" --host 0.0.0.0 --port "$UI_PORT" --strictPort >> "$VITE_LOG" 2>&1 &)
  local i code vcode
  for i in $(seq 1 20); do
    sleep 1
    code=$(curl -s -o /dev/null -w '%{http_code}' -m 2 "http://127.0.0.1:$API_PORT/api/requests" 2>/dev/null)
    vcode=$(curl -s -o /dev/null -w '%{http_code}' -m 2 "http://127.0.0.1:$UI_PORT" 2>/dev/null)
    if [ "$code" = "200" ] && [ "$vcode" = "200" ]; then
      return 0
    fi
  done
  return 1
}

S1_build() {
  step "S1 프런트엔드 빌드"
  if (cd "$ROOT/client" && npx tsc -p tsconfig.json --noEmit && npx vite build) > "$LOGDIR/s1-build.log" 2>&1; then
    pass "S1" "tsc --noEmit + vite build"
  else
    fail "S1" "빌드 실패 (로그: $LOGDIR/s1-build.log)"
  fi
}

S2_unit() {
  step "S2 단위 테스트 (제8교시: validate/store)"
  if (cd "$ROOT" && npx vitest run tests/unit/validate.test.ts tests/unit/store.test.ts) > "$LOGDIR/s2-unit.log" 2>&1; then
    pass "S2" "단위 테스트"
  else
    fail "S2" "단위 테스트 실패 (로그: $LOGDIR/s2-unit.log)"
  fi
}

S3_integration() {
  step "S3 통합 테스트"
  if (cd "$ROOT" && npx vitest run tests/integration) > "$LOGDIR/s3-integration.log" 2>&1; then
    pass "S3" "통합 테스트"
  else
    fail "S3" "통합 테스트 실패 (로그: $LOGDIR/s3-integration.log)"
  fi
}

S4_kill() {
  step "S4 앱 서버 안전 종료"
  if safe_kill "S4"; then
    pass "S4" "안전 종료 확인"
  else
    fail "S4" "안전 종료 확인 실패 — 데이터 복원 강행하지 않음"
    exit 1
  fi
}

S5_restore_restart() {
  step "S5 초기 데이터 3건 복원 및 앱 서버 재시작"
  if safe_kill "S5-kill" && restore_seed && start_server; then
    pass "S5" "초기 데이터 3건 복원 + 서버 재시작"
  else
    fail "S5" "복원 또는 재시작 실패"
  fi
}

S6_e2e() {
  step "S6 E2E 실행 (POST http://playwright:3000/run)"
  local code
  code=$(curl -s -m 300 -X POST -H 'Content-Type: application/json' \
    -d '{"test":"requests"}' -o "$LOGDIR/s6-e2e.json" -w '%{http_code}' \
    http://playwright:3000/run 2>/dev/null)
  if [ "$code" = "200" ] && grep -q '"status":"PASS"' "$LOGDIR/s6-e2e.json"; then
    pass "S6" "E2E 실행 (결과: $LOGDIR/s6-e2e.json)"
  else
    fail "S6" "E2E 실패 (HTTP $code, 결과: $LOGDIR/s6-e2e.json)"
  fi
}

S7_restore_restart() {
  step "S7 E2E 종료 후 서버 안전 종료, 초기 데이터 복원, 서버 재시작"
  if safe_kill "S7-kill" && restore_seed && start_server; then
    pass "S7" "초기 데이터 복원 + 서버 재시작"
  else
    fail "S7" "안전 종료 또는 복원/재시작 실패"
  fi
}

S8_final() {
  step "S8 최종 검증 (초기 요청 3건 + 서버 정상 실행)"
  local body n
  body=$(curl -s -m 5 "http://127.0.0.1:$API_PORT/api/requests" 2>/dev/null)
  n=$(printf '%s' "$body" | python3 -c 'import json,sys; print(len(json.load(sys.stdin)["items"]))' 2>/dev/null)
  if [ "$n" = "3" ]; then
    pass "S8" "초기 요청 3건 + 서버 정상 실행"
  else
    fail "S8" "초기 요청 3건이 아님 (실제: ${n:-없음})"
  fi
}

S1_build
S2_unit
S3_integration
if [ "$FAILED" -eq 0 ]; then
  S4_kill
  S5_restore_restart
  S6_e2e
  S7_restore_restart
  S8_final
else
  fail "S4" "S1-S3 실패로 생략"
  fail "S5" "S1-S3 실패로 생략"
  fail "S6" "S1-S3 실패로 생략"
  fail "S7" "S1-S3 실패로 생략"
  fail "S8" "S1-S3 실패로 생략"
fi

log "실행 로그: $LOGDIR"
if [ "$FAILED" -eq 0 ]; then
  log "OVERALL: PASS"
  exit 0
fi
log "OVERALL: FAIL"
exit 1
