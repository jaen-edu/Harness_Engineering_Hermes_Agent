#!/usr/bin/env bash
# verify-dashboard.sh — AI Work Request Manager v3 제9교시 자율형 검증 Harness
# 한 번의 호출로 빌드→단위→통합→안전종료→시드복원·재시작→E2E(dashboard)→사후복원→최종검증을 수행한다.
# verify-requests.sh와 동일한 실행 방식·결과 기록 형식을 재사용하되 아래 안전 규칙을 적용한다.
#  - 포트 번호만으로 무관한 프로세스를 종료하지 않는다(소속 /workspace/server|client 만 대상).
#  - 종료 대상 프로세스의 소유 관계를 확인할 수 없으면 FAIL로 보고한다.
#  - 서버가 실제로 중지되지 않았다면 데이터 파일을 덮어쓰지 않는다.
set -u
export LC_ALL=C

ROOT=/workspace
SEED="$ROOT/data/fixtures/requests.seed.json"
DATA="$ROOT/server/data/requests.json"
SERVER_LOG="$ROOT/evidence/lesson09-server.log"
VITE_LOG="$ROOT/evidence/lesson09-vite.log"
API_PORT=3001
UI_PORT=5174

RUN_ID=$(date +%Y%m%d-%H%M%S)
LOGDIR="$ROOT/evidence/logs/lesson09-$RUN_ID"
mkdir -p "$LOGDIR"

FAILED=0

log() { echo "[$(date +%T) verify-dashboard $RUN_ID] $*"; }
step() { echo "[$(date +%T) STEP $RUN_ID] $1"; }
fail() { echo "[$(date +%T) STEP $RUN_ID] $1: FAIL — $2"; FAILED=1; }
pass() { echo "[$(date +%T) STEP $RUN_ID] $1: PASS — $2"; }

# ---- 프로세스 식별: 이 작업공간(/workspace/server, /workspace/client) 소속만 종료 대상 ----
is_ours() {
  local pid="$1" cmd cwd
  cmd=$(tr -d '\0' < "/proc/$pid/cmdline" 2>/dev/null || true)
  case "$cmd" in
    */workspace/server/*|*/workspace/client*) return 0 ;;
  esac
  cwd=$(readlink "/proc/$pid/cwd" 2>/dev/null || true)
  case "$cwd" in
    "$ROOT/server"|"$ROOT/server/"*|"$ROOT/client"|"$ROOT/client/"*) return 0 ;;
  esac
  return 1
}

alive() { [ -d "/proc/$1" ]; }

# 우리 소속으로 식별 가능한 프로세스 목록
collect_ours() {
  local d pid
  for d in /proc/[0-9]*; do
    pid=${d#/proc/}
    is_ours "$pid" && echo "$pid"
  done
}

# 포트가 응답하면 리스너가 존재한다는 신호 — 소유 확인 불가 시 FAIL에 사용
port_busy() {
  local code
  code=$(curl -s -o /dev/null -w '%{http_code}' -m 2 "$1" 2>/dev/null)
  [ "$code" != "000" ] && [ -n "$code" ]
}

# 리스닝 프로세스가 모두 우리 소속인지 확인 (소유 관계 확인 불가 → 1 반환)
ports_owned_by_us() {
  local pids listening pid
  pids=$(collect_ours)
  # /proc/net/tcp* 에서 포트 리스닝 여부 확인(16진수 little-endian 주소 필요 없이 상태 0A)
  for p in "$API_PORT" "$UI_PORT"; do
    local hex
    hex=$(printf '%04X' "$p")
    if grep -qi ":$hex .* 0A " /proc/net/tcp /proc/net/tcp6 2>/dev/null; then
      listening=1
      # 리스닝 소켓의 소유 pid를 inode로 역추적 가능한 경우에만 통과시킨다
      local inode owners=""
      owners=$(ls -l /proc/[0-9]*/fd 2>/dev/null | grep -o 'socket:\[[0-9]*\]' | sort -u || true)
      local found=0
      for pid in $pids; do
        if ls -l "/proc/$pid/fd" 2>/dev/null | grep -q 'socket:'; then
          # 우리 프로세스 중 하나가 소켓을 보유 중이면 소유 관계 확인됨
          found=1
        fi
      done
      if [ "$found" -eq 0 ]; then
        echo "$p"
        return 1
      fi
    fi
  done
  return 0
}

safe_kill() {
  local label="$1" pids pid any=0 i left
  pids=$(collect_ours)
  if [ -z "$pids" ]; then
    echo "[STEP $RUN_ID] $label: 종료 대상 프로세스 없음"
    return 0
  fi
  for pid in $pids; do kill "$pid" 2>/dev/null && any=1; done
  if [ "$any" -eq 0 ]; then
    echo "[STEP $RUN_ID] $label: SIGTERM 전송 실패"
    return 1
  fi
  # 안전 종료 확인: 최대 10초 대기
  for i in $(seq 1 10); do
    sleep 1
    left=""
    for pid in $pids; do alive "$pid" && left="$left $pid"; done
    if [ -z "$left" ]; then
      echo "[STEP $RUN_ID] $label: 안전 종료 확인 완료"
      return 0
    fi
  done
  # SIGKILL은 우리 프로세스에 한해 필요 시에만 사용
  for pid in $pids; do alive "$pid" && kill -9 "$pid" 2>/dev/null; done
  sleep 1
  for pid in $pids; do
    if alive "$pid"; then
      echo "[STEP $RUN_ID] $label: 종료 확인 실패 (pid=$pid)"
      return 1
    fi
  done
  echo "[STEP $RUN_ID] $label: SIGKILL 후 종료 확인 완료"
  return 0
}

# 안전종료 후 포트 잔존 확인: 무관한 프로세스가 포트를 점유 중이면 FAIL (데이터 덮어쓰기 금지)
verify_stopped() {
  local label="$1" i
  for i in 1 2 3 4 5; do
    if ! port_busy "http://127.0.0.1:$API_PORT/health" && ! port_busy "http://127.0.0.1:$UI_PORT"; then
      echo "[STEP $RUN_ID] $label: 포트 잔존 없음 확인 ($API_PORT/$UI_PORT)"
      return 0
    fi
    sleep 1
  done
  local offender
  offender=$(ports_owned_by_us 2>/dev/null)
  if [ -n "$offender" ]; then
    echo "[STEP $RUN_ID] $label: 포트 $offender 리스너가 /workspace 소속이 아님 — 소유 관계 확인 불가, 데이터 덮어쓰지 않음"
  else
    echo "[STEP $RUN_ID] $label: 포트가 아직 응답 중 — 서버가 실제로 중지되지 않음"
  fi
  return 1
}

restore_seed() {
  rm -f "$DATA.tmp"
  cp "$SEED" "$DATA"
}

start_server() {
  (cd "$ROOT/server" && nohup node "$ROOT/server/src/index.js" >> "$SERVER_LOG" 2>&1 &)
  (cd "$ROOT/client" && nohup node "$ROOT/client/node_modules/vite/bin/vite.js" --host 0.0.0.0 --port "$UI_PORT" --strictPort >> "$VITE_LOG" 2>&1 &)
  local i code vcode
  for i in $(seq 1 20); do
    sleep 1
    code=$(curl -s -o /dev/null -w '%{http_code}' -m 2 "http://127.0.0.1:$API_PORT/api/requests" 2>/dev/null)
    vcode=$(curl -s -o /dev/null -w '%{http_code}' -m 2 "http://127.0.0.1:$UI_PORT" 2>/dev/null)
    if [ "$code" = "200" ] && [ "$vcode" = "200" ]; then
      return 0
    fi
  done
  return 1
}

S1_build() {
  step "S1 프런트엔드 빌드"
  if (cd "$ROOT/client" && npx tsc -p tsconfig.json --noEmit && npx vite build) > "$LOGDIR/s1-build.log" 2>&1; then
    pass "S1" "tsc --noEmit + vite build"
  else
    fail "S1" "빌드 실패 (로그: $LOGDIR/s1-build.log)"
  fi
}

S2_unit() {
  step "S2 단위 테스트"
  if (cd "$ROOT" && npx vitest run tests/unit) > "$LOGDIR/s2-unit.log" 2>&1; then
    pass "S2" "단위 테스트 (stats + dashboard 렌더링 포함)"
  else
    fail "S2" "단위 테스트 실패 (로그: $LOGDIR/s2-unit.log)"
  fi
}

S3_integration() {
  step "S3 통합 테스트"
  if (cd "$ROOT" && npx vitest run tests/integration) > "$LOGDIR/s3-integration.log" 2>&1; then
    pass "S3" "통합 테스트 (API ↔ Dashboard 지표 연동 포함)"
  else
    fail "S3" "통합 테스트 실패 (로그: $LOGDIR/s3-integration.log)"
  fi
}

S4_kill() {
  step "S4 앱 서버·클라이언트 안전 종료"
  if safe_kill "S4" && verify_stopped "S4"; then
    pass "S4" "안전 종료 + 포트 잔존 없음 확인"
  else
    fail "S4" "안전 종료 확인 실패 — 데이터 복원 강행하지 않음"
    exit 1
  fi
}

S5_restore_restart() {
  step "S5 초기 데이터 3건 복원 및 앱 서버 재시작"
  if safe_kill "S5-kill" && verify_stopped "S5-kill" && restore_seed && start_server; then
    pass "S5" "초기 데이터 3건 복원 + 서버 재시작 + 헬스 200"
  else
    fail "S5" "복원 또는 재시작 실패"
  fi
}

S6_e2e() {
  step "S6 E2E 실행 (POST http://playwright:3000/run {\"test\":\"dashboard\"})"
  local code status exit_code timed_out
  code=$(curl -s -m 300 -X POST -H 'Content-Type: application/json' \
    -d '{"test":"dashboard"}' -o "$LOGDIR/s6-e2e.json" -w '%{http_code}' \
    http://playwright:3000/run 2>/dev/null)
  # Runner 응답의 status, exitCode, timedOut을 직접 파싱해 판정 (문자열 grep 오인 방지)
  status=$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(d.get("status",""))' "$LOGDIR/s6-e2e.json" 2>/dev/null)
  exit_code=$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(d.get("exitCode",""))' "$LOGDIR/s6-e2e.json" 2>/dev/null)
  timed_out=$(python3 -c 'import json,sys; d=json.load(open(sys.argv[1])); print(d.get("timedOut",""))' "$LOGDIR/s6-e2e.json" 2>/dev/null)
  if [ "$code" = "200" ] && [ "$status" = "PASS" ] && [ "$exit_code" = "0" ] && [ "$timed_out" = "False" ]; then
    pass "S6" "E2E status=PASS exitCode=0 timedOut=False (결과: $LOGDIR/s6-e2e.json)"
  else
    fail "S6" "E2E 실패 (HTTP $code, status=$status, exitCode=$exit_code, timedOut=$timed_out, 결과: $LOGDIR/s6-e2e.json)"
  fi
}

S7_restore_restart() {
  step "S7 E2E 종료 후 서버 안전 종료, 초기 데이터 복원, 서버 재시작 (성공·실패 무관 시도)"
  if safe_kill "S7-kill" && verify_stopped "S7-kill" && restore_seed && start_server; then
    pass "S7" "초기 데이터 복원 + 서버 재시작"
  else
    fail "S7" "안전 종료 또는 복원/재시작 실패"
  fi
}

S8_final() {
  step "S8 최종 검증 (초기 요청 3건 + 서버 정상 실행)"
  local body n
  body=$(curl -s -m 5 "http://127.0.0.1:$API_PORT/api/requests" 2>/dev/null)
  n=$(printf '%s' "$body" | python3 -c 'import json,sys; print(len(json.load(sys.stdin)["items"]))' 2>/dev/null)
  if [ "$n" = "3" ]; then
    pass "S8" "초기 요청 3건 + 서버 정상 실행"
  else
    fail "S8" "초기 요청 3건이 아님 (실제: ${n:-없음})"
  fi
}

S1_build
S2_unit
S3_integration
if [ "$FAILED" -eq 0 ]; then
  S4_kill
  S5_restore_restart
  S6_e2e
  S7_restore_restart
  S8_final
else
  fail "S4" "S1-S3 실패로 생략"
  fail "S5" "S1-S3 실패로 생략"
  fail "S6" "S1-S3 실패로 생략"
  fail "S7" "S1-S3 실패로 생략"
  fail "S8" "S1-S3 실패로 생략"
fi

log "실행 로그: $LOGDIR"
if [ "$FAILED" -eq 0 ]; then
  log "OVERALL: PASS"
  exit 0
fi
log "OVERALL: FAIL"
exit 1
