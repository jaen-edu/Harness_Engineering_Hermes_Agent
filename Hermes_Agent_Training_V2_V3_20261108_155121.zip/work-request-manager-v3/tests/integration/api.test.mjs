// tests/integration/api.test.mjs — 실제 서버 spawn 후 API 통합 검증
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { spawn } from 'node:child_process';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const PORT = 3002;
const BASE = `http://127.0.0.1:${PORT}`;
const DATA_FILE = join(mkdtempSync(join(tmpdir(), 'v3-it-')), 'requests.json');
let child;

function waitForServer(timeoutMs = 10000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = async () => {
      try {
        const r = await fetch(`${BASE}/api/requests`);
        if (r.ok) return resolve();
      } catch {}
      if (Date.now() - start > timeoutMs) return reject(new Error('server start timeout'));
      setTimeout(tick, 100);
    };
    tick();
  });
}

beforeAll(async () => {
  child = spawn('node', ['src/index.js'], {
    cwd: '/workspace/server',
    env: { ...process.env, PORT: String(PORT), DATA_FILE, SEED_FILE: '/workspace/data/fixtures/requests.seed.json' },
  });
  await waitForServer();
}, 30000);

afterAll(async () => {
  if (child) child.kill('SIGTERM');
});

describe('API 통합 검증', () => {
  it('초기 요청 3건을 반환', async () => {
    const r = await fetch(`${BASE}/api/requests`);
    expect(r.status).toBe(200);
    const body = await r.json();
    expect(body.items).toHaveLength(3);
  });

  it('필수 입력 검증: 기계 판독 가능한 오류 코드', async () => {
    const r = await fetch(`${BASE}/api/requests`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '' }),
    });
    expect(r.status).toBe(400);
    const body = await r.json();
    expect(body.error.code).toBe('VALIDATION_REQUIRED_FIELD');
    expect(Array.isArray(body.error.errors)).toBe(true);
  });

  it('등록 → 수정 → 상태 변경 → 검색 → 상태 필터', async () => {
    // 등록
    const r = await fetch(`${BASE}/api/requests`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '통합 테스트 요청', requester: 'tester', description: '통합 테스트용' }),
    });
    expect(r.status).toBe(201);
    const created = await r.json();
    expect(created.id).toBe('REQ-004');
    expect(created.status).toBe('todo');

    // 상태 변경
    const r2 = await fetch(`${BASE}/api/requests/${created.id}`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'done' }),
    });
    expect(r2.status).toBe(200);
    const patched = await r2.json();
    expect(patched.status).toBe('done');

    // 검색
    const r3 = await fetch(`${BASE}/api/requests?q=${encodeURIComponent('통합 테스트')}`);
    expect(r3.status).toBe(200);
    expect((await r3.json()).items).toHaveLength(1);

    // 상태 필터: REQ-003(시드 done) + REQ-004(새로 등록 후 done) = 2건
    const r4 = await fetch(`${BASE}/api/requests?status=done`);
    expect((await r4.json()).items).toHaveLength(2);
  });

  it('잘못된 상태 값은 400 VALIDATION_INVALID_STATUS', async () => {
    const r = await fetch(`${BASE}/api/requests?status=bad`);
    expect(r.status).toBe(400);
    expect((await r.json()).error.code).toBe('VALIDATION_INVALID_STATUS');
  });

  it('존재하지 않는 id PATCH는 404 NOT_FOUND', async () => {
    const r = await fetch(`${BASE}/api/requests/REQ-999`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'done' }),
    });
    expect(r.status).toBe(404);
    expect((await r.json()).error.code).toBe('NOT_FOUND');
  });
});
