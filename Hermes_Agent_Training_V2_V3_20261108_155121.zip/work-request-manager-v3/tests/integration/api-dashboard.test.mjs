// tests/integration/api-dashboard.test.mjs — Requests API 데이터 변경 ↔ Dashboard 지표 연동 통합 테스트
// 실제 서버 spawn 후 GET /api/requests 원본 데이터 기준으로 지표를 검증한다 (단일 데이터 원본).
import { describe, it, expect, beforeAll, afterAll } from 'vitest';
import { spawn } from 'node:child_process';
import { mkdtempSync } from 'node:fs';
import { tmpdir } from 'node:os';
import { join } from 'node:path';

const PORT = 3003;
const BASE = `http://127.0.0.1:${PORT}`;
const DATA_FILE = join(mkdtempSync(join(tmpdir(), 'v3-dash-')), 'requests.json');
let child;

function waitForServer(timeoutMs = 10000) {
  const start = Date.now();
  return new Promise((resolve, reject) => {
    const tick = async () => {
      try {
        const r = await fetch(`${BASE}/api/requests`);
        if (r.ok) return resolve();
      } catch {}
      if (Date.now() - start > timeoutMs) return reject(new Error('server start timeout'));
      setTimeout(tick, 100);
    };
    tick();
  });
}

// Dashboard stats.ts와 동일한 기준으로 원본 데이터에서 지표를 계산 (순수 집계)
function computeStats(items) {
  const s = { total: 0, todo: 0, in_progress: 0, done: 0, priority: { low: 0, medium: 0, high: 0 } };
  for (const r of items) {
    s.total += 1;
    if (r.status in s && r.status !== 'priority') s[r.status] += 1;
    if (['low', 'medium', 'high'].includes(r.priority)) s.priority[r.priority] += 1;
  }
  return s;
}

async function fetchStats() {
  const r = await fetch(`${BASE}/api/requests`);
  expect(r.status).toBe(200);
  const body = await r.json();
  return { items: body.items, stats: computeStats(body.items) };
}

beforeAll(async () => {
  child = spawn('node', ['src/index.js'], {
    cwd: '/workspace/server',
    env: { ...process.env, PORT: String(PORT), DATA_FILE, SEED_FILE: '/workspace/data/fixtures/requests.seed.json' },
  });
  await waitForServer();
}, 30000);

afterAll(async () => {
  if (child) child.kill('SIGTERM');
});

describe('Requests API ↔ Dashboard 지표 연동', () => {
  it('AC09-01: 초기 시드 3건의 지표가 원본 데이터와 일치', async () => {
    const { stats } = await fetchStats();
    expect(stats).toEqual({ total: 3, todo: 1, in_progress: 1, done: 1, priority: { low: 1, medium: 1, high: 1 } });
  });

  it('AC09-02: 우선순위 합계 === 전체 건수 (불변식)', async () => {
    const { stats } = await fetchStats();
    expect(stats.priority.low + stats.priority.medium + stats.priority.high).toBe(stats.total);
  });

  it('AC09-04: POST 등록 후 원본 데이터 기준 지표가 즉시 재계산된다', async () => {
    const r = await fetch(`${BASE}/api/requests`, {
      method: 'POST',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ title: '대시보드 연동 테스트', requester: 'tester', description: '통합', priority: 'high' }),
    });
    expect(r.status).toBe(201);
    const { stats } = await fetchStats();
    expect(stats.total).toBe(4);
    expect(stats.todo).toBe(2); // 새 요청은 todo로 등록됨
    expect(stats.priority.high).toBe(2);
    expect(stats.priority.low + stats.priority.medium + stats.priority.high).toBe(stats.total);
  });

  it('AC09-04: PATCH 상태 변경 후 원본 데이터 기준 지표가 즉시 재계산된다', async () => {
    const r = await fetch(`${BASE}/api/requests/REQ-001`, {
      method: 'PATCH',
      headers: { 'Content-Type': 'application/json' },
      body: JSON.stringify({ status: 'done' }),
    });
    expect(r.status).toBe(200);
    const { stats } = await fetchStats();
    expect(stats.todo).toBe(1);
    expect(stats.done).toBe(2);
    expect(stats.in_progress).toBe(1);
    expect(stats.priority.low + stats.priority.medium + stats.priority.high).toBe(stats.total);
  });

  it('AC09-01: 상태 필터 파라미터를 사용해도 원본 집합 기준 지표와 일관된다', async () => {
    const r = await fetch(`${BASE}/api/requests?status=done`);
    expect(r.status).toBe(200);
    const body = await r.json();
    const filtered = computeStats(body.items);
    expect(filtered.total).toBe(2);
    expect(filtered.done).toBe(2);
    expect(filtered.todo).toBe(0);
  });
});
