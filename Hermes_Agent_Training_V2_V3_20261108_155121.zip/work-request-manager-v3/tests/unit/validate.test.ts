import { describe, it, expect } from 'vitest';
import { validateCreate, validatePatch } from '../../server/src/validate.js';

const valid = { title: 't', requester: 'r', description: 'd' };

describe('validateCreate', () => {
  it('rejects missing required fields', () => {
    const r = validateCreate({ title: '', requester: '', description: '' });
    expect(r.errors.length).toBeGreaterThan(0);
    expect(r.errors.some((e) => e.code === 'VALIDATION_REQUIRED_FIELD')).toBe(true);
  });
  it('rejects invalid priority', () => {
    const r = validateCreate({ ...valid, priority: 'urgent' });
    expect(r.errors.some((e) => e.code === 'VALIDATION_INVALID_PRIORITY')).toBe(true);
  });
  it('accepts a valid payload', () => {
    const r = validateCreate(valid);
    expect(r.errors).toHaveLength(0);
    expect(r.priority).toBe('medium');
  });
});

describe('validatePatch', () => {
  it('rejects empty patch', () => {
    const r = validatePatch({});
    expect(r.errors).toHaveLength(1);
    expect(r.errors[0].code).toBe('VALIDATION_EMPTY_PATCH');
  });
  it('rejects invalid status', () => {
    const r = validatePatch({ status: 'done!' });
    expect(r.errors.some((e) => e.code === 'VALIDATION_INVALID_STATUS')).toBe(true);
  });
  it('accepts a valid status patch', () => {
    const r = validatePatch({ status: 'done' });
    expect(r.errors).toHaveLength(0);
    expect(r.patch.status).toBe('done');
  });
});
