// tests/unit/stats.test.ts — 지표·분포 계산 순수 함수 단위 테스트 (AC09-01, AC09-02, AC09-03)
import { describe, it, expect } from 'vitest';
import type { Request } from '../../client/src/api/client';
import {
  computeStats,
  computeFilteredStats,
  filterByStatus,
  prioritySumMatchesTotal,
} from '../../client/src/features/dashboard/stats';

function mk(id: string, status: Request['status'], priority: Request['priority']): Request {
  return {
    id,
    title: `제목-${id}`,
    description: '설명',
    requester: '요청자',
    assignee: '담당자',
    priority,
    status,
    createdAt: '2026-10-01T09:00:00+09:00',
    updatedAt: '2026-10-01T09:00:00+09:00',
  };
}

const FIXTURE: Request[] = [
  mk('REQ-001', 'todo', 'high'),
  mk('REQ-002', 'in_progress', 'medium'),
  mk('REQ-003', 'done', 'low'),
  mk('REQ-004', 'todo', 'high'),
  mk('REQ-005', 'in_progress', 'low'),
];

describe('computeStats — AC09-01 지표 건수가 원본 데이터와 결정적으로 일치', () => {
  it('고정 입력 배열에 대해 기대 건수를 정확히 반환', () => {
    const s = computeStats(FIXTURE);
    expect(s.total).toBe(5);
    expect(s.todo).toBe(2);
    expect(s.in_progress).toBe(2);
    expect(s.done).toBe(1);
  });

  it('같은 입력을 반복 계산해도 항상 동일한 결과 (결정성)', () => {
    expect(computeStats(FIXTURE)).toEqual(computeStats([...FIXTURE].reverse()));
    expect(computeStats(FIXTURE)).toEqual(computeStats(FIXTURE));
  });

  it('시드 데이터 3건 (todo 1, in_progress 1, done 1)', () => {
    const seed: Request[] = [
      mk('REQ-001', 'todo', 'high'),
      mk('REQ-002', 'in_progress', 'medium'),
      mk('REQ-003', 'done', 'low'),
    ];
    const s = computeStats(seed);
    expect(s).toEqual({ total: 3, todo: 1, in_progress: 1, done: 1, priority: { low: 1, medium: 1, high: 1 } });
  });
});

describe('computeStats — AC09-03 빈 데이터 및 0건', () => {
  it('빈 배열은 모두 0 (오류 없음)', () => {
    const s = computeStats([]);
    expect(s).toEqual({ total: 0, todo: 0, in_progress: 0, done: 0, priority: { low: 0, medium: 0, high: 0 } });
  });

  it('빈 배열에서 0으로 나누지 않는다 (분모 0 안전)', () => {
    // 비율 계산이 도입되더라도 분모 0 케이스가 예외를 던지지 않아야 한다.
    expect(() => computeStats([])).not.toThrow();
  });
});

describe('computeStats — AC09-02 우선순위 합계 = 전체 건수', () => {
  it('low + medium + high === total', () => {
    const s = computeStats(FIXTURE);
    expect(s.priority.low + s.priority.medium + s.priority.high).toBe(s.total);
    expect(prioritySumMatchesTotal(s)).toBe(true);
  });

  it('빈 배열에서도 합계 불변식 성립 (0 == 0)', () => {
    const s = computeStats([]);
    expect(s.priority.low + s.priority.medium + s.priority.high).toBe(0);
    expect(s.total).toBe(0);
    expect(prioritySumMatchesTotal(s)).toBe(true);
  });

  it('여러 케이스에서 불변식 성립', () => {
    const cases: Request[][] = [
      [mk('A', 'todo', 'high')],
      [mk('A', 'todo', 'low'), mk('B', 'done', 'medium'), mk('C', 'in_progress', 'medium')],
      FIXTURE,
    ];
    for (const items of cases) {
      const s = computeStats(items);
      expect(s.priority.low + s.priority.medium + s.priority.high).toBe(s.total);
    }
  });
});

describe('filterByStatus / computeFilteredStats — 상태 필터', () => {
  it("'' 필터는 전체를 반환", () => {
    expect(filterByStatus(FIXTURE, '')).toHaveLength(5);
  });

  it("'in_progress' 필터는 해당 상태만 반환", () => {
    const filtered = filterByStatus(FIXTURE, 'in_progress');
    expect(filtered).toHaveLength(2);
    expect(filtered.every((r) => r.status === 'in_progress')).toBe(true);
  });

  it('필터 적용 시 필터된 집합 기준으로 지표·분포가 함께 계산된다', () => {
    const s = computeFilteredStats(FIXTURE, 'in_progress');
    expect(s.total).toBe(2);
    expect(s.in_progress).toBe(2);
    expect(s.todo).toBe(0);
    expect(s.done).toBe(0);
    // 필터된 집합에서도 우선순위 합계 불변식 유지
    expect(s.priority.low + s.priority.medium + s.priority.high).toBe(s.total);
  });

  it('존재하지 않는 상태 조합은 0건 (안전)', () => {
    const filtered = filterByStatus(FIXTURE, 'done');
    expect(computeStats(filtered).total).toBe(1);
  });
});
