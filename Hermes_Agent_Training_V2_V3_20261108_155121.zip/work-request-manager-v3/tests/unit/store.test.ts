import { describe, it, expect } from 'vitest';
import { createStore } from '../../server/src/store.js';

const TMP = '/tmp/v3-store-test.json';

describe('createStore', () => {
  it('persists items across save/load', () => {
    const store = createStore(TMP);
    store.save([{ id: '1', title: 'x' }]);
    const store2 = createStore(TMP);
    expect(store2.load()).toHaveLength(1);
    expect(store2.load()[0].id).toBe('1');
  });
});
