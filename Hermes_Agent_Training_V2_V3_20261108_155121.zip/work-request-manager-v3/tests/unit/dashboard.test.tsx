// @vitest-environment jsdom
// tests/unit/dashboard.test.tsx — Dashboard 렌더링·필터 갱신 단위 테스트 (AC09-01, AC09-03, AC09-04, AC09-05)
import React from 'react';
import '@testing-library/jest-dom/vitest';
import { describe, it, expect, vi, afterEach } from 'vitest';
import { render, screen, waitFor, cleanup, fireEvent } from '@testing-library/react';
import { Dashboard } from '../../client/src/features/dashboard/Dashboard';
import type { Request } from '../../client/src/api/client';

afterEach(() => {
  cleanup();
  vi.unstubAllGlobals();
});

function mk(id: string, status: Request['status'], priority: Request['priority']): Request {
  return {
    id,
    title: `제목-${id}`,
    description: '설명',
    requester: '요청자',
    assignee: '담당자',
    priority,
    status,
    createdAt: '2026-10-01T09:00:00+09:00',
    updatedAt: '2026-10-01T09:00:00+09:00',
  };
}

const SEED: Request[] = [
  mk('REQ-001', 'todo', 'high'),
  mk('REQ-002', 'in_progress', 'medium'),
  mk('REQ-003', 'done', 'low'),
];

function stubFetch(data: Request[]) {
  vi.stubGlobal(
    'fetch',
    vi.fn(() =>
      Promise.resolve(
        new Response(JSON.stringify({ items: data }), {
          status: 200,
          headers: { 'Content-Type': 'application/json' },
        }),
      ),
    ),
  );
}

async function renderDashboard(data: Request[] = SEED) {
  stubFetch(data);
  render(<Dashboard />);
  await waitFor(() => expect(screen.getByTestId('stat-total-value')).toHaveTextContent(String(data.length)));
}

describe('Dashboard 렌더링 — AC09-01 지표 건수 결정적 일치', () => {
  it('API 원본 데이터에서 계산한 지표 카드 값이 화면에 표시된다', async () => {
    await renderDashboard();
    expect(screen.getByTestId('stat-total-value')).toHaveTextContent('3');
    expect(screen.getByTestId('stat-todo-value')).toHaveTextContent('1');
    expect(screen.getByTestId('stat-in_progress-value')).toHaveTextContent('1');
    expect(screen.getByTestId('stat-done-value')).toHaveTextContent('1');
  });

  it('우선순위 분포: low/medium/high 각 1건, 합계 3 = 전체 3 (AC09-02)', async () => {
    await renderDashboard();
    expect(screen.getByTestId('priority-low-value')).toHaveTextContent('1');
    expect(screen.getByTestId('priority-medium-value')).toHaveTextContent('1');
    expect(screen.getByTestId('priority-high-value')).toHaveTextContent('1');
    expect(screen.getByTestId('priority-sum')).toHaveTextContent('합계 3 / 전체 3');
  });

  it('접근 가능한 이름·레이블이 제공된다 (AC09-05 단위 부분)', async () => {
    await renderDashboard();
    expect(screen.getByLabelText('대시보드 상태 필터')).toBeTruthy();
    expect(screen.getByLabelText('전체 3건')).toBeTruthy();
    expect(screen.getByLabelText('완료 1건')).toBeTruthy();
  });
});

describe('Dashboard 상태 필터 — 결정적 갱신 + 활성 필터 표시', () => {
  it('필터 변경 시 필터된 집합 기준으로 지표·분포가 갱신되고 활성 필터가 표시된다', async () => {
    await renderDashboard();
    fireEvent.change(screen.getByLabelText('대시보드 상태 필터'), { target: { value: 'in_progress' } });
    await waitFor(() => expect(screen.getByTestId('stat-total-value')).toHaveTextContent('1'));
    expect(screen.getByTestId('stat-in_progress-value')).toHaveTextContent('1');
    expect(screen.getByTestId('stat-todo-value')).toHaveTextContent('0');
    expect(screen.getByTestId('stat-done-value')).toHaveTextContent('0');
    expect(screen.getByTestId('active-filter')).toHaveTextContent('활성 필터: 진행 중');
    // 필터된 집합({in_progress, medium}) 기준 분포
    expect(screen.getByTestId('priority-medium-value')).toHaveTextContent('1');
    expect(screen.getByTestId('priority-high-value')).toHaveTextContent('0');
    expect(screen.getByTestId('priority-sum')).toHaveTextContent('합계 1 / 전체 1');
  });

  it('전체로 되돌리면 원래 지표로 복원된다', async () => {
    await renderDashboard();
    fireEvent.change(screen.getByLabelText('대시보드 상태 필터'), { target: { value: 'done' } });
    await waitFor(() => expect(screen.getByTestId('stat-total-value')).toHaveTextContent('1'));
    fireEvent.change(screen.getByLabelText('대시보드 상태 필터'), { target: { value: '' } });
    await waitFor(() => expect(screen.getByTestId('stat-total-value')).toHaveTextContent('3'));
  });
});

describe('AC09-03 빈 데이터', () => {
  it('0건이면 모든 건수 0 + 빈 상태 안내 표시', async () => {
    await renderDashboard([]);
    expect(screen.getByTestId('stat-total-value')).toHaveTextContent('0');
    expect(screen.getByTestId('stat-todo-value')).toHaveTextContent('0');
    expect(screen.getByTestId('stat-in_progress-value')).toHaveTextContent('0');
    expect(screen.getByTestId('stat-done-value')).toHaveTextContent('0');
    expect(screen.getByTestId('priority-sum')).toHaveTextContent('합계 0 / 전체 0');
    expect(screen.getByTestId('empty-state')).toHaveTextContent('등록된 요청이 없습니다');
  });
});

describe('AC09-04 데이터 갱신 후 지표 재계산', () => {
  it('refetch 결과가 반영되어 지표가 재계산된다', async () => {
    stubFetch(SEED);
    render(<Dashboard />);
    await waitFor(() => expect(screen.getByTestId('stat-total-value')).toHaveTextContent('3'));
    // Requests에서 1건 추가 후 새로고침 버튼으로 다시 GET /api/requests
    stubFetch([...SEED, mk('REQ-004', 'todo', 'low')]);
    fireEvent.click(screen.getByTestId('dashboard-refresh'));
    await waitFor(() => expect(screen.getByTestId('stat-total-value')).toHaveTextContent('4'));
    expect(screen.getByTestId('stat-todo-value')).toHaveTextContent('2');
    expect(screen.getByTestId('priority-low-value')).toHaveTextContent('2');
  });
});
