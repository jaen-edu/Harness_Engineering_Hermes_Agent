// tests/e2e/requests.spec.cjs — Playwright library API E2E (runner executes via NODE_PATH)
// Browser target: http://hermes:5174 (hostname, no fixed container IP)
// AC08-01~06 + UI08-01~08 검증
const { chromium } = require('playwright');

const BASE = process.env.E2E_BASE_URL || 'http://hermes:5174';

const fails = [];
function ok(cond, label) {
  if (cond) { console.log(`PASS: ${label}`); return true; }
  fails.push(label);
  console.error(`FAIL: ${label}`);
  return false;
}

async function formVisible(page) {
  return (await page.$$('[data-testid="request-form"]')).length > 0;
}

async function cardCount(page) {
  return page.$$eval('[data-testid="request-card"]', (els) => els.length);
}

async function main() {
  const browser = await chromium.launch();
  const page = await browser.newPage();
  page.setDefaultTimeout(15000);
  page.on('console', (m) => console.log(`[console:${m.type()}] ${m.text()}`));
  page.on('pageerror', (e) => console.log(`[pageerror] ${e.message}`));
  page.on('requestfailed', (r) => console.log(`[requestfailed] ${r.url()} ${r.failure() && r.failure().errorText}`));
  page.on('response', (r) => { if (r.status() >= 400) console.log(`[http ${r.status()}] ${r.url()}`); });

  await page.goto(BASE, { waitUntil: 'domcontentloaded' });

  // AC08-01: initial 3 requests rendered as cards
  await page.waitForSelector('[data-testid="request-card"]', { timeout: 15000 });
  let count = await cardCount(page);
  ok(count === 3, `AC08-01 초기 요청 3건 카드 표시 (실제 ${count})`);

  // ---- UI08-01: 최초 진입 시 등록 폼은 숨김 상태 ----
  ok(!(await formVisible(page)), 'UI08-01 최초 진입 시 등록 폼 숨김');

  // ---- UI08-02: 검색·필터 영역 옆 [새 요청] 버튼 표시 ----
  const newBtn = page.locator('[data-testid="new-request-btn"]');
  ok(await newBtn.isVisible(), 'UI08-02 [새 요청] 버튼 표시');
  // 버튼이 검색·필터 영역(request-toolbar) 안에 배치되어 있는지 확인
  ok((await newBtn.locator('xpath=ancestor::div[contains(@class,"request-toolbar")]').count()) > 0,
    'UI08-02 [새 요청] 버튼이 검색·필터 영역 옆에 배치');

  // ---- UI08-03: [새 요청] 클릭 시 빈 등록 폼 표시 ----
  await newBtn.click();
  await page.waitForSelector('[data-testid="request-form"]');
  ok(await page.$eval('[data-testid="request-form"] input[name="title"]', (el) => el.value === ''),
    'UI08-03 [새 요청] 클릭 시 빈 등록 폼 표시');
  ok(await newBtn.getAttribute('aria-expanded') === 'true', 'UI08-03 버튼 aria-expanded=true');

  // ---- UI08-04: [취소] 클릭 시 등록 없이 폼 닫기 (데이터 불변) ----
  await page.locator('[data-testid="cancel-request"]').click();
  await page.waitForSelector('[data-testid="request-form"]', { state: 'detached' });
  ok(!(await formVisible(page)), 'UI08-04 [취소] 클릭 시 폼 닫힘');
  ok((await cardCount(page)) === 3, 'UI08-04 [취소] 후 데이터 불변 (3건)');

  // ---- UI08-03 재확인: [새 요청] 재클릭 → 빈 폼 ----
  await newBtn.click();
  await page.waitForSelector('[data-testid="request-form"]');
  ok(await page.$eval('[data-testid="request-form"] input[name="title"]', (el) => el.value === ''),
    'UI08-03 재클릭 시 빈 등록 폼 표시');

  // ---- UI08-06 (+AC08-06): 필수 입력 오류 → 오류 표시, 폼 유지, 등록 없음 ----
  // 공백만 입력한 제목은 HTML5 required를 통과하지만 서버 trim 검증에서 400을 반환한다.
  await page.fill('[data-testid="request-form"] input[name="title"]', '   ');
  await page.fill('[data-testid="request-form"] input[name="requester"]', 'E2E 요청자');
  await page.fill('[data-testid="request-form"] textarea[name="description"]', '필수 입력 검증');
  await page.locator('[data-testid="submit-request"]').click();
  await page.waitForSelector('[data-testid="form-error"]', { timeout: 5000 });
  ok(await formVisible(page), 'UI08-06 오류 시 폼 유지');
  ok((await cardCount(page)) === 3, 'UI08-06 오류 시 등록 없음 (3건 유지)');

  // ---- UI08-05 (+AC08-02): 정상 입력 등록 → 폼 닫힘 + 새 카드 즉시 표시 ----
  await page.fill('[data-testid="request-form"] input[name="title"]', 'E2E 테스트 요청');
  await page.fill('[data-testid="request-form"] input[name="requester"]', 'E2E 요청자');
  await page.fill('[data-testid="request-form"] textarea[name="description"]', 'E2E 자동화 테스트');
  await page.locator('[data-testid="submit-request"]').click();
  await page.waitForSelector('[data-testid="request-form"]', { state: 'detached' });
  ok(!(await formVisible(page)), 'UI08-05 등록 성공 시 폼 닫힘');
  await page.waitForFunction(() => document.querySelectorAll('[data-testid="request-card"]').length === 4);
  ok(true, 'AC08-02 등록 후 카드 4건');
  ok(await page.isVisible('text=E2E 테스트 요청'), 'UI08-05 새 카드 즉시 표시');

  // ---- AC08-03/UI08-07: 기존 요청 수정 보존 ----
  const card = page.locator('[data-testid="request-card"]', { hasText: '교육실 장비 점검' });
  await card.locator('button', { hasText: '수정' }).first().click();
  await card.locator('[data-testid="edit-form"] input[name="title"]').fill('E2E 수정 테스트');
  await card.locator('[data-testid="edit-form"] button[type="submit"]').click();
  await page.waitForSelector('text=E2E 수정 테스트');
  ok(true, 'AC08-03/UI08-07 제목 수정 반영');

  // ---- AC08-04/UI08-07: 상태 변경 보존 ----
  const card2 = page.locator('[data-testid="request-card"]', { hasText: 'E2E 수정 테스트' });
  await card2.locator('select').selectOption('done');
  await page.waitForSelector('.request-card:has-text("E2E 수정 테스트") .badge-status:has-text("완료")');
  ok(true, 'AC08-04/UI08-07 상태 변경 (완료 배지)');

  // ---- 검색 ----
  await page.fill('input[type="search"]', '설문');
  await page.waitForFunction(() => document.querySelectorAll('[data-testid="request-card"]').length === 1);
  ok(true, 'AC08-02 검색 "설문" -> 1건');

  // ---- 상태 필터 ----
  await page.fill('input[type="search"]', '');
  await page.selectOption('[aria-label="상태 필터"]', 'done');
  await page.waitForFunction(() => document.querySelectorAll('[data-testid="request-card"]').length === 2);
  ok(true, 'AC08-02 상태 필터 done -> 2건');

  // ---- 필터 초기화 ----
  await page.locator('button', { hasText: '필터 초기화' }).click();
  await page.waitForFunction(() => document.querySelectorAll('[data-testid="request-card"]').length === 4);
  ok(true, 'AC08-02 필터 초기화 -> 4건');

  // ---- UI08-08/AC08-05: 모바일 레이아웃 ----
  await page.setViewportSize({ width: 375, height: 667 });
  await page.waitForTimeout(300);
  const overflow = await page.evaluate(() => document.documentElement.scrollWidth - document.documentElement.clientWidth);
  ok(overflow <= 1, `UI08-08 모바일 375px 가로 스크롤 없음 (초과 ${overflow}px)`);
  ok(await page.locator('[data-testid="new-request-btn"]').isVisible(), 'UI08-08 모바일에서 [새 요청] 버튼 표시');
  ok((await page.$$eval('[data-testid="request-card"]', (els) => els.length)) === 4, 'UI08-08 모바일 카드 정상 표시');
  await page.setViewportSize({ width: 1280, height: 720 });

  // ---- UI08-08/AC08-05: 키보드 접근성 — Tab이 네이티브 대화형 요소에 머문다 ----
  await page.click('body');
  let okTab = true;
  for (let i = 0; i < 10; i++) {
    await page.keyboard.press('Tab');
    const tag = await page.evaluate(() => document.activeElement && document.activeElement.tagName);
    if (!['BUTTON', 'INPUT', 'SELECT', 'TEXTAREA'].includes(tag)) { okTab = false; break; }
  }
  ok(okTab, 'UI08-08/AC08-05 키보드 Tab 포커스 이동');

  await browser.close();
  if (fails.length) {
    console.error(`E2E FAIL: ${fails.length}건 실패`);
    process.exit(1);
  }
  console.log('E2E PASS: all assertions');
  process.exit(0);
}

main().catch((e) => {
  console.error(`E2E FAIL: ${e.message}`);
  process.exit(1);
});
