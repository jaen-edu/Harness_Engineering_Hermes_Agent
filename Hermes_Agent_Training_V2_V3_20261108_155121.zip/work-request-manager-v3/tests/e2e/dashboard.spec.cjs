// tests/e2e/dashboard.spec.cjs — Playwright library API E2E (runner executes via NODE_PATH)
// Browser target: http://hermes:5174 (hostname, no fixed container IP)
// AC09-01~AC09-05 검증. AC09-06은 Runner status/exitCode로 판정한다.
const { chromium } = require('playwright');

const BASE = process.env.E2E_BASE_URL || 'http://hermes:5174';

const fails = [];
function ok(cond, label) {
  if (cond) { console.log(`PASS: ${label}`); return true; }
  fails.push(label);
  console.error(`FAIL: ${label}`);
  return false;
}

async function gotoDashboard(page) {
  await page.goto(BASE, { waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-testid="tab-dashboard"]', { timeout: 15000 });
  await page.click('[data-testid="tab-dashboard"]');
  await page.waitForSelector('[data-testid="stat-total-value"]', { timeout: 15000 });
}

async function readStats(page) {
  return {
    total: await page.textContent('[data-testid="stat-total-value"]'),
    todo: await page.textContent('[data-testid="stat-todo-value"]'),
    in_progress: await page.textContent('[data-testid="stat-in_progress-value"]'),
    done: await page.textContent('[data-testid="stat-done-value"]'),
    low: await page.textContent('[data-testid="priority-low-value"]'),
    medium: await page.textContent('[data-testid="priority-medium-value"]'),
    high: await page.textContent('[data-testid="priority-high-value"]'),
  };
}

async function main() {
  const browser = await chromium.launch();
  const page = await browser.newPage({ viewport: { width: 1280, height: 800 } });
  page.setDefaultTimeout(15000);
  page.on('console', (m) => console.log(`[console:${m.type()}] ${m.text()}`));
  page.on('pageerror', (e) => console.log(`[pageerror] ${e.message}`));
  page.on('response', (r) => { if (r.status() >= 400 && !r.url().includes('data:')) console.log(`[http ${r.status()}] ${r.url()}`); });

  await gotoDashboard(page);

  // ---- AC09-01: 실제 서버 데이터 로드 후 각 지표 카드 숫자가 데이터 개수와 일치 ----
  // GET /api/requests 원본에서 계산한 기대값과 화면 값을 비교한다.
  const apiData = await page.evaluate(async () => {
    const r = await fetch('/api/requests');
    return r.json();
  });
  const items = apiData.items;
  const expected = { total: items.length, todo: 0, in_progress: 0, done: 0, low: 0, medium: 0, high: 0 };
  for (const r of items) {
    expected[r.status] += 1;
    expected[r.priority] += 1;
  }
  const s = await readStats(page);
  ok(
    Number(s.total) === expected.total && Number(s.todo) === expected.todo &&
    Number(s.in_progress) === expected.in_progress && Number(s.done) === expected.done,
    `AC09-01 지표 카드 = 원본 데이터 (화면 ${s.total}/${s.todo}/${s.in_progress}/${s.done}, 원본 ${expected.total}/${expected.todo}/${expected.in_progress}/${expected.done})`
  );

  // ---- AC09-02: 우선순위별 건수 합계 === 전체 건수 ----
  ok(
    Number(s.low) + Number(s.medium) + Number(s.high) === Number(s.total),
    `AC09-02 우선순위 합계 ${Number(s.low) + Number(s.medium) + Number(s.high)} === 전체 ${s.total}`
  );

  // ---- 상태 필터: 필터된 집합 기준 지표·분포 재계산 + 활성 필터 표시 ----
  await page.selectOption('[data-testid="dashboard-status-filter"]', 'in_progress');
  await page.waitForFunction(() => document.querySelector('[data-testid="active-filter"]')?.textContent?.includes('진행 중'));
  const filtered = items.filter((r) => r.status === 'in_progress');
  const s2 = await readStats(page);
  const exp2 = { total: filtered.length, todo: 0, in_progress: 0, done: 0, low: 0, medium: 0, high: 0 };
  for (const r of filtered) { exp2[r.status] += 1; exp2[r.priority] += 1; }
  ok(
    Number(s2.total) === exp2.total && Number(s2.in_progress) === exp2.in_progress &&
    Number(s2.todo) === 0 && Number(s2.done) === 0 &&
    Number(s2.low) + Number(s2.medium) + Number(s2.high) === Number(s2.total),
    `AC09-01/02 필터(in_progress) 기준 재계산: 화면 ${s2.total}건, 원본 필터 ${exp2.total}건`
  );
  ok(
    (await page.textContent('[data-testid="active-filter"]')).includes('활성 필터: 진행 중'),
    '활성 필터 명시 표시 (활성 필터: 진행 중)'
  );
  // 필터 해제 → 복원
  await page.selectOption('[data-testid="dashboard-status-filter"]', '');
  await page.waitForFunction((n) => document.querySelector('[data-testid="stat-total-value"]')?.textContent === String(n), items.length);

  // ---- AC09-04: Requests 탭 변경이 Dashboard에 반영 ----
  await page.click('[data-testid="tab-requests"]');
  await page.waitForSelector('[data-testid="request-card"]', { timeout: 15000 });
  // UI08 토글 도입: 등록 폼은 [새 요청] 버튼으로 연다.
  await page.click('[data-testid="new-request-btn"]');
  await page.waitForSelector('[data-testid="request-form"]', { timeout: 15000 });
  await page.fill('[data-testid="request-form"] input[name="title"]', '대시보드 반영 테스트');
  await page.fill('[data-testid="request-form"] input[name="requester"]', 'E2E 요청자');
  await page.fill('[data-testid="request-form"] textarea[name="description"]', 'AC09-04 반영 확인');
  await page.click('[data-testid="request-form"] button[type="submit"]');
  await page.waitForFunction((n) => document.querySelectorAll('[data-testid="request-card"]').length === n, items.length + 1);
  // 탭 이동 (같은 세션)
  await page.click('[data-testid="tab-dashboard"]');
  await page.waitForFunction((n) => document.querySelector('[data-testid="stat-total-value"]')?.textContent === String(n), items.length + 1);
  ok(true, `AC09-04 탭 이동 후 반영 (총 ${items.length + 1}건)`);
  // 새로고침 후에도 반영
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-testid="tab-dashboard"]', { timeout: 15000 });
  await page.click('[data-testid="tab-dashboard"]');
  await page.waitForFunction((n) => document.querySelector('[data-testid="stat-total-value"]')?.textContent === String(n), items.length + 1);
  ok(true, `AC09-04 새로고침 후에도 반영 (총 ${items.length + 1}건)`);
  // 우선순위 불변식 유지
  const s3 = await readStats(page);
  ok(
    Number(s3.low) + Number(s3.medium) + Number(s3.high) === Number(s3.total),
    `AC09-02 반영 후 불변식 유지 (합계 ${Number(s3.low) + Number(s3.medium) + Number(s3.high)} === ${s3.total})`
  );

  // ---- AC09-03: 빈 데이터·0건 (응답 차단 방식: 서버 데이터는 변경하지 않음) ----
  await page.route('**/api/requests**', (route) =>
    route.fulfill({ status: 200, contentType: 'application/json', body: JSON.stringify({ items: [] }) })
  );
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-testid="tab-dashboard"]', { timeout: 15000 });
  await page.click('[data-testid="tab-dashboard"]');
  await page.waitForSelector('[data-testid="empty-state"]', { timeout: 15000 });
  const s4 = await readStats(page);
  ok(
    s4.total === '0' && s4.todo === '0' && s4.in_progress === '0' && s4.done === '0' && s4.low === '0' && s4.medium === '0' && s4.high === '0',
    'AC09-03 빈 데이터: 모든 건수 0 표시'
  );
  const emptyMsg = await page.textContent('[data-testid="empty-state"]');
  ok(emptyMsg.includes('등록된 요청이 없습니다'), 'AC09-03 빈 상태 안내 문구 표시');
  await page.unroute('**/api/requests**');

  // ---- AC09-05: 데스크톱(1280px)·모바일(375px) 레이아웃 + 키보드 접근성 ----
  // 데스크톱: 가로 스크롤 없음
  await page.reload({ waitUntil: 'domcontentloaded' });
  await page.waitForSelector('[data-testid="tab-dashboard"]', { timeout: 15000 });
  await page.click('[data-testid="tab-dashboard"]');
  await page.waitForSelector('[data-testid="stat-total-value"]', { timeout: 15000 });
  const hScrollDesktop = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth
  );
  ok(!hScrollDesktop, 'AC09-05 데스크톱(1280px) 가로 스크롤 없음');

  // 모바일 375px: 1열, 가로 스크롤 없음
  await page.setViewportSize({ width: 375, height: 720 });
  await page.waitForTimeout(300);
  const cols = await page.evaluate(() => {
    const grid = document.querySelector('[data-testid="metric-cards"]');
    return getComputedStyle(grid).gridTemplateColumns.split(' ').length;
  });
  ok(cols === 1, `AC09-05 모바일(375px) 1열 레이아웃 (실제 ${cols}열)`);
  const hScrollMobile = await page.evaluate(
    () => document.documentElement.scrollWidth > document.documentElement.clientWidth
  );
  ok(!hScrollMobile, 'AC09-05 모바일(375px) 가로 스크롤 없음');

  // 키보드: Tab이 대화형 요소에 머무르며 포커스 표시(box-shadow) 존재
  await page.setViewportSize({ width: 1280, height: 800 });
  await page.click('body');
  const nInteractive = await page.evaluate(() =>
    document.querySelectorAll('main button, main input, main select, main textarea, main a[href]').length
  );
  let okTab = true, okFocus = true;
  for (let i = 0; i < nInteractive; i++) {
    await page.keyboard.press('Tab');
    const info = await page.evaluate(() => {
      const el = document.activeElement;
      if (!el || !['BUTTON', 'INPUT', 'SELECT', 'TEXTAREA'].includes(el.tagName)) return null;
      const shadow = getComputedStyle(el).boxShadow;
      return { tag: el.tagName, shadow };
    });
    if (!info) { okTab = false; break; }
    if (!info.shadow || info.shadow === 'none') okFocus = false;
  }
  ok(okTab, 'AC09-05 키보드 Tab 포커스 이동');
  ok(okFocus, 'AC09-05 키보드 포커스 표시 (focus ring)');

  await browser.close();
  if (fails.length) {
    console.error(`E2E FAIL: ${fails.length}건 실패`);
    process.exit(1);
  }
  console.log('E2E PASS: all assertions');
  process.exit(0);
}

main().catch((e) => {
  console.error(`E2E FAIL: ${e.message}`);
  process.exit(1);
});
