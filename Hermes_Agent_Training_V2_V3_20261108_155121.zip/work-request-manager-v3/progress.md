# 진행 기록

- 제7교시: 환경 검증은 실행 후 AC07-01~06의 결과를 기록합니다. Starter 배포본 자체는 실행 결과를 주장하지 않습니다.
- 제8교시: **COMPLETE** — Requests 탭 구현 및 검증 완료.
  - 구현: `client/`(React+TS+Vite, 5174), `server/`(Node.js API + 파일 영속 저장소, 3001), 초기 요청 3건, 등록·수정·상태 변경·검색·상태 필터·필터 초기화, 서버 측 필수 입력 검증 + 기계 판독 가능한 오류 코드, 재시작 후 데이터 유지, 반응형 카드 UI, 키보드 접근성.
  - 테스트: `tests/unit/`(validate, store), `tests/integration/`(API), `tests/e2e/requests.spec.cjs`(Playwright Runner 연동).
  - Harness: `scripts/verify-requests.sh` — 빌드→단위→통합→안전 종료→시드 복원·재시작→E2E(POST http://playwright:3000/run {"test":"requests"})→사후 복원·재시작→최종 검증, 단계별 PASS/FAIL·종료 코드·로그 보존(`/workspace/evidence/logs/lesson08-<RUN_ID>/`).
  - 결과: 안정화 실행 1회 + 추가 수정 없이 2회 연속 `OVERALL: PASS`(exit=0). 스크립트 sha256 재실행 전후 동일. AC08-01~AC08-06 모두 PASS (증거: `evidence/lesson08-verification.md`).
  - 실패 13건(빌드 타입 오류, vitest 설정 부재, 빈 patch 검증 누락, Vite allowedHosts 403, E2E 셀렉터·시드 불일치, `page.click` hasText 옵션 무시, 소속 프로세스 판별 등)을 로그 기반으로 최소 수정 후 재검증 완료. 문제당 재시도 상한 3회 내 해결.
- 제9교시: `NOT_IMPLEMENTED`. (Dashboard 지표 기능은 요구에 따라 구현하지 않음)
