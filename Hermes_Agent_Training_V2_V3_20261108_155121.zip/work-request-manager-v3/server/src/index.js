// AI Work Request Manager v3 — API 서버 (Node.js 내장 http, 파일 기반 영속 저장소)
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import { fileURLToPath } from 'node:url';
import { createStore } from './store.js';
import { validateCreate, validatePatch, nowIso } from './validate.js';

const __dirname = path.dirname(fileURLToPath(import.meta.url));
const DATA_FILE = process.env.DATA_FILE || path.join(__dirname, '..', 'data', 'requests.json');
const SEED_FILE = process.env.SEED_FILE || path.join(__dirname, '..', 'data', 'requests.seed.json');
const PORT = Number(process.env.PORT || 3001);
const HOST = process.env.HOST || '0.0.0.0';

const store = createStore(DATA_FILE);
let requests = store.load();

if (!requests) {
  // 첫 기동: 시드 파일로 초기 데이터 기록
  const seed = JSON.parse(fs.readFileSync(SEED_FILE, 'utf8'));
  requests = seed;
  store.save(requests);
}

function nextId() {
  let max = 0;
  for (const r of requests) {
    const m = /^REQ-(\d+)$/.exec(r.id);
    if (m) max = Math.max(max, Number(m[1]));
  }
  return `REQ-${String(max + 1).padStart(3, '0')}`;
}

function sendJson(res, status, payload) {
  const body = JSON.stringify(payload);
  res.writeHead(status, { 'Content-Type': 'application/json; charset=utf-8', 'Content-Length': Buffer.byteLength(body) });
  res.end(body);
}

function readBody(req) {
  return new Promise((resolve, reject) => {
    let chunks = '';
    req.on('data', (c) => {
      chunks += c;
      if (chunks.length > 1e6) reject(new Error('BODY_TOO_LARGE'));
    });
    req.on('end', () => {
      if (!chunks) return resolve({});
      try {
        resolve(JSON.parse(chunks));
      } catch {
        reject(new Error('INVALID_JSON'));
      }
    });
    req.on('error', reject);
  });
}

function handleErrors(res, e) {
  if (e.message === 'INVALID_JSON') return sendJson(res, 400, { error: { code: 'VALIDATION_INVALID_JSON', message: '요청 본문이 올바른 JSON이 아닙니다.' } });
  if (e.message === 'BODY_TOO_LARGE') return sendJson(res, 413, { error: { code: 'VALIDATION_BODY_TOO_LARGE', message: '요청 본문이 너무 큽니다.' } });
  return sendJson(res, 500, { error: { code: 'INTERNAL_ERROR', message: '서버 내부 오류가 발생했습니다.' } });
}

const server = http.createServer(async (req, res) => {
  const url = new URL(req.url, `http://${req.headers.host || 'localhost'}`);
  const pathname = url.pathname;

  if (pathname === '/health') {
    return sendJson(res, 200, { status: 'OK', count: requests.length });
  }

  if (pathname === '/api/requests' && req.method === 'GET') {
    const q = (url.searchParams.get('q') || '').trim().toLowerCase();
    const status = url.searchParams.get('status') || '';
    let items = requests;
    if (status) {
      if (!['todo', 'in_progress', 'done'].includes(status)) {
        return sendJson(res, 400, { error: { code: 'VALIDATION_INVALID_STATUS', field: 'status', message: 'status는 todo|in_progress|done 중 하나여야 합니다.' } });
      }
      items = items.filter((r) => r.status === status);
    }
    if (q) {
      items = items.filter((r) =>
        [r.title, r.description, r.requester, r.assignee].some((v) => typeof v === 'string' && v.toLowerCase().includes(q))
      );
    }
    return sendJson(res, 200, { items });
  }

  if (pathname === '/api/requests' && req.method === 'POST') {
    let body;
    try {
      body = await readBody(req);
    } catch (e) {
      return handleErrors(res, e);
    }
    const { errors, priority } = validateCreate(body);
    if (errors.length) return sendJson(res, 400, { error: { code: errors[0].code, field: errors[0].field, message: errors[0].message, errors } });
    const now = nowIso();
    const item = {
      id: nextId(),
      title: body.title.trim(),
      description: body.description.trim(),
      requester: body.requester.trim(),
      assignee: typeof body.assignee === 'string' && body.assignee.trim() ? body.assignee.trim() : '',
      priority,
      status: 'todo',
      createdAt: now,
      updatedAt: now,
    };
    requests.push(item);
    store.save(requests);
    return sendJson(res, 201, item);
  }

  const patchMatch = /^\/api\/requests\/([^/]+)$/.exec(pathname);
  if (patchMatch && req.method === 'PATCH') {
    let body;
    try {
      body = await readBody(req);
    } catch (e) {
      return handleErrors(res, e);
    }
    const item = requests.find((r) => r.id === patchMatch[1]);
    if (!item) return sendJson(res, 404, { error: { code: 'NOT_FOUND', message: '존재하지 않는 요청입니다.' } });
    const { errors, patch } = validatePatch(body);
    if (errors.length) return sendJson(res, 400, { error: { code: errors[0].code, field: errors[0].field, message: errors[0].message, errors } });
    if (Object.keys(patch).length === 0) {
      return sendJson(res, 400, { error: { code: 'VALIDATION_EMPTY_PATCH', message: '수정할 필드가 지정되지 않았습니다.' } });
    }
    Object.assign(item, patch, { updatedAt: nowIso() });
    store.save(requests);
    return sendJson(res, 200, item);
  }

  return sendJson(res, 404, { error: { code: 'NOT_FOUND', message: '요청한 경로가 없습니다.' } });
});

export { server, PORT, HOST };

if (process.env.VITEST !== '1') {
  server.listen(PORT, HOST, () => {
    console.log(`API server listening on http://${HOST}:${PORT}`);
  });
}
