// 파일 기반 영속 저장소 (원자적 쓰기: 임시 파일 → rename)
import fs from 'node:fs';
import path from 'node:path';

export function createStore(filePath) {
  function load() {
    try {
      const raw = fs.readFileSync(filePath, 'utf8');
      const data = JSON.parse(raw);
      if (Array.isArray(data)) return data;
    } catch {
      /* 파일 없거나 파싱 실패 → 시드로 시작 */
    }
    return null;
  }

  function save(items) {
    fs.mkdirSync(path.dirname(filePath), { recursive: true });
    const tmp = filePath + '.tmp';
    fs.writeFileSync(tmp, JSON.stringify(items, null, 2), 'utf8');
    fs.renameSync(tmp, filePath);
  }

  return { load, save };
}
