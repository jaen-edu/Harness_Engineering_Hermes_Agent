// 입력 검증 — 기계 판독 가능한 오류 코드 반환
const PRIORITIES = ['low', 'medium', 'high'];
const STATUSES = ['todo', 'in_progress', 'done'];

export function validateCreate(body) {
  const errors = [];
  const b = body && typeof body === 'object' ? body : {};
  for (const field of ['title', 'requester', 'description']) {
    const v = typeof b[field] === 'string' ? b[field].trim() : '';
    if (!v) {
      errors.push({ code: 'VALIDATION_REQUIRED_FIELD', field, message: `${field} 값은 공백 제거 후 비어 있으면 안 됩니다.` });
    }
  }
  const priority = b.priority === undefined || b.priority === null || b.priority === '' ? 'medium' : b.priority;
  if (!PRIORITIES.includes(priority)) {
    errors.push({ code: 'VALIDATION_INVALID_PRIORITY', field: 'priority', message: `priority는 ${PRIORITIES.join('|')} 중 하나여야 합니다.` });
  }
  return { errors, priority };
}

export function validatePatch(body) {
  const errors = [];
  const b = body && typeof body === 'object' ? body : {};
  const allowed = ['title', 'description', 'requester', 'assignee', 'priority', 'status'];
  const patch = {};
  for (const key of allowed) {
    if (!(key in b)) continue;
    const v = b[key];
    if (['title', 'description', 'requester', 'assignee'].includes(key)) {
      if (typeof v !== 'string' || v.trim() === '') {
        errors.push({ code: 'VALIDATION_REQUIRED_FIELD', field: key, message: `${key} 값은 공백 제거 후 비어 있으면 안 됩니다.` });
        continue;
      }
      patch[key] = v.trim();
    } else if (key === 'priority') {
      if (!PRIORITIES.includes(v)) {
        errors.push({ code: 'VALIDATION_INVALID_PRIORITY', field: 'priority', message: `priority는 ${PRIORITIES.join('|')} 중 하나여야 합니다.` });
        continue;
      }
      patch.priority = v;
    } else if (key === 'status') {
      if (!STATUSES.includes(v)) {
        errors.push({ code: 'VALIDATION_INVALID_STATUS', field: 'status', message: `status는 ${STATUSES.join('|')} 중 하나여야 합니다.` });
        continue;
      }
      patch.status = v;
    }
  }
  if (errors.length === 0 && Object.keys(patch).length === 0) {
    errors.push({ code: 'VALIDATION_EMPTY_PATCH', message: '수정할 필드가 지정되지 않았습니다.' });
  }
  return { errors, patch };
}

export function nowIso() {
  return new Date().toISOString();
}
