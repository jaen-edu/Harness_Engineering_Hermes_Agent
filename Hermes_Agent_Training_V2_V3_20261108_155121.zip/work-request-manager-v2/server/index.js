// 서버 시작: package.json "dev:server": "node server/index.js"
// - createApp({dataFile})을 호출해 기본 포트 3001에서 실행
// - DATA_FILE 환경변수가 설정되어 있으면 우선 전달 (docs/specification.md "저장")

import { createApp } from './app.js';

const PORT = Number(process.env.PORT) || 3001;
const dataFile = process.env.DATA_FILE || undefined;

const app = createApp({ dataFile });

app.listen(PORT, () => {
  console.log(`AI Work Request Manager API listening on http://localhost:${PORT}`);
});
