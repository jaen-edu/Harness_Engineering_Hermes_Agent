// 오류 형식과 코드: docs/specification.md "API 오류" (REQ-007)
// 형식: { "error": { "code": "...", "message": "..." } }
// 코드 4종: VALIDATION_ERROR, NOT_FOUND, INVALID_TRANSITION, INTERNAL_ERROR
// 스택 추적·서버 파일 경로는 노출하지 않는다.

export const CODES = {
  VALIDATION_ERROR: 'VALIDATION_ERROR',
  NOT_FOUND: 'NOT_FOUND',
  INVALID_TRANSITION: 'INVALID_TRANSITION',
  INTERNAL_ERROR: 'INTERNAL_ERROR',
};

export const STATUS_BY_CODE = {
  VALIDATION_ERROR: 400,
  NOT_FOUND: 404,
  INVALID_TRANSITION: 409,
  INTERNAL_ERROR: 500,
};

export class ApiError extends Error {
  constructor(code, message, status) {
    super(message);
    this.name = 'ApiError';
    this.code = code;
    this.status = status ?? STATUS_BY_CODE[code] ?? 500;
  }
}

export function validationError(message) {
  return new ApiError(CODES.VALIDATION_ERROR, message);
}

export function notFoundError(message) {
  return new ApiError(CODES.NOT_FOUND, message);
}

export function invalidTransitionError(message) {
  return new ApiError(CODES.INVALID_TRANSITION, message);
}

export function internalError(message) {
  return new ApiError(CODES.INTERNAL_ERROR, message);
}

// 중앙 오류 핸들러에서 사용: 오류를 {error:{code,message}}로 변환.
// 스택·경로 노출 없음. 알 수 없는 오류는 INTERNAL_ERROR로 통일.
export function toErrorResponse(err) {
  if (err instanceof ApiError) {
    return { status: err.status, body: { error: { code: err.code, message: err.message } } };
  }
  return {
    status: 500,
    body: { error: { code: CODES.INTERNAL_ERROR, message: '서버 내부 오류가 발생했습니다.' } },
  };
}
