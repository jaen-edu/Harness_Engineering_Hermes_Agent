// JSON 저장소: docs/specification.md "저장" (REQ-006)
// - 기본 ./data/requests.json, createApp({dataFile}) 옵션 우선
// - 파일 미존재 시 빈 배열 시작, 첫 쓰기 시 상위 디렉터리 안전 생성
// - 손상된 JSON은 초기화하지 않고 500 INTERNAL_ERROR
// - 같은 디렉터리의 고유 임시 파일에 쓰고 rename으로 원자적 교체
// - 읽기→수정→쓰기 전체를 직렬화 (순차 작업 큐)

import { mkdir, readFile, rename, writeFile } from 'node:fs/promises';
import path from 'node:path';
import { internalError } from './errors.js';

export const DEFAULT_DATA_FILE = './data/requests.json';

export function createStore({ dataFile } = {}) {
  const file = path.resolve(dataFile ?? DEFAULT_DATA_FILE);
  const dir = path.dirname(file);

  // 읽기→수정→쓰기 전체를 직렬화하는 순차 작업 큐.
  // 쓰기만 직렬화하면 두 요청이 같은 스냅샷을 읽어 한쪽 변경이 유실되므로
  // load부터 mutate, save까지 큐에서 순차 실행한다.
  let queue = Promise.resolve();

  function enqueue(task) {
    const run = queue.then(task, task);
    // 큐 체인이 깨지지 않도록 실패를 흡수한다 (개별 작업의 결과는 그대로 반환).
    queue = run.then(() => undefined, () => undefined);
    return run;
  }

  async function load() {
    let raw;
    try {
      raw = await readFile(file, 'utf8');
    } catch (err) {
      if (err && err.code === 'ENOENT') {
        return []; // 파일 미존재: 빈 배열 시작
      }
      // 파일이 있지만 읽기 실패 (권한 등): 조용히 초기화하지 않는다.
      throw internalError('저장 파일을 읽을 수 없습니다.');
    }
    try {
      const parsed = JSON.parse(raw);
      if (!Array.isArray(parsed)) {
        throw internalError('저장 파일 형식이 올바르지 않습니다.');
      }
      return parsed;
    } catch (err) {
      if (err instanceof Error && err.code === 'INTERNAL_ERROR') throw err;
      // 손상된 JSON: 빈 배열로 덮지 않고 500 보고.
      throw internalError('저장 파일이 손상되었습니다.');
    }
  }

  async function save(items) {
    // 상위 디렉터리 안전 생성 (첫 쓰기 시)
    await mkdir(dir, { recursive: true });
    // 같은 디렉터리의 고유한 임시 파일에 쓰고 rename으로 원자적 교체
    const tmp = path.join(dir, `.${path.basename(file)}.${process.pid}.${Date.now()}.${Math.random().toString(36).slice(2)}.tmp`);
    await writeFile(tmp, JSON.stringify(items, null, 2), 'utf8');
    await rename(tmp, file);
  }

  return {
    // 읽기 전용: 손상 파일이면 500 (AC-010). 파일을 덮지 않는다.
    load,

    // 읽기→수정→쓰기 전체 직렬화. mutate(items)는 배열을 받아 새 배열을 반환.
    // 예외 발생 시 저장하지 않고 오류를 그대로 전파한다.
    // fn이 입력 배열과 동일한 참조를 반환하면 '변경 없음'으로 보고
    // 저장 파일을 재기록하지 않고 기존 배열을 그대로 반환한다(동일 값 PATCH/상태 변경용).
    mutate(fn) {
      return enqueue(async () => {
        const items = await load();
        const next = await fn(items);
        if (next === items) {
          return items; // 변경 없음: 저장 스킵
        }
        await save(next);
        return next;
      });
    },

    // 읽기 전용 조회도 큐에 넣어 쓰기와의 순서를 보장한다.
    read() {
      return enqueue(async () => load());
    },

    // 경로·파일명 노출 없이 저장소가 같은 파일을 가리키는지 비교 (차후 PATCH 재사용)
    file,
  };
}
