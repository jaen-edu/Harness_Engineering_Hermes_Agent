// 유효성 검증: docs/specification.md "데이터 필드"·"생성" (REQ-001/007)
// - trim 후 Unicode 코드 포인트 기준 길이 (title 1-100, requester/assignee 1-60,
//   description 0-2000)
// - priority enum low/medium/high
// - 알 수 없는 필드·클라이언트 전달 id/status/시각 → 400
// - ID UUID v4 형식 검사 (승인 기준 C: 형식 검사를 조회보다 먼저 적용)

import { validationError } from './errors.js';

export const PRIORITIES = ['low', 'medium', 'high'];
export const STATUSES = ['received', 'in_progress', 'completed'];

// UUID v4 (형식 유효성만; 어떤 버전 비트든 v4 패턴으로 검사)
const UUID_V4_RE = /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i;

export function isUuidV4(value) {
  return typeof value === 'string' && UUID_V4_RE.test(value);
}

// 코드 포인트 기준 길이 (String.prototype.length는 UTF-16 코드 단위 기준이므로
// 서로게이트 쌍 2칸 문제를 피하려고 Array.from으로 코드 포인트를 센다)
export function codePointLength(value) {
  return Array.from(value).length;
}

function requireString(value, field) {
  if (typeof value !== 'string') {
    throw validationError(`${field} 필드는 문자열이어야 합니다.`);
  }
  return value.trim();
}

function requireLength(value, field, min, max) {
  const trimmed = requireString(value, field);
  const len = codePointLength(trimmed);
  if (len < min || len > max) {
    throw validationError(`${field} 필드는 ${min}~${max}자(코드 포인트)여야 합니다.`);
  }
  return trimmed;
}

function requireEnum(value, field, allowed) {
  if (typeof value !== 'string' || !allowed.includes(value)) {
    throw validationError(`${field} 필드는 ${allowed.join(', ')} 중 하나여야 합니다.`);
  }
  return value;
}

// POST /api/requests 본문 검증. 성공 시 정규화된 생성 입력을 반환.
// 허용 필드: title, description, requester, assignee, priority.
// 알 수 없는 필드(id/status/createdAt/updatedAt 등)는 400.
export function validateCreate(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    throw validationError('요청 본문은 JSON 객체여야 합니다.');
  }
  const allowed = ['title', 'description', 'requester', 'assignee', 'priority'];
  const unknown = Object.keys(body).filter((k) => !allowed.includes(k));
  if (unknown.length > 0) {
    throw validationError(`허용되지 않는 필드가 있습니다: ${unknown.join(', ')}`);
  }
  for (const field of ['title', 'requester', 'assignee', 'priority']) {
    if (!(field in body)) {
      throw validationError(`${field} 필드는 필수입니다.`);
    }
  }
  const title = requireLength(body.title, 'title', 1, 100);
  const requester = requireLength(body.requester, 'requester', 1, 60);
  const assignee = requireLength(body.assignee, 'assignee', 1, 60);
  const priority = requireEnum(body.priority, 'priority', PRIORITIES);
  let description = '';
  if (body.description !== undefined) {
    if (body.description === null) {
      throw validationError('description 필드는 문자열이어야 합니다.');
    }
    description = requireLength(body.description, 'description', 0, 2000);
  }
  return { title, description, requester, assignee, priority };
}

// 목록 필터 검증: status/priority는 선택적이며, 지정 시 enum이어야 한다.
export function validateListFilters(query) {
  const filters = {};
  if (query.status !== undefined) {
    filters.status = requireEnum(query.status, 'status', STATUSES);
  }
  if (query.priority !== undefined) {
    filters.priority = requireEnum(query.priority, 'priority', PRIORITIES);
  }
  return filters;
}

// PATCH /api/requests/:id 본문 검증 (REQ-005).
// assignee, priority 중 하나 이상만 허용. 빈 PATCH·알 수 없는 필드는 400.
export function validatePatch(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    throw validationError('요청 본문은 JSON 객체여야 합니다.');
  }
  const allowed = ['assignee', 'priority'];
  const unknown = Object.keys(body).filter((k) => !allowed.includes(k));
  if (unknown.length > 0) {
    throw validationError(`허용되지 않는 필드가 있습니다: ${unknown.join(', ')}`);
  }
  const patch = {};
  if ('assignee' in body) {
    patch.assignee = requireLength(body.assignee, 'assignee', 1, 60);
  }
  if ('priority' in body) {
    patch.priority = requireEnum(body.priority, 'priority', PRIORITIES);
  }
  if (Object.keys(patch).length === 0) {
    throw validationError('변경할 필드가 없습니다. assignee 또는 priority를 지정하세요.');
  }
  return patch;
}

// PATCH /api/requests/:id/status 본문 검증 (REQ-004).
// status 필드 하나만 허용. 빈 본문·미허용 필드·잘못된 enum은 400.
export function validatePatchStatus(body) {
  if (body === null || typeof body !== 'object' || Array.isArray(body)) {
    throw validationError('요청 본문은 JSON 객체여야 합니다.');
  }
  const unknown = Object.keys(body).filter((k) => k !== 'status');
  if (unknown.length > 0) {
    throw validationError(`허용되지 않는 필드가 있습니다: ${unknown.join(', ')}`);
  }
  if (!('status' in body)) {
    throw validationError('status 필드는 필수입니다.');
  }
  return { status: requireEnum(body.status, 'status', STATUSES) };
}

// 상태 전이 표 (REQ-004): 허용되지 않은 전이는 라우트에서 409 처리.
export const ALLOWED_TRANSITIONS = {
  received: ['in_progress'],
  in_progress: ['completed'],
  completed: ['in_progress'],
};

// 경로 ID 검증 (승인 기준 C): 형식 오류 → 400 VALIDATION_ERROR.
export function validateId(id) {
  if (!isUuidV4(id)) {
    throw validationError('요청 ID는 UUID v4 형식이어야 합니다.');
  }
  return id;
}
