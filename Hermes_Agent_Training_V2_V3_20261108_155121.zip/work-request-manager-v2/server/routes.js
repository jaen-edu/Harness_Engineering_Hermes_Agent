// 라우트: REQ-001 (등록), REQ-002 (목록·필터), REQ-003 (상세),
// REQ-004 (상태 변경 PATCH /:id/status), REQ-005 (수정 PATCH /:id)

import { randomUUID } from 'node:crypto';
import { notFoundError, invalidTransitionError } from './errors.js';
import {
  validateCreate,
  validateListFilters,
  validateId,
  validatePatch,
  validatePatchStatus,
  ALLOWED_TRANSITIONS,
} from './validate.js';

// GET /api/requests 응답: {items, total}. total = 필터 적용 후 items.length (기준 A).
// 정렬: createdAt 내림차순, 동률이면 id 오름차순.
function sortItems(items) {
  return [...items].sort((a, b) => {
    if (a.createdAt !== b.createdAt) {
      return a.createdAt < b.createdAt ? 1 : -1;
    }
    return a.id < b.id ? -1 : 1;
  });
}

function applyFilters(items, filters) {
  return items.filter((item) => {
    if (filters.status !== undefined && item.status !== filters.status) return false;
    if (filters.priority !== undefined && item.priority !== filters.priority) return false;
    return true;
  });
}

export function registerRoutes(app, store) {
  // REQ-001 등록
  app.post('/api/requests', async (req, res, next) => {
    try {
      const input = validateCreate(req.body);
      const now = new Date().toISOString();
      const item = {
        id: randomUUID(),
        title: input.title,
        description: input.description,
        requester: input.requester,
        assignee: input.assignee,
        priority: input.priority,
        status: 'received',
        createdAt: now,
        updatedAt: now,
      };
      const items = await store.mutate((current) => [...current, item]);
      const saved = items.find((it) => it.id === item.id);
      res.status(201).json(saved ?? item);
    } catch (err) {
      next(err);
    }
  });

  // REQ-002 목록·필터
  app.get('/api/requests', async (req, res, next) => {
    try {
      const filters = validateListFilters(req.query);
      const items = await store.read();
      const filtered = sortItems(applyFilters(items, filters));
      res.status(200).json({ items: filtered, total: filtered.length });
    } catch (err) {
      next(err);
    }
  });

  // REQ-003 상세 (기준 C: UUID 형식 검사를 조회보다 먼저)
  app.get('/api/requests/:id', async (req, res, next) => {
    try {
      const id = validateId(req.params.id);
      const items = await store.read();
      const item = items.find((it) => it.id === id);
      if (!item) {
        throw notFoundError('요청을 찾을 수 없습니다.');
      }
      res.status(200).json(item);
    } catch (err) {
      next(err);
    }
  });

  // REQ-005 수정: PATCH /api/requests/:id
  // - validatePatch: assignee/priority 중 하나 이상, 미허용 필드·빈 PATCH 400
  // - trim·정규화된 값과 기존 값이 모두 같으면 updatedAt 유지 + 저장 스킵(mutate에 동일 참조 반환)
  // - 실제 변경 시에만 updatedAt 갱신 후 원자적 저장
  // - 잘못된 UUID 400(기준 C), 형식 유효·미존재 404
  app.patch('/api/requests/:id', async (req, res, next) => {
    try {
      const id = validateId(req.params.id);
      const patch = validatePatch(req.body);
      const items = await store.mutate((current) => {
        const idx = current.findIndex((it) => it.id === id);
        if (idx === -1) {
          throw notFoundError('요청을 찾을 수 없습니다.');
        }
        const original = current[idx];
        let changed = false;
        const updated = { ...original };
        if (patch.assignee !== undefined && patch.assignee !== original.assignee) {
          updated.assignee = patch.assignee;
          changed = true;
        }
        if (patch.priority !== undefined && patch.priority !== original.priority) {
          updated.priority = patch.priority;
          changed = true;
        }
        if (!changed) {
          return current; // 동일 값: updatedAt 유지, 저장 스킵
        }
        updated.updatedAt = new Date().toISOString();
        const next = current.slice();
        next[idx] = updated;
        return next;
      });
      const item = items.find((it) => it.id === id);
      res.status(200).json(item);
    } catch (err) {
      next(err);
    }
  });

  // REQ-004 상태 변경: PATCH /api/requests/:id/status
  // - validatePatchStatus: status 필드 하나만 허용
  // - 동일 상태는 200 + 기존 updatedAt 유지 + 저장 스킵(mutate에 동일 참조 반환)
  // - 허용 전이(received→in_progress, in_progress→completed, completed→in_progress 재개)만 성공
  // - 나머지 전이는 409 INVALID_TRANSITION이며 저장 파일을 변경하지 않는다
  // - 잘못된 UUID 400(기준 C), 형식 유효·미존재 404
  app.patch('/api/requests/:id/status', async (req, res, next) => {
    try {
      const id = validateId(req.params.id);
      const { status } = validatePatchStatus(req.body);
      const items = await store.mutate((current) => {
        const idx = current.findIndex((it) => it.id === id);
        if (idx === -1) {
          throw notFoundError('요청을 찾을 수 없습니다.');
        }
        const original = current[idx];
        if (original.status === status) {
          return current; // 동일 상태: 200, updatedAt 유지, 저장 스킵
        }
        if (!ALLOWED_TRANSITIONS[original.status].includes(status)) {
          throw invalidTransitionError(
            `${original.status} 상태에서 ${status} 상태로 변경할 수 없습니다.`,
          );
        }
        const updated = { ...original, status, updatedAt: new Date().toISOString() };
        const next = current.slice();
        next[idx] = updated;
        return next;
      });
      const item = items.find((it) => it.id === id);
      res.status(200).json(item);
    } catch (err) {
      next(err);
    }
  });
}
