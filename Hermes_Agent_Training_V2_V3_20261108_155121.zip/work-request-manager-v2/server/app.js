// Express 앱 팩토리: tests/api.test.js 계약 — named export createApp(options)
// Supertest가 포트 없이 앱을 검사할 수 있도록 Express 앱 인스턴스를 반환한다.
// - dataFile 옵션이 전달되면 저장소에 그대로 전달 (기본 ./data/requests.json)
// - 잘못된 JSON 본문 → 400 VALIDATION_ERROR (REQ-007)
// - 중앙 오류 핸들러: {error:{code,message}} 형식, 스택·경로 노출 없음

import express from 'express';
import { createStore } from './store.js';
import { registerRoutes } from './routes.js';
import { toErrorResponse, validationError, notFoundError } from './errors.js';

export function createApp(options = {}) {
  const app = express();
  const store = createStore({ dataFile: options.dataFile });

  app.disable('x-powered-by');
  app.use(express.json());

  // JSON 파서 오류 (잘못된 JSON 본문) → 400 VALIDATION_ERROR
  app.use((err, req, res, next) => {
    if (err && (err.type === 'entity.parse.failed' || err instanceof SyntaxError)) {
      next(validationError('잘못된 JSON 형식입니다.'));
      return;
    }
    next(err);
  });

  registerRoutes(app, store);

  // 알 수 없는 경로 → 404 NOT_FOUND
  app.use((req, res, next) => {
    next(notFoundError('요청 경로를 찾을 수 없습니다.'));
  });

  // 중앙 오류 핸들러: 오류 형식 {error:{code,message}}, 스택·경로 노출 없음
  // eslint-disable-next-line no-unused-vars
  app.use((err, req, res, next) => {
    const { status, body } = toErrorResponse(err);
    res.status(status).json(body);
  });

  return app;
}

export default createApp;
