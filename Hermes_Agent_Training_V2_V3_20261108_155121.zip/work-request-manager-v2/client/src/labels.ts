// 상태·우선순위 한국어 표시 (docs/specification.md "UI": API는 영문 enum, UI는 한국어)
import type { Priority, Status } from './types';

export const STATUS_LABEL: Record<Status, string> = {
  received: '접수',
  in_progress: '진행 중',
  completed: '완료',
};

export const PRIORITY_LABEL: Record<Priority, string> = {
  low: '낮음',
  medium: '보통',
  high: '높음',
};

export const STATUS_OPTIONS: Status[] = ['received', 'in_progress', 'completed'];
export const PRIORITY_OPTIONS: Priority[] = ['low', 'medium', 'high'];

// UTC ISO 8601 문자열 → 한국어 가독 표시 (로컬 시각으로 변환)
export function formatDateTime(iso: string): string {
  const date = new Date(iso);
  if (Number.isNaN(date.getTime())) return iso;
  return new Intl.DateTimeFormat('ko-KR', {
    year: 'numeric',
    month: '2-digit',
    day: '2-digit',
    hour: '2-digit',
    minute: '2-digit',
    second: '2-digit',
  }).format(date);
}
