// WF-01 목록 화면: GET /api/requests, 상태·우선순위 필터 동시 적용(AND),
// total = 필터 후 개수(기준 A), 로딩·빈 목록·오류·재시도 구분,
// 제목 클릭 → 상세, 모바일 카드 목록(동일 정보·조작).
import { useCallback, useEffect, useState } from 'react';
import { ApiError, listRequests } from '../api';
import { PRIORITY_LABEL, PRIORITY_OPTIONS, STATUS_LABEL, STATUS_OPTIONS, formatDateTime } from '../labels';
import type { ListFilters, WorkRequest } from '../types';

type LoadState =
  | { kind: 'loading' }
  | { kind: 'error'; message: string }
  | { kind: 'loaded'; items: WorkRequest[]; total: number };

function statusBadge(status: WorkRequest['status']) {
  return <span className={`badge badge--${status}`}>{STATUS_LABEL[status]}</span>;
}

function priorityBadge(priority: WorkRequest['priority']) {
  return <span className={`badge badge--priority-${priority}`}>{PRIORITY_LABEL[priority]}</span>;
}

function RequestTitleLink({ request, onNavigate }: { request: WorkRequest; onNavigate: (hash: string) => void }) {
  return (
    <button
      type="button"
      className="request-title-link"
      onClick={() => onNavigate(`#/requests/${encodeURIComponent(request.id)}`)}
    >
      {request.title}
    </button>
  );
}

interface Props {
  onNavigate: (hash: string) => void;
}

export function RequestList({ onNavigate }: Props) {
  const [filters, setFilters] = useState<ListFilters>({});
  const [state, setState] = useState<LoadState>({ kind: 'loading' });
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setState({ kind: 'loading' });
    listRequests(filters)
      .then((result) => {
        if (!cancelled) setState({ kind: 'loaded', items: result.items, total: result.total });
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          const message = error instanceof ApiError ? error.message : '요청을 불러오는 중 오류가 발생했습니다.';
          setState({ kind: 'error', message });
        }
      });
    return () => {
      cancelled = true;
    };
  }, [filters, reloadKey]);

  const onFilterChange = useCallback((next: ListFilters) => {
    setFilters(next);
  }, []);

  const onRetry = useCallback(() => {
    setReloadKey((key) => key + 1);
  }, []);

  return (
    <section aria-label="요청 목록">
      <div className="filter-bar">
        <label htmlFor="filter-status">
          상태
          <select
            id="filter-status"
            value={filters.status ?? ''}
            onChange={(event) => {
              const value = event.target.value;
              onFilterChange({ ...filters, status: value === '' ? undefined : (value as ListFilters['status']) });
            }}
          >
            <option value="">전체</option>
            {STATUS_OPTIONS.map((status) => (
              <option key={status} value={status}>
                {STATUS_LABEL[status]}
              </option>
            ))}
          </select>
        </label>
        <label htmlFor="filter-priority">
          우선순위
          <select
            id="filter-priority"
            value={filters.priority ?? ''}
            onChange={(event) => {
              const value = event.target.value;
              onFilterChange({ ...filters, priority: value === '' ? undefined : (value as ListFilters['priority']) });
            }}
          >
            <option value="">전체</option>
            {PRIORITY_OPTIONS.map((priority) => (
              <option key={priority} value={priority}>
                {PRIORITY_LABEL[priority]}
              </option>
            ))}
          </select>
        </label>
        <span className="filter-bar__total">총 {state.kind === 'loaded' ? state.total : 0}건</span>
      </div>

      {state.kind === 'loading' && (
        <div className="state" role="status">로딩 중…</div>
      )}

      {state.kind === 'error' && (
        <div className="state state--error" role="alert">
          <p>요청 목록을 불러오지 못했습니다. {state.message}</p>
          <button type="button" className="btn" onClick={onRetry}>재시도</button>
        </div>
      )}

      {state.kind === 'loaded' && state.items.length === 0 && (
        <div className="state" role="status">결과 없음</div>
      )}

      {state.kind === 'loaded' && state.items.length > 0 && (
        <>
          <div className="table-wrap">
            <table>
              <thead>
                <tr>
                  <th scope="col">ID</th>
                  <th scope="col">제목</th>
                  <th scope="col">상태</th>
                  <th scope="col">우선순위</th>
                  <th scope="col">담당자</th>
                  <th scope="col">생성 시각</th>
                </tr>
              </thead>
              <tbody>
                {state.items.map((request) => (
                  <tr key={request.id}>
                    <td>{request.id}</td>
                    <td>
                      <RequestTitleLink request={request} onNavigate={onNavigate} />
                    </td>
                    <td>{statusBadge(request.status)}</td>
                    <td>{priorityBadge(request.priority)}</td>
                    <td>{request.assignee}</td>
                    <td>{formatDateTime(request.createdAt)}</td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>

          <div className="card-list">
            {state.items.map((request) => (
              <div className="card" key={request.id}>
                <RequestTitleLink request={request} onNavigate={onNavigate} />
                <dl>
                  <dt>ID</dt>
                  <dd>{request.id}</dd>
                  <dt>상태</dt>
                  <dd>{statusBadge(request.status)}</dd>
                  <dt>우선순위</dt>
                  <dd>{priorityBadge(request.priority)}</dd>
                  <dt>담당자</dt>
                  <dd>{request.assignee}</dd>
                  <dt>생성 시각</dt>
                  <dd>{formatDateTime(request.createdAt)}</dd>
                </dl>
              </div>
            ))}
          </div>
        </>
      )}
    </section>
  );
}
