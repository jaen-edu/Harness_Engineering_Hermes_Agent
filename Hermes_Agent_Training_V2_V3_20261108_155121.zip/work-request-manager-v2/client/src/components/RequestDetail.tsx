// WF-03 상세/수정 화면: GET /api/requests/{id}, PATCH /api/requests/{id},
// PATCH /api/requests/{id}/status (REQ-004/005)
// - 제목 heading의 접근 가능한 이름은 '요청 상세'
// - 제목·설명·요청자·생성/수정 시각은 읽기 전용 표시
// - 담당자 입력, 우선순위 라디오(가로 정렬), 저장 버튼으로 PATCH /{id}
// - 현재 상태 표시 + 허용된 다음 상태 선택 + 상태 변경 버튼으로 PATCH /{id}/status
//   (completed는 in_progress 선택으로 재개)
// - 실패 시 입력값과 기존 상세 데이터를 유지하고 오류를 안내, 중복 제출 방지
// - 성공 시 서버 응답(전체 WorkRequest)으로 화면 갱신
// - 잘못된 UUID는 400, 형식 유효·미존재는 404로 서버가 판정한다(기준 C)
import { useCallback, useEffect, useState } from 'react';
import { ApiError, getRequest, updateRequest, updateRequestStatus } from '../api';
import { PRIORITY_LABEL, PRIORITY_OPTIONS, STATUS_LABEL, formatDateTime } from '../labels';
import type { Priority, Status, WorkRequest } from '../types';

type LoadState =
  | { kind: 'loading' }
  | { kind: 'not-found' }
  | { kind: 'error'; message: string }
  | { kind: 'loaded'; request: WorkRequest };

// 상태 전이표 (docs/specification.md): 허용된 다음 상태만 선택지로 제공
const NEXT_STATUS: Record<Status, Status[]> = {
  received: ['in_progress'],
  in_progress: ['completed'],
  completed: ['in_progress'], // 재개
};

// 코드 포인트 기준 길이 (서버와 동일)
function codePointLength(value: string): number {
  return Array.from(value).length;
}

interface Props {
  id: string;
  onNavigate: (hash: string) => void;
}

export function RequestDetail({ id, onNavigate }: Props) {
  const [state, setState] = useState<LoadState>({ kind: 'loading' });
  const [reloadKey, setReloadKey] = useState(0);

  // 수정 폼: 담당자·우선순위
  const [assignee, setAssignee] = useState('');
  const [priority, setPriority] = useState<Priority>('medium');
  const [editErrors, setEditErrors] = useState<Partial<Record<'assignee' | 'priority', string>>>({});
  const [editError, setEditError] = useState<string | null>(null);
  const [savingEdit, setSavingEdit] = useState(false);

  // 상태 변경 폼
  const [nextStatus, setNextStatus] = useState<Status | ''>('');
  const [statusError, setStatusError] = useState<string | null>(null);
  const [savingStatus, setSavingStatus] = useState(false);

  useEffect(() => {
    let cancelled = false;
    setState({ kind: 'loading' });
    getRequest(id)
      .then((request) => {
        if (cancelled) return;
        setState({ kind: 'loaded', request });
        setAssignee(request.assignee);
        setPriority(request.priority);
        setNextStatus('');
        setEditErrors({});
        setEditError(null);
        setStatusError(null);
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          if (error instanceof ApiError && error.status === 404) {
            setState({ kind: 'not-found' });
          } else {
            const message = error instanceof ApiError ? error.message : '요청을 불러오는 중 오류가 발생했습니다.';
            setState({ kind: 'error', message });
          }
        }
      });
    return () => {
      cancelled = true;
    };
  }, [id, reloadKey]);

  const onRetry = useCallback(() => {
    setReloadKey((key) => key + 1);
  }, []);

  const validateEdit = useCallback((): Partial<Record<'assignee' | 'priority', string>> => {
    const errors: Partial<Record<'assignee' | 'priority', string>> = {};
    const trimmed = assignee.trim();
    if (trimmed.length === 0) {
      errors.assignee = '담당자는 필수입니다.';
    } else if (codePointLength(trimmed) > 60) {
      errors.assignee = '담당자는 60자(코드 포인트) 이내여야 합니다.';
    }
    return errors;
  }, [assignee]);

  // 저장: PATCH /api/requests/{id} (assignee + priority)
  const onSaveEdit = useCallback(
    (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      if (savingEdit) return; // 중복 제출 방지
      if (state.kind !== 'loaded') return;
      const errors = validateEdit();
      if (Object.keys(errors).length > 0) {
        setEditErrors(errors);
        return;
      }
      setEditErrors({});
      setEditError(null);
      setSavingEdit(true);
      updateRequest(id, { assignee: assignee.trim(), priority })
        .then((updated) => {
          setState({ kind: 'loaded', request: updated });
          setSavingEdit(false);
        })
        .catch((error: unknown) => {
          // 입력값(assignee·priority)과 기존 상세 데이터는 유지된다
          setEditError(error instanceof ApiError ? error.message : '요청 수정 중 오류가 발생했습니다.');
          setSavingEdit(false);
        });
    },
    [savingEdit, state, id, assignee, priority, validateEdit],
  );

  // 상태 변경: PATCH /api/requests/{id}/status
  const onChangeStatus = useCallback(
    (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      if (savingStatus) return; // 중복 제출 방지
      if (nextStatus === '') return;
      setStatusError(null);
      setSavingStatus(true);
      updateRequestStatus(id, { status: nextStatus })
        .then((updated) => {
          setState({ kind: 'loaded', request: updated });
          setNextStatus('');
          setSavingStatus(false);
        })
        .catch((error: unknown) => {
          // 기존 상세 데이터와 상태 선택은 유지된다
          setStatusError(error instanceof ApiError ? error.message : '상태 변경 중 오류가 발생했습니다.');
          setSavingStatus(false);
        });
    },
    [savingStatus, id, nextStatus],
  );

  return (
    <section aria-label="요청 상세">
      <p>
        <button type="button" className="btn" onClick={() => onNavigate('#/')}>
          목록으로
        </button>
      </p>

      {state.kind === 'loading' && (
        <div className="state" role="status">로딩 중…</div>
      )}

      {state.kind === 'not-found' && (
        <div className="state state--error" role="alert">
          <p>요청을 찾을 수 없습니다.</p>
          <button type="button" className="btn" onClick={onRetry}>재시도</button>
        </div>
      )}

      {state.kind === 'error' && (
        <div className="state state--error" role="alert">
          <p>요청을 불러오지 못했습니다. {state.message}</p>
          <button type="button" className="btn" onClick={onRetry}>재시도</button>
        </div>
      )}

      {state.kind === 'loaded' && (
        <div className="detail">
          <h2 className="detail__heading">요청 상세</h2>
          <div className="detail__section">
            <dl>
              <dt>제목</dt>
              <dd>{state.request.title}</dd>
              <dt>설명</dt>
              <dd>{state.request.description}</dd>
              <dt>요청자</dt>
              <dd>{state.request.requester}</dd>
              <dt>생성 시각</dt>
              <dd>{formatDateTime(state.request.createdAt)}</dd>
              <dt>수정 시각</dt>
              <dd>{formatDateTime(state.request.updatedAt)}</dd>
            </dl>
          </div>

          {/* 수정: 담당자·우선순위 (REQ-005) */}
          <div className="detail__section detail-panel">
            <h2>수정</h2>
            {editError !== null && (
              <div className="state state--error" role="alert">
                <p>{editError}</p>
              </div>
            )}
            <form className="form" onSubmit={onSaveEdit} noValidate>
              <div className="field">
                <label className="field__label" htmlFor="f-detail-assignee">
                  담당자 <span className="field__required" aria-hidden="true">*</span>
                </label>
                <input
                  id="f-detail-assignee"
                  name="assignee"
                  type="text"
                  value={assignee}
                  onChange={(event) => setAssignee(event.target.value)}
                  aria-invalid={editErrors.assignee !== undefined ? true : undefined}
                  aria-describedby={editErrors.assignee !== undefined ? 'error-detail-assignee' : undefined}
                  aria-required="true"
                />
                <p className="field__hint">60자(코드 포인트) 이내</p>
                {editErrors.assignee !== undefined && (
                  <p className="field__error" id="error-detail-assignee" role="alert">
                    {editErrors.assignee}
                  </p>
                )}
              </div>

              <div className="field">
                <span className="field__label" id="detail-priority-label">
                  우선순위 <span className="field__required" aria-hidden="true">*</span>
                </span>
                <div
                  className="priority-group"
                  role="radiogroup"
                  aria-labelledby="detail-priority-label"
                >
                  {PRIORITY_OPTIONS.map((option) => (
                    <label className="priority-group__item" key={option}>
                      <input
                        type="radio"
                        name="priority"
                        value={option}
                        id={`f-detail-priority-${option}`}
                        checked={priority === option}
                        onChange={() => setPriority(option)}
                      />
                      {PRIORITY_LABEL[option]}
                    </label>
                  ))}
                </div>
              </div>

              <div className="form__actions">
                <button type="submit" className="btn btn--primary" disabled={savingEdit}>
                  {savingEdit ? '저장 중…' : '저장'}
                </button>
              </div>
            </form>
          </div>

          {/* 상태 변경 (REQ-004): 허용된 다음 상태만 선택 가능 */}
          <div className="detail__section detail-panel">
            <h2>상태 변경</h2>
            <dl>
              <dt>현재 상태</dt>
              <dd>
                <span className={`badge badge--${state.request.status}`}>
                  {STATUS_LABEL[state.request.status]}
                </span>
              </dd>
            </dl>
            {statusError !== null && (
              <div className="state state--error" role="alert">
                <p>{statusError}</p>
              </div>
            )}
            <form className="form" onSubmit={onChangeStatus} noValidate>
              <div className="field">
                <label className="field__label" htmlFor="f-detail-status">
                  다음 상태
                </label>
                <select
                  id="f-detail-status"
                  name="status"
                  value={nextStatus}
                  onChange={(event) => {
                    const value = event.target.value;
                    setNextStatus(value === '' ? '' : (value as Status));
                  }}
                >
                  <option value="">선택하세요</option>
                  {NEXT_STATUS[state.request.status].map((option) => (
                    <option key={option} value={option}>
                      {STATUS_LABEL[option]}
                      {state.request.status === 'completed' && option === 'in_progress'
                        ? ' (재개)'
                        : ''}
                    </option>
                  ))}
                </select>
                {state.request.status === 'completed' && (
                  <p className="field__hint">완료된 요청은 진행 중 상태로 재개할 수 있습니다.</p>
                )}
              </div>
              <div className="form__actions">
                <button
                  type="submit"
                  className="btn btn--primary"
                  disabled={savingStatus || nextStatus === ''}
                >
                  {savingStatus ? '변경 중…' : '상태 변경'}
                </button>
              </div>
            </form>
          </div>
        </div>
      )}
    </section>
  );
}
