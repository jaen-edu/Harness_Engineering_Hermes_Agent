// WF-02 요청 등록 화면: POST /api/requests
// - 제목 input id=f-title name=title, 설명 textarea id=f-description name=description,
//   요청자 input id=f-requester name=requester, 담당자 input id=f-assignee name=assignee
// - 우선순위 radio 3개 name=priority, 한국어 라벨
// - 제출 버튼 type=submit, 접근 가능한 이름에 '등록' 포함
// - 계약 검증: 필수·문자 길이(코드 포인트)·공백 trim, 오류는 필드에 연결
// - 제출 중 재클릭·Enter 중복 제출 방지, 오류 시 입력 유지
// - 201 성공 시 요청 상세 화면으로 이동
import { useCallback, useState } from 'react';
import { ApiError, createRequest } from '../api';
import { PRIORITY_LABEL, PRIORITY_OPTIONS } from '../labels';
import type { CreateRequestInput, Priority } from '../types';

type FieldName = 'title' | 'description' | 'requester' | 'assignee' | 'priority';

interface FormValues {
  title: string;
  description: string;
  requester: string;
  assignee: string;
  priority: Priority;
}

const INITIAL_VALUES: FormValues = {
  title: '',
  description: '',
  requester: '',
  assignee: '',
  priority: 'medium',
};

// 코드 포인트 기준 길이 (서버와 동일: UTF-16 코드 단위가 아닌 코드 포인트)
function codePointLength(value: string): number {
  return Array.from(value).length;
}

// 계약 검증 (schemas/request.schema.json, docs/specification.md "생성"):
// title 1~100, requester/assignee 1~60, description 0~2000, priority enum.
// trim 후 길이 검사. 오류는 필드별로 반환.
function validate(values: FormValues): Partial<Record<FieldName, string>> {
  const errors: Partial<Record<FieldName, string>> = {};
  const title = values.title.trim();
  if (title.length === 0) {
    errors.title = '제목은 필수입니다.';
  } else if (codePointLength(title) > 100) {
    errors.title = '제목은 100자(코드 포인트) 이내여야 합니다.';
  }
  const description = values.description.trim();
  if (codePointLength(description) > 2000) {
    errors.description = '설명은 2000자(코드 포인트) 이내여야 합니다.';
  }
  const requester = values.requester.trim();
  if (requester.length === 0) {
    errors.requester = '요청자는 필수입니다.';
  } else if (codePointLength(requester) > 60) {
    errors.requester = '요청자는 60자(코드 포인트) 이내여야 합니다.';
  }
  const assignee = values.assignee.trim();
  if (assignee.length === 0) {
    errors.assignee = '담당자는 필수입니다.';
  } else if (codePointLength(assignee) > 60) {
    errors.assignee = '담당자는 60자(코드 포인트) 이내여야 합니다.';
  }
  return errors;
}

interface Props {
  onNavigate: (hash: string) => void;
}

export function RequestForm({ onNavigate }: Props) {
  const [values, setValues] = useState<FormValues>(INITIAL_VALUES);
  const [errors, setErrors] = useState<Partial<Record<FieldName, string>>>({});
  const [submitting, setSubmitting] = useState(false);
  const [formError, setFormError] = useState<string | null>(null);

  const setField = useCallback((field: keyof FormValues, value: string) => {
    setValues((current) => ({ ...current, [field]: value }));
  }, []);

  const onSubmit = useCallback(
    (event: React.FormEvent<HTMLFormElement>) => {
      event.preventDefault();
      if (submitting) return; // 중복 제출 방지 (재클릭·Enter)
      const nextErrors = validate(values);
      if (Object.keys(nextErrors).length > 0) {
        setErrors(nextErrors);
        return;
      }
      setErrors({});
      setFormError(null);
      setSubmitting(true);
      const input: CreateRequestInput = {
        title: values.title.trim(),
        description: values.description.trim(),
        requester: values.requester.trim(),
        assignee: values.assignee.trim(),
        priority: values.priority,
      };
      createRequest(input)
        .then((created) => {
          onNavigate(`#/requests/${encodeURIComponent(created.id)}`);
        })
        .catch((error: unknown) => {
          // 오류 시 입력 유지 (values는 그대로)
          setFormError(error instanceof ApiError ? error.message : '요청 등록 중 오류가 발생했습니다.');
          setSubmitting(false);
        });
    },
    [submitting, values, onNavigate],
  );

  const fieldError = (field: FieldName) => {
    const message = errors[field];
    if (message === undefined) return undefined;
    return (
      <p className="field__error" id={`error-${field}`} role="alert">
        {message}
      </p>
    );
  };

  const ariaInvalid = (field: FieldName) => (errors[field] !== undefined ? true : undefined);
  const ariaDescribedBy = (field: FieldName) => (errors[field] !== undefined ? `error-${field}` : undefined);

  return (
    <section aria-label="요청 등록">
      <p>
        <button type="button" className="btn" onClick={() => onNavigate('#/')}>
          목록으로
        </button>
      </p>
      <h2>새 업무 요청</h2>
      {formError !== null && (
        <div className="state state--error" role="alert">
          <p>{formError}</p>
        </div>
      )}
      <form className="form" onSubmit={onSubmit} noValidate>
        <div className="field">
          <label className="field__label" htmlFor="f-title">
            제목 <span className="field__required" aria-hidden="true">*</span>
          </label>
          <input
            id="f-title"
            name="title"
            type="text"
            value={values.title}
            onChange={(event) => setField('title', event.target.value)}
            aria-invalid={ariaInvalid('title')}
            aria-describedby={ariaDescribedBy('title')}
            aria-required="true"
          />
          <p className="field__hint">100자(코드 포인트) 이내</p>
          {fieldError('title')}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="f-description">
            설명
          </label>
          <textarea
            id="f-description"
            name="description"
            value={values.description}
            onChange={(event) => setField('description', event.target.value)}
            aria-invalid={ariaInvalid('description')}
            aria-describedby={ariaDescribedBy('description')}
          />
          <p className="field__hint">2000자(코드 포인트) 이내</p>
          {fieldError('description')}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="f-requester">
            요청자 <span className="field__required" aria-hidden="true">*</span>
          </label>
          <input
            id="f-requester"
            name="requester"
            type="text"
            value={values.requester}
            onChange={(event) => setField('requester', event.target.value)}
            aria-invalid={ariaInvalid('requester')}
            aria-describedby={ariaDescribedBy('requester')}
            aria-required="true"
          />
          <p className="field__hint">60자(코드 포인트) 이내</p>
          {fieldError('requester')}
        </div>

        <div className="field">
          <label className="field__label" htmlFor="f-assignee">
            담당자 <span className="field__required" aria-hidden="true">*</span>
          </label>
          <input
            id="f-assignee"
            name="assignee"
            type="text"
            value={values.assignee}
            onChange={(event) => setField('assignee', event.target.value)}
            aria-invalid={ariaInvalid('assignee')}
            aria-describedby={ariaDescribedBy('assignee')}
            aria-required="true"
          />
          <p className="field__hint">60자(코드 포인트) 이내</p>
          {fieldError('assignee')}
        </div>

        <div className="field">
          <span className="field__label" id="priority-label">
            우선순위 <span className="field__required" aria-hidden="true">*</span>
          </span>
          <div className="radio-group" role="radiogroup" aria-labelledby="priority-label">
            {PRIORITY_OPTIONS.map((priority) => (
              <label className="radio-group__item" key={priority}>
                <input
                  type="radio"
                  name="priority"
                  value={priority}
                  id={`f-priority-${priority}`}
                  checked={values.priority === priority}
                  onChange={() => setField('priority', priority)}
                  aria-invalid={ariaInvalid('priority')}
                  aria-describedby={ariaDescribedBy('priority')}
                />
                {PRIORITY_LABEL[priority]}
              </label>
            ))}
          </div>
          {fieldError('priority')}
        </div>

        <div className="form__actions">
          <button type="button" className="btn" onClick={() => onNavigate('#/')}>
            취소
          </button>
          <button type="submit" className="btn btn--primary" disabled={submitting}>
            {submitting ? '등록 중…' : '요청 등록'}
          </button>
        </div>
      </form>
    </section>
  );
}
