// API 클라이언트: Vite 프록시(/api → http://localhost:3001)를 사용하는 상대 경로
// 오류 형식 {error:{code,message}} 파싱 (REQ-007)
import type {
  ApiErrorBody,
  CreateRequestInput,
  ListFilters,
  UpdateRequestInput,
  UpdateRequestStatusInput,
  WorkRequest,
  WorkRequestList,
} from './types';
import { isApiErrorBody } from './types';

export class ApiError extends Error {
  readonly status: number;
  readonly code: string;
  constructor(status: number, code: string, message: string) {
    super(message);
    this.name = 'ApiError';
    this.status = status;
    this.code = code;
  }
}

async function request<T>(url: string, init?: RequestInit): Promise<T> {
  let response: Response;
  try {
    response = await fetch(url, init);
  } catch {
    // 네트워크 오류 (fetch 실패): 오류 본문 없음
    throw new ApiError(0, 'NETWORK_ERROR', '서버에 연결할 수 없습니다.');
  }
  const text = await response.text();
  let body: unknown = undefined;
  if (text.length > 0) {
    try {
      body = JSON.parse(text);
    } catch {
      body = undefined;
    }
  }
  if (!response.ok) {
    if (isApiErrorBody(body)) {
      throw new ApiError(response.status, body.error.code, body.error.message);
    }
    throw new ApiError(response.status, 'INTERNAL_ERROR', '서버 오류가 발생했습니다.');
  }
  return body as T;
}

export function listRequests(filters: ListFilters = {}): Promise<WorkRequestList> {
  const params = new URLSearchParams();
  if (filters.status !== undefined) params.set('status', filters.status);
  if (filters.priority !== undefined) params.set('priority', filters.priority);
  const query = params.toString();
  return request<WorkRequestList>(`/api/requests${query ? `?${query}` : ''}`);
}

export function getRequest(id: string): Promise<WorkRequest> {
  return request<WorkRequest>(`/api/requests/${encodeURIComponent(id)}`);
}

export function createRequest(input: CreateRequestInput): Promise<WorkRequest> {
  return request<WorkRequest>('/api/requests', {
    method: 'POST',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
}

// REQ-005: 담당자·우선순위 수정. 성공 시 갱신된 전체 WorkRequest 반환.
export function updateRequest(id: string, input: UpdateRequestInput): Promise<WorkRequest> {
  return request<WorkRequest>(`/api/requests/${encodeURIComponent(id)}`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
}

// REQ-004: 상태 변경. 성공 시 갱신된 전체 WorkRequest 반환.
export function updateRequestStatus(
  id: string,
  input: UpdateRequestStatusInput,
): Promise<WorkRequest> {
  return request<WorkRequest>(`/api/requests/${encodeURIComponent(id)}/status`, {
    method: 'PATCH',
    headers: { 'Content-Type': 'application/json' },
    body: JSON.stringify(input),
  });
}
