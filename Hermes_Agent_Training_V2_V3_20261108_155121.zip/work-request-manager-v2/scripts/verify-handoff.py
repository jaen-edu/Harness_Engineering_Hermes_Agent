#!/usr/bin/env python3
"""Validate the Hermes Agent handoff document."""
import argparse
from pathlib import Path

REQUIRED = [
    "프로젝트 상태",
    "완료된 작업",
    "검증 결과",
    "미해결 문제",
    "다음 작업",
]

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--root", default=".")
    args = parser.parse_args()

    root = Path(args.root)
    errors = []

    for name in ("AGENTS.md", "progress.md", "handoff.md"):
        if not (root / name).is_file():
            errors.append(f"Missing: {name}")

    handoff = root / "handoff.md"
    if handoff.is_file():
        text = handoff.read_text(encoding="utf-8-sig")
        for heading in REQUIRED:
            if not any(
                line.startswith("## ") and heading in line
                for line in text.splitlines()
            ):
                errors.append(f"Missing section: {heading}")
        if "미작성" in text:
            errors.append("Unfilled placeholder")

    if errors:
        for error in errors:
            print("FAIL:", error)
        return 1

    print("Handoff structure: PASS")
    return 0

if __name__ == "__main__":
    raise SystemExit(main())
