# Chat 인계 문서

## 프로젝트 상태

- AI Work Request Manager 2.0 — 제6교시 Implementation(REQ-004/005 PATCH, 상세 수정·상태 변경 UI) 구현·검증 완료. 다음 교시 지시 대기 단계다.
- 제1교시(Harness 로드·변경 통제 판정), 제2교시(개발 환경 구축·Smoke Test), 제3교시(고정 Baseline 7개 자산 분석), 제4교시(명세 해석 확정·구현·검증 계획 작성), 제5교시(Backend·Frontend 등록·목록·상세 구현), 제6교시(REQ-004/005 PATCH·상세 수정 UI) 완료.
- tests/api.test.js·tests/api-contract.test.js는 배치됨. 제6교시에서 고정 API 테스트 17/17 PASS가 사용자 제공 출력으로 확인되었으며, 그 실행 결과는 사용자 제공 로그에 근거한 기록이다(Hermes 직접 실행 아님).
- 수정 허용 영역: client/, server/, plans/, progress.md, handoff.md. 그 외 경로는 사전 보고·승인 필요 (AGENTS.md §3).
- 고정 Baseline(docs/, specs/, contracts/, schemas/, design/, traceability/, tests/, e2e/, scripts/)은 읽기만 가능하며 수정 금지다 (AGENTS.md §2).

## 계획 파일 (제4교시 작성, Planning 산출물)

| 경로 | 역할 |
|---|---|
| /workspace/plans/implementation-plan.md | 구현 계획: 목표·범위·제외, 수정 금지/허용 영역, REQ-001~008 작업 분해와 대응 AC, server/(저장소→유효성·오류→상태 전이→라우트→index.js)·client/(공통 기반→목록→등록→상세/수정→접근성) 구현 순서, 예정 파일 책임, 완료 조건, 다음 우선순위 |
| /workspace/plans/verification-plan.md | 검증 계획: AC-001~014 검증 대상·방법, AGENTS.md §10 검증 순서, package.json 실제 명령, §6 반복 한도 3회, 증거 기록 원칙, tests/·e2e/ 미제공·미실행 명시, 테스트 배치 후 기준 A·C 기대값 비교 절차 |

## 승인된 구현 기준 (사용자 확정, 제4교시)

- A. GET /api/requests의 `total`은 상태·우선순위 필터 적용 후 반환되는 항목 수(items.length)로 계산한다.
- B. 키보드 포커스는 기존 `primary` 디자인 토큰과 브라우저 기본 포커스 동작을 활용하며, 디자인 토큰 파일(design/tokens.json)은 변경하지 않는다.
- C. 잘못된 UUID 형식의 요청 ID는 HTTP 400 `VALIDATION_ERROR`, 형식은 유효하지만 존재하지 않는 ID는 HTTP 404 `NOT_FOUND`로 처리한다 (형식 검사를 조회보다 먼저 적용).
- 이는 구현 기준의 확정이며 고정 Baseline 파일 변경 승인이 아니다. 과거 미해결 해석 3건은 이 승인으로 해소됨.

## 고정 Baseline 자산 목록 (경로와 역할)

| 경로 | 역할 |
|---|---|
| AGENTS.md | 공통 Harness 규칙(수정 영역, 변경 통제, 검증 순서, 인계) |
| docs/project-overview.md | 프로젝트 목적·범위·기술 기준·완료 기준 |
| specs/requirements.md | 요구사항 Baseline REQ-001~008 + 공통 조건 |
| docs/specification.md | 상세 명세(데이터 필드·전이·수정·목록·저장·오류·UI·테스트 분리) |
| specs/acceptance-criteria.md | 인수 기준 AC-001~014 |
| contracts/openapi.json | API 계약(5개 엔드포인트, localhost:3001, Error 스키마) |
| schemas/request.schema.json | WorkRequest 데이터 스키마(OpenAPI와 동일) |
| design/wireframes.md | 화면 구조 WF-01 목록·WF-02 등록·WF-03 상세/수정 + 공통 UI 계약 |
| design/tokens.json | 디자인 토큰(색 9·간격 6·radius 2·타이포그래피·contentMaxWidth) |

## 완료된 작업

- 제1교시: Starter 적용, Harness 규칙 로드, 수정 허용/금지 영역 구분, Closed-loop 개선 규칙 확인, AGENTS.md ↔ 프로젝트 개요 충돌 없음 확인, 변경 통제 시나리오 A(허용)/B(금지)/C(사전 승인 필요) 판정.
- 제2교시: 개발 환경 구축 및 브라우저 Smoke Test 완료.
- 제3교시: 고정 자산 7개 실제 읽기·분석. REQ-001~008 ↔ AC-001~014 대응 관계 확인(전 커버, 누락 없음). API 엔드포인트·스키마·화면·토큰 정리. REQ–AC 추적표와 구현 필수 규칙 요약 작성. 계약 문서 간 명백한 모순 없음 확인.
- 제4교시: 구현 기준 A·B·C 사용자 확정, 확정 기준의 REQ/API/UI 영향 범위 정리, 구현 계획과 검증 계획 작성(plans/ 두 파일만 생성), REQ 8개·AC 14개 계획 포함 재독 확인.
- 제5교시: tests/api.test.js의 createApp({dataFile}) 계약 확인. Backend server/ 6파일 생성(app.js, index.js, store.js, validate.js, errors.js, routes.js): POST 등록, GET 목록·필터, GET 상세, 공통 입력 검증·오류·JSON 저장(기본 ./data/requests.json, 상위 디렉터리 생성, rename 원자적 교체, 손상 파일 보존, 읽기→수정→쓰기 전체 직렬화). Frontend client/src 9파일 생성(types.ts, labels.ts, api.ts, styles.css, main.tsx, App.tsx, components/RequestList.tsx, RequestForm.tsx, RequestDetail.tsx): React 18 + TypeScript(strict) + Vite 6, 라우터 라이브러리 없이 해시 기반 화면 전환, WF-01 목록·WF-02 등록·WF-03 읽기 전용 상세. 승인된 구현 기준 A·B·C 유지, 고정 Baseline 무변경.

## 제5교시 구현 파일 (server/·client/)

| 경로 | 역할 |
|---|---|
| server/app.js | named export createApp(options), JSON 파서 오류→400, 중앙 오류 핸들러 |
| server/index.js | 포트 3001, DATA_FILE 환경변수 우선 전달 |
| server/store.js | 기본 ./data/requests.json, 상위 디렉터리 생성, rename 원자적 교체, 손상 파일 500·보존, 읽기→수정→쓰기 전체 직렬화 큐 |
| server/validate.js | trim 후 코드 포인트 길이·enum·UUID v4 형식 검사(기준 C) |
| server/errors.js | 오류 형식 {error:{code,message}} 4종 코드 |
| server/routes.js | POST /api/requests, GET /api/requests, GET /api/requests/:id |
| client/src/types.ts | WorkRequest·ListFilters·ApiErrorBody 타입 |
| client/src/labels.ts | 상태·우선순위 한국어 표시(접수/진행 중/완료, 낮음/보통/높음), 시각 포맷 |
| client/src/api.ts | fetch 래퍼(/api 상대 경로, Vite 프록시), 오류 파싱 |
| client/src/styles.css | tokens.json 값과 1:1 CSS 변수, :focus-visible + primary |
| client/src/main.tsx, App.tsx | 진입점, 해시 기반 화면 전환(#/ 목록, #/new 등록, #/requests/:id 상세) |
| client/src/components/RequestList.tsx | WF-01 목록(AND 필터, total=필터 후 개수, 로딩·빈 목록·오류·재시도 구분, 모바일 카드 목록) |
| client/src/components/RequestForm.tsx | WF-02 등록(f-title/f-description/f-requester/f-assignee, priority radio 3개, 중복 제출 방지, 오류 시 입력 유지, 201 성공 시 상세 이동) |
| client/src/components/RequestDetail.tsx | WF-03 읽기 전용 상세('요청 상세' heading, 로딩·404·네트워크 오류 구분, 목록으로 버튼) |

## 제6교시 구현 내역 (server/·client/)

| 경로 | 제6교시 변경 |
|---|---|
| server/validate.js | validatePatch(assignee/priority 1개 이상, 미허용·빈 PATCH 400), validatePatchStatus(status만 허용), ALLOWED_TRANSITIONS 전이표 추가 |
| server/routes.js | PATCH /api/requests/:id(REQ-005), PATCH /api/requests/:id/status(REQ-004) 추가. mutate 내 읽기→판정→수정, 동일 값/동일 상태는 동일 참조 반환으로 updatedAt 유지+저장 스킵, 불허 전이 409 INVALID_TRANSITION, 잘못된 UUID 400/유효·미존재 404(기준 C) |
| server/store.js | mutate에 저장 스킵 경로 추가(fn 반환값이 입력 배열과 동일 참조면 재기록 없이 반환) — 직렬화 큐·원자적 rename 저장·손상 파일 보존은 무변경 |
| client/src/types.ts | UpdateRequestInput·UpdateRequestStatusInput 추가 |
| client/src/api.ts | updateRequest·updateRequestStatus 추가(오류 파싱·Vite 프록시 재사용) |
| client/src/components/RequestDetail.tsx | 상세/수정 화면으로 확장: 읽기 전용 필드(제목·설명·요청자·생성/수정 시각), 담당자 input(f-detail-assignee), 우선순위 라디오(priority-group), 저장 버튼, 현재 상태 배지, 허용 다음 상태 select(completed→in_progress 재개 표기), 상태 변경 버튼, 실패 시 입력·기존 데이터 유지, 중복 제출 방지, 성공 시 서버 응답으로 갱신. "다음 교시 범위" 임시 주석 삭제 |
| client/src/styles.css | .detail-panel .priority-group 규칙 추가(flex·flex-wrap·label nowrap·input width:auto·accent-color) — 상세 패널 범위 한정. 요청 예시 변수명(--s-3/--s-2/--c-primary)은 프로젝트 실제 토큰(--spacing-3/--spacing-2/--color-primary)으로 매핑(기준 B, tokens.json 무변경) |
| client/src/App.tsx | "다음 교시" 임시 주석 삭제(WF-03 상세/수정 표기) |

- 환경·접속 기록: Windows 브라우저 연결은 사용자 관리 compose.browser.yaml의 app-preview(127.0.0.1:5173), 기존 Dashboard 127.0.0.1:9120 유지. Backend 소스 변경 후 Node 프로세스 재시작 필요, Vite HMR 감지 누락 시 실제 모듈 확인 후 Vite만 재시작, Playwright hermes:5173 403 시 Docker DNS IPv4 사용. PID·IP·요청 ID는 고정 문자열로 쓰지 않음. compose.browser.yaml은 사용자 관리이며 Hermes가 임의 수정하지 않음.

## REQ ↔ AC 대응 및 주요 구현 규칙

- 대응: REQ-001→AC-001/002/013, REQ-002→AC-003, REQ-003→AC-004, REQ-004→AC-005/006/007/014, REQ-005→AC-008/014, REQ-006→AC-009/010, REQ-007→AC-002/013, REQ-008→AC-011/012 (내용 대응 기준, Baseline에 명시 매핑 표 없음).
- 주요 규칙: trim 후 코드 포인트 기준 길이(title 1–100, requester/assignee 1–60, description 0–2000), id UUID v4·시각 UTC ISO 8601 서버 생성, 클라이언트 전달 id/status/시각·알 수 없는 필드 400, 전이 received→in_progress→completed 및 completed→in_progress(재개), 그 외 409 INVALID_TRANSITION, 동일 상태 200(updatedAt 유지), 오류 형식 `{error:{code,message}}` 4종 코드, 저장 `./data/requests.json`(DATA_FILE 변경 가능)·원자적 rename·손상 파일 500·쓰기 직렬화, UI 한국어 표시·키보드 포커스·중복 제출 방지·오류 시 입력 유지.

## 검증 결과

- 고정 자산 7개 실제 파일 읽기 및 문서 간 대조 분석 완료. 파일 수정 없음.
- JSON 계약(OpenAPI·JSON Schema·디자인 토큰) 구조 검사 PASS — 사용자 제공 PowerShell 실행 결과에 근거한 판정이며, Hermes Agent가 직접 실행한 것이 아니다.
- Lesson 04 Planning Check: PASS, 종료 코드 0 — 사용자 제공 PowerShell 실행 결과에 근거한 기록이며, Hermes Agent가 직접 실행한 것이 아니다.
- 제5교시 검증 결과(사용자가 제공한 PowerShell 결과를 근거로 한 것임을 명시 — Hermes Agent가 직접 실행한 결과가 아님):
  - Backend API 11/11 PASS, 종료 코드 0.
  - TypeScript 정적 검사 PASS, Vite 프로덕션 빌드 PASS.
  - Backend·Frontend·API 프록시 HTTP 200.
  - Chromium 목록·등록 화면 PASS.
  - Chromium 등록 → POST 201 → 상세 → 목록 복귀 PASS, 종료 코드 0.
- 고정 tests/api.test.js 전체는 제5교시 시점에는 실행하지 않았다(제6교시에서 17/17 PASS가 사용자 제공 출력으로 확인됨).
- 제5교시에서 Hermes Agent가 직접 실행한 검증: npx tsc --noEmit → exit 0 PASS (client/src strict).
- e2e/는 미배치이므로 Playwright E2E는 미실행이다. 미검증 항목은 완료로 보고하지 않는다.
- 계획 파일의 필수 ID·문구 검사(REQ 8개·AC 14개 포함 확인)는 계획 문서의 완성도 확인일 뿐 구현 성공을 보증하지 않는다.
- 제6교시 검증 결과 — **Hermes가 직접 실행한 검사**:
  - `npx tsc --noEmit` → exit 0 PASS (client/src strict, PATCH 타입·RequestDetail 확장 포함).
  - `node --check` server/routes.js·validate.js·store.js → SYNTAX OK (정적 문법 검사이며 테스트 실행이 아님).
- 제6교시 검증 결과 — **사용자 제공 출력에 근거한 기록(Hermes가 직접 실행한 결과가 아님, 개별 로그 원본은 사용자 측 보관)**:
  - 고정 API 테스트 17/17 PASS (tests/api.test.js 11 + tests/api-contract.test.js 6).
  - TypeScript 검사 PASS, Vite 프로덕션 빌드 PASS.
  - Chromium UI 8/8, Chromium 기능 E2E 9/9 (각각 실제 실행된 경우에 한해 유효).
  - AC-009 서버 재시작 전후 데이터·해시 보존, AC-010 손상 JSON 원본 보존 확인.
  - Windows 브라우저(127.0.0.1:5173) 목록·상세 및 수정 UI 확인.
- 제6교시 Closed-loop 자동 수정·재검증 사용 횟수: **0회** (한도 최대 3회, 미사용).

## 미해결 문제·주의 사항

- 참고(승인 필요, 유지): 목록 정렬 규칙이 requirements.md·specification.md에만 있고 openapi.json에는 미표기 — 계약 보완 여부는 변경 통제 대상.
- 고정 테스트 배치 후 기준 A(total=items.length)와 C(잘못된 UUID 400 VALIDATION_ERROR / 유효·미존재 404 NOT_FOUND)의 기대값을 실제 테스트와 교차 확인한다. 충돌 시 테스트나 구현을 임의로 수정·우회하지 않고 보고한다(AGENTS.md §2·§6).
- 구현 시 승인된 범위(client/, server/, plans/, progress.md, handoff.md)만 수정한다. Docker 명령은 사용하지 않는다(컨테이너 작업은 Windows PowerShell 사용자 담당).

## 다음 작업

- 제6교시(REQ-004/005 PATCH·상세 수정 UI) 구현·검증 완료. 다음 교시 지시 대기.
- 남은 검증 후보: 강사 전용 최종 인수 테스트, e2e/ 고정 자산 배치 상태 확인, AGENTS.md §10 최종 통합 검증 재확인.
- 로그인·삭제·검색 등 제외 범위는 구현 대상 아님.
- 고정 테스트 원본과 수정 금지 영역은 계속 보존한다. Docker 컨테이너 작업은 Windows PowerShell 사용자 담당(AGENTS.md §8).

## 다음 Chat에서 읽을 파일

- /workspace/AGENTS.md (공통 Harness 규칙)
- /workspace/docs/project-overview.md (프로젝트 개요)
- /workspace/specs/requirements.md (요구사항 Baseline)
- /workspace/docs/specification.md (상세 명세)
- /workspace/specs/acceptance-criteria.md (인수 기준 AC-001~014)
- /workspace/plans/implementation-plan.md (구현 계획)
- /workspace/plans/verification-plan.md (검증 계획)
- /workspace/progress.md (진행 상태) 및 /workspace/handoff.md (이 문서)
- /workspace/tests/api.test.js (고정 API 테스트 — createApp({dataFile}) 계약)
- /workspace/server/ (app.js, index.js, store.js, validate.js, errors.js, routes.js)
- /workspace/client/src/ (types.ts, labels.ts, api.ts, styles.css, main.tsx, App.tsx, components/)
- 필요 시: /workspace/contracts/openapi.json, /workspace/schemas/request.schema.json, /workspace/design/wireframes.md, /workspace/design/tokens.json
