# 구현 계획 (Implementation Plan) v1.0

작성 시점: Planning 단계 (Implementation 미착수)
근거 문서: AGENTS.md, docs/project-overview.md, specs/requirements.md, docs/specification.md, specs/acceptance-criteria.md, contracts/openapi.json, schemas/request.schema.json, design/wireframes.md, design/tokens.json, package.json, tsconfig.json, vite.config.js, playwright.config.js (전부 실제 읽기로 확인)

## 1. 목표

단일 사용자·인증 없는 로컬 웹 애플리케이션으로, 업무 요청의 등록·조회·수정·상태 관리를 제공하고 고정 테스트를 모두 통과한다. 오프라인에서 앱 데이터 작업이 동작해야 한다(초기 패키지 설치는 별개).

## 2. 구현 범위

- REQ-001~REQ-008 전체 (docs/project-overview.md "포함 기능")
- API 5개 엔드포인트 (contracts/openapi.json): GET/POST `/api/requests`, GET/PATCH `/api/requests/{id}`, PATCH `/api/requests/{id}/status`
- UI 3화면 (design/wireframes.md): WF-01 목록, WF-02 등록, WF-03 상세/수정
- 로컬 JSON 영속 저장, 원자적 교체, 오류 형식 통일

## 3. 제외 기능

docs/project-overview.md "제외": 로그인, 권한, 협업, 알림, 이메일, 외부 API, 클라우드 DB, 첨부파일, 삭제, 댓글, 검색, 정렬 변경, 페이지네이션.

## 4. 수정 금지 영역과 구현 허용 영역 (AGENTS.md §2, §3)

| 구분 | 경로 |
|---|---|
| 수정 금지 (읽기 전용) | docs/, specs/, contracts/, schemas/, design/, traceability/, tests/, e2e/, scripts/ |
| 구현 허용 | client/, server/, plans/, progress.md, handoff.md |
| 기타 경로 | 사전 보고·승인 필요 |

변경 통제 대상(§7): 요구사항·인수 기준·API 계약·데이터 스키마·와이어프레임·디자인 토큰·고정 테스트·검증 스크립트의 변경, 새 의존성 추가, 데이터 삭제·초기화, 승인 범위 밖 변경. 고정 테스트 원본은 수정하지 않는다(specification.md "테스트 분리").

## 5. 승인된 구현 기준 (사용자 확정, 2026-11-07)

- **A. total**: GET /api/requests의 `total`은 상태·우선순위 필터 적용 후 반환되는 항목 수, 즉 `items.length`로 계산한다. (REQ-002, WF-01 "총 N건" 표시와 일치)
- **B. 포커스**: 키보드 포커스는 기존 `primary` 디자인 토큰과 브라우저 기본 포커스 동작을 활용하며, design/tokens.json은 변경하지 않는다. (REQ-008, AC-011/012)
- **C. ID 오류**: 잘못된 UUID 형식의 요청 ID는 HTTP 400 `VALIDATION_ERROR`, 형식은 유효하지만 존재하지 않는 ID는 HTTP 404 `NOT_FOUND`로 처리한다. 형식 검사를 조회보다 먼저 적용한다. (REQ-003/004/005/007, AC-004)

## 6. REQ-001~REQ-008 작업 분해와 대응 AC

| REQ | 작업 | 대응 AC |
|---|---|---|
| REQ-001 요청 등록 | POST 라우트: 필수 필드(title, requester, assignee, priority) 검증, trim 후 코드 포인트 기준 길이(title 1–100, requester/assignee 1–60, priority enum), description 생략 시 빈 문자열, id(UUID v4)/status(received)/createdAt·updatedAt(UTC ISO 8601) 서버 생성, 클라이언트 전달 id/status/시각·알 수 없는 필드 400 | AC-001, AC-002, AC-013 |
| REQ-002 목록 조회·필터 | GET 라우트: status/priority 선택적 AND 필터, 잘못된 값 400, 생성 시각 내림차순 + ID 오름차순 타이브레이커, `{items, total: items.length}` (기준 A), 전 필드 반환 | AC-003 |
| REQ-003 상세 조회 | UUID 형식 검사(기준 C) → 400, 존재 시 200, 미존재 404 NOT_FOUND | AC-004 |
| REQ-004 상태 변경 | PATCH /status: status enum 검증, 전이 표 received→in_progress→completed, completed→in_progress(재개) 허용, 그 외 409 INVALID_TRANSITION, 동일 상태 200·updatedAt 유지 | AC-005, AC-006, AC-007, AC-014 |
| REQ-005 담당자·우선순위 수정 | PATCH /{id}: assignee/priority 중 하나 이상만 허용(minProperties 1), 알 수 없는 필드·빈 PATCH 400, 지정 필드만 변경, 동일 값이면 updatedAt 유지 | AC-008, AC-014 |
| REQ-006 로컬 영속 저장 | 저장 모듈: 기본 `./data/requests.json`, `DATA_FILE` 환경변수, 미존재 시 빈 배열 시작, 임시 파일 작성 후 같은 디렉터리 rename으로 원자적 교체, 손상 파일은 초기화하지 않고 500 보고, 쓰기 직렬화(큐/락) | AC-009, AC-010 |
| REQ-007 유효성·오류 | 오류 형식 `{error:{code,message}}`, 코드 4종(VALIDATION_ERROR, NOT_FOUND, INVALID_TRANSITION, INTERNAL_ERROR), 잘못된 JSON 400, 스택 추적·서버 파일 경로 노출 금지, 중앙 오류 핸들러 | AC-002, AC-013 |
| REQ-008 화면 접근성·사용성 | UI 3화면, 한국어 상태·우선순위 표시(접수/진행 중/완료, 낮음/보통/높음; API는 영문 enum), 시각적 라벨·필수 표시·오류 메시지·키보드 포커스(기준 B), 비동기 중복 제출 방지, 오류 시 입력 유지, 성공 시 목록/상세 갱신, 로딩/빈 목록/오류 상태 구분 | AC-011, AC-012 |

## 7. server/ 구현 순서

1. **저장소 모듈** (`server/store.js` 예정): 데이터 로드(미존재 시 빈 배열), 원자적 쓰기(rename), 손상 파일 500, 쓰기 직렬화. REQ-006.
2. **유효성·오류 처리 모듈** (`server/validation.js`, `server/errors.js` 예정): 필드 검증(코드 포인트 길이·enum·trim), 오류 형식과 코드 4종, UUID 형식 검사(기준 C). REQ-001/007.
3. **상태 전이 로직** (`server/state.js` 예정 또는 라우트 내): 전이 표, 409 판정, 동일 상태 200. REQ-004.
4. **라우트** (`server/routes/*.js` 예정): 5개 엔드포인트, 필터 AND 조합, 정렬(생성 시각 내림차순 → ID 오름차순), total = items.length(기준 A). REQ-001~005.
5. **시작 파일** (`server/index.js`): Express 앱, `/api` 접두사, 포트 3001, JSON 파서 오류(잘못된 JSON) 400 변환, 중앙 오류 핸들러, 정적 파일 서빙은 빌드 산출물 기준으로 최소 구성. REQ-006/007.

의존성: 1 → 2 → 3 → 4 → 5 (저장소와 유효성이 라우트의 선행 조건).

## 8. client/ 구현 순서

1. **공통 기반**: API 클라이언트(fetch 래퍼, 오류 형식 파싱), 상태·우선순위 한국어 라벨 매핑, 디자인 토큰 CSS 변수 매핑(tokens.json 값과 1:1, focus는 기본 outline 유지 — 기준 B), 라우팅/화면 전환 구조.
2. **목록 화면 (WF-01)**: 테이블(모바일 카드 목록), 상태·우선순위 필터 동시 적용, "총 N건"(= items.length), 로딩/빈 목록/오류+재시도 상태 구분, 제목 클릭 → 상세.
3. **등록 화면 (WF-02)**: 필수 표시·라벨, 필드 하단 오류 메시지, 중복 제출 방지, 오류 시 입력 유지, 성공 시 상세로 이동.
4. **상세/수정 화면 (WF-03)**: 읽기 전용 필드, 담당자·우선순위 저장, 상태 변경(불가능한 전이는 선택 비활성 또는 오류 안내), 성공 시 갱신.
5. **접근성 마무리**: 키보드 조작 전수 점검, 포커스 표시 확인, 오류 메시지와 라벨 연결.

의존성: 1 → 2 → 3 → 4 → 5. server/ 1~5 단계 완료 후 client/ 통합 개발·수동 확인 가능(개발 중에는 Vite 프록시 `/api` → localhost:3001 사용).

## 9. 예정 파일별 책임

| 예정 파일 | 책임 |
|---|---|
| server/index.js | Express 부팅, 미들웨어, 라우트 마운트, 오류 핸들러 |
| server/store.js | 영속 저장·로드·원자적 교체·쓰기 직렬화 |
| server/validation.js | 필드·필터·UUID 검증과 오류 생성 |
| server/routes/*.js | 5개 엔드포인트 로직 |
| client/src/main.tsx, App.tsx | 진입점, 화면 전환 |
| client/src/api.ts | API 호출과 오류 파싱 |
| client/src/pages/* | 목록/등록/상세 3화면 |
| client/src/styles | 토큰 CSS 변수, 레이아웃(contentMaxWidth 1120px), 포커스 |

(파일명은 예시이며 구현 중 조정 가능. 외부 구현 계약은 변경하지 않는다.)

## 10. 완료 조건

- AGENTS.md §10 순서의 검증이 모두 PASS: TypeScript 정적 검사 → 프로덕션 빌드 → API 인수 테스트 → 서버 재시작 영속성 → Playwright E2E.
- AC-001~AC-014 모두 충족, REQ-001~REQ-008 전부 구현.
- 고정 테스트 원본 미수정, 수정 금지 영역 무변경.
- tests/와 e2e/에 고정 테스트가 배치되면 **기준 A(total=items.length)와 C(400/404 매핑)의 기대값을 실제 테스트와 교차 확인**한다. 충돌 시 임의 수정하지 않고 사용자에게 보고한다.

## 11. 다음 구현 우선순위

1. server/ 저장소 모듈 → 2. 유효성·오류 처리 → 3. 상태 전이 → 4. 라우트 5개 → 5. server/index.js → 6. client/ 공통 기반 → 7. 목록 → 8. 등록 → 9. 상세/수정 → 10. 접근성·통합 확인.

Implementation 착수 전 사용자 승인을 받는다(AGENTS.md §4 절차 6, handoff.md 다음 작업).
