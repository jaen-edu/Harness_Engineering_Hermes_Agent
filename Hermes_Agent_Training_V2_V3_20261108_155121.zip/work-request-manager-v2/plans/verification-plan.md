# 검증 계획 (Verification Plan) v1.0

작성 시점: Planning 단계 (Implementation 미착수, 테스트 실행 이력 없음)
근거: AGENTS.md §6(반복 한도 3회)·§9(증거 보고)·§10(검증 순서), specs/acceptance-criteria.md AC-001~014, package.json 스크립트, playwright.config.js

## 1. 검증 명령 (package.json 실제 존재하는 것)

| 목적 | 명령 | 비고 |
|---|---|---|
| TypeScript 정적 검사 | `npx tsc --noEmit` | tsconfig.json: strict, include `client/src` (서버 TS는 범위 밖) |
| 프로덕션 빌드 | `npm run build` | vite build → `dist/` |
| API 인수 테스트 | `npm test` | `vitest run tests` — **tests/ 디렉터리는 현재 존재하지 않음** |
| E2E 테스트 | `npx playwright test` | playwright.config.js: testDir `./e2e`, baseURL `http://127.0.0.1:5173`, Desktop Chrome — **e2e/는 현재 비어 있음(테스트 파일 0개)** |
| 개발 실행 | `npm run dev` | server(3001) + Vite(5173, /api 프록시) 동시 실행 |

실제 존재 명령(package.json): `dev`, `dev:server`, `dev:client`, `build`, `test`, `test:watch`. 이 외 명령은 사용하지 않는다.

## 2. 제공 예정 테스트 자산과의 구분

- **고정 테스트 자산은 아직 제공되지 않았다**: tests/(단위·API, Vitest/Supertest)와 e2e/(Playwright)는 미제공 상태이며, 따라서 **이 두 검증은 현재 실행 불가·미실행이다. 존재하지 않는 테스트의 실행 결과를 주장하지 않는다.**
- 테스트 자산이 배치되면 그 시점에 위 명령으로 실행하고 결과를 보고한다.
- 고정 공개 테스트와 강사 전용 최종 인수 테스트는 구분되며, 둘 다 원본 그대로 사용한다(specification.md "테스트 분리"). **테스트 수정·검증 우회는 금지한다(AGENTS.md §6).**
- 테스트 배치 전 단계에서는 구현 수동 확인(서버 기동, 브라우저 조작)만 보조 수단으로 하고, 이를 PASS 근거로 대체하지 않는다.

## 3. 검증 순서 (AGENTS.md §10)

1. TypeScript 정적 검사 (`npx tsc --noEmit`, 종료 코드 0)
2. Frontend 프로덕션 빌드 (`npm run build`)
3. API 인수 테스트 (`npm test`, tests/ 배치 후)
4. 서버 재시작 후 데이터 영속성 테스트 (생성·수정 데이터 유지 확인, AC-009)
5. Playwright E2E 테스트 (`npx playwright test`, e2e/ 배치 후)
6. 전체 검증 결과 및 미해결 사항 보고

## 4. AC-001~AC-014 검증 대상과 방법

| AC | 검증 대상 | 방법 |
|---|---|---|
| AC-001 | 정상 필드 생성 → 201, UUID, received, UTC 시각, 저장 반영 | API 테스트(고정) + 수동 POST 확인 |
| AC-002 | 공백 제목·누락 필수·잘못된 priority → 400 VALIDATION_ERROR, 저장 변경 없음 | API 테스트(고정) |
| AC-003 | 상태+우선순위 동시 필터(AND) | API 테스트(고정) — total은 기준 A(items.length) |
| AC-004 | 상세 200 / 미존재 404 NOT_FOUND | API 테스트(고정) — 잘못된 UUID는 기준 C(400) |
| AC-005 | received→in_progress→completed 각 200 | API 테스트(고정) |
| AC-006 | received→completed → 409 INVALID_TRANSITION, 저장 변경 없음 | API 테스트(고정) |
| AC-007 | completed→in_progress 재개 200 | API 테스트(고정) |
| AC-008 | PATCH 지정 필드만 변경, updatedAt 갱신 | API 테스트(고정) |
| AC-009 | 서버 재시작 후 데이터 유지 | 영속성 검사(§3-4, 실제 재시작 수행) |
| AC-010 | 손상된 JSON 저장 파일 → 500, 빈 배열로 덮어쓰지 않음 | API 테스트(고정) 또는 수동: 손상 파일 주입 후 GET/재기동 확인 |
| AC-011 | 목록→등록→상세→상태변경 UI, 키보드 조작 | E2E(고정, 배치 후) — 포커스는 기준 B |
| AC-012 | 잘못된 입력 UI: 오류 표시, 입력 유지, 중복 제출 없음 | E2E(고정, 배치 후) |
| AC-013 | 미허용 필드 포함 본문 → 400, 데이터 변경 없음 | API 테스트(고정) |
| AC-014 | 동일 값 PATCH/상태 변경 → 200, updatedAt 유지 | API 테스트(고정) |

## 5. 고정 테스트 배치 후 기준 A·C 기대값 비교 (명시 사항)

tests/와 e2e/가 배치되면 다음을 테스트 코드와 교차 확인한다.

- **기준 A**: 목록 테스트가 기대하는 `total` 값이 "필터 적용 후 items.length"와 일치하는지. (테스트가 전체 건수를 기대하면 충돌)
- **기준 C**: 잘못된 UUID 형식 ID 케이스의 기대 상태 코드·오류 코드가 400 VALIDATION_ERROR와 일치하는지, 유효·미존재 ID가 404 NOT_FOUND와 일치하는지.
- 불일치 발견 시 **테스트나 구현을 임의로 수정·우회하지 않고** 충돌 내용(파일, 케이스, 기대값, 확정 기준과의 차이)을 사용자에게 보고하고 결정을 기다린다(AGENTS.md §2).

## 6. Closed-loop 개선 반복 (AGENTS.md §6)

- 최초 검증 이후 자동 수정·재검증은 **최대 3회**.
- 반복 절차: 구현 수정(허용 영역만) → 동일 고정 테스트 재실행 → PASS면 종료.
- 3회 이내 미해결 시 반복 중지 후 실패 원인·수정 이력·남은 문제를 보고한다.

## 7. 증거 기록 (AGENTS.md §9)

PASS 보고에는 반드시 다음을 포함한다. 실행한 명령, 종료 코드, 통과·실패 테스트 수, 실패 로그 또는 결과 파일 경로, 수정한 구현 파일, 남은 문제. 실행하지 않은 테스트는 PASS로 보고하지 않는다. Docker 명령은 사용하지 않는다(§8 — 컨테이너 작업은 Windows PowerShell 사용자 담당).
