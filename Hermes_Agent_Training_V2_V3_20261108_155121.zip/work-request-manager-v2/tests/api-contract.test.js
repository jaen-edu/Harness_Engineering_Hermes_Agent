import { describe, it, expect, beforeEach, afterEach } from 'vitest';
import request from 'supertest';
import { mkdtemp, rm, readFile } from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import { createApp } from '../server/app.js';

let dir;
let file;
let app;

const payload = {
  title: '계약 테스트 요청',
  description: '설명',
  requester: '요청자',
  assignee: '담당자',
  priority: 'high'
};

beforeEach(async () => {
  dir = await mkdtemp(path.join(os.tmpdir(), 'wrm-contract-'));
  file = path.join(dir, 'requests.json');
  app = createApp({ dataFile: file });
});

afterEach(async () => {
  await rm(dir, { recursive: true, force: true });
});

const create = body => request(app).post('/api/requests').send(body);

describe('추가 API 계약 인수 테스트', () => {
  it('AC-001 UUID v4, UTC 시각, 저장 후 재조회', async () => {
    const r = await create(payload);
    expect(r.status).toBe(201);
    expect(r.body.id).toMatch(
      /^[0-9a-f]{8}-[0-9a-f]{4}-4[0-9a-f]{3}-[89ab][0-9a-f]{3}-[0-9a-f]{12}$/i
    );
    expect(r.body.createdAt).toMatch(/^\d{4}-\d{2}-\d{2}T.*Z$/);
    expect(r.body.updatedAt).toBe(r.body.createdAt);

    const detail = await request(app).get(`/api/requests/${r.body.id}`);
    expect(detail.status).toBe(200);
    expect(detail.body).toEqual(r.body);
  });

  it('AC-002 잘못된 값은 저장 데이터를 변경하지 않는다', async () => {
    const initial = await create(payload);
    expect(initial.status).toBe(201);

    const original = await readFile(file, 'utf8');

    const invalid = [
      { ...payload, title: '   ' },
      { ...payload, title: '가'.repeat(101) },
      { ...payload, requester: '가'.repeat(61) },
      { ...payload, assignee: '가'.repeat(61) },
      { ...payload, description: '가'.repeat(2001) },
      { ...payload, priority: 'urgent' }
    ];

    for (const item of invalid) {
      const r = await create(item);
      expect(r.status).toBe(400);
      expect(r.body.error.code).toBe('VALIDATION_ERROR');
    }

    expect(await readFile(file, 'utf8')).toBe(original);
  });

  it('AC-004 존재하지 않는 요청은 NOT_FOUND', async () => {
    const r = await request(app).get(
      '/api/requests/00000000-0000-4000-8000-000000000000'
    );
    expect(r.status).toBe(404);
    expect(r.body.error.code).toBe('NOT_FOUND');
  });

  it('AC-006 금지된 상태 전이는 저장 데이터를 변경하지 않는다', async () => {
    const created = await create(payload);
    const original = await readFile(file, 'utf8');

    const r = await request(app)
      .patch(`/api/requests/${created.body.id}/status`)
      .send({ status: 'completed' });

    expect(r.status).toBe(409);
    expect(r.body.error.code).toBe('INVALID_TRANSITION');

    const detail = await request(app)
      .get(`/api/requests/${created.body.id}`);

    expect(detail.body.status).toBe('received');
    expect(detail.body.updatedAt).toBe(created.body.updatedAt);
    expect(await readFile(file, 'utf8')).toBe(original);
  });

  it('AC-008 수정 시 다른 필드는 유지된다', async () => {
    const created = await create(payload);

    const r = await request(app)
      .patch(`/api/requests/${created.body.id}`)
      .send({ assignee: '변경 담당자', priority: 'low' });

    expect(r.status).toBe(200);
    expect(r.body.assignee).toBe('변경 담당자');
    expect(r.body.priority).toBe('low');
    expect(r.body.title).toBe(created.body.title);
    expect(r.body.description).toBe(created.body.description);
    expect(r.body.requester).toBe(created.body.requester);
    expect(r.body.createdAt).toBe(created.body.createdAt);
    expect(Date.parse(r.body.updatedAt))
      .toBeGreaterThanOrEqual(Date.parse(created.body.updatedAt));
  });

  it('AC-013 미허용 필드는 거부하고 저장을 변경하지 않는다', async () => {
    const created = await create(payload);
    const original = await readFile(file, 'utf8');

    const r = await request(app)
      .patch(`/api/requests/${created.body.id}`)
      .send({ title: '무단 변경' });

    expect(r.status).toBe(400);
    expect(r.body.error.code).toBe('VALIDATION_ERROR');
    expect(await readFile(file, 'utf8')).toBe(original);
  });
});
