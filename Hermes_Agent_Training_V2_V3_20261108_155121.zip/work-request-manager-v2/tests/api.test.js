import {describe,it,expect,beforeEach,afterEach} from 'vitest';
import request from 'supertest';
import {mkdtemp,rm,readFile,writeFile} from 'node:fs/promises';
import os from 'node:os';
import path from 'node:path';
import {createApp} from '../server/app.js';
let dir,file,app;
const payload={title:'테스트 요청',description:'설명',requester:'요청자',assignee:'담당자',priority:'high'};
beforeEach(async()=>{dir=await mkdtemp(path.join(os.tmpdir(),'wrm-'));file=path.join(dir,'requests.json');app=createApp({dataFile:file});});
afterEach(async()=>{await rm(dir,{recursive:true,force:true});});
async function create(p=payload){return request(app).post('/api/requests').send(p);}
describe('고정 API 인수 테스트',()=>{
 it('AC-001 생성과 UUID/기본 상태',async()=>{const r=await create();expect(r.status).toBe(201);expect(r.body.id).toMatch(/^[\da-f-]{36}$/);expect(r.body.status).toBe('received');expect(r.body.title).toBe(payload.title);expect(r.body.createdAt).toBeTruthy();});
 it('AC-002 잘못된 입력은 400이고 저장되지 않는다',async()=>{for(const p of [{...payload,title:'  '},{...payload,priority:'urgent'},{title:'x'}]){expect((await create(p)).status).toBe(400);}expect((await request(app).get('/api/requests')).body.total).toBe(0);});
 it('AC-003 상태+우선순위 AND 필터',async()=>{await create();await create({...payload,title:'두 번째',priority:'low'});const r=await request(app).get('/api/requests?status=received&priority=high');expect(r.status).toBe(200);expect(r.body.total).toBe(1);expect(r.body.items[0].priority).toBe('high');});
 it('AC-004 상세와 미존재',async()=>{const r=await create();expect((await request(app).get(`/api/requests/${r.body.id}`)).status).toBe(200);expect((await request(app).get('/api/requests/00000000-0000-4000-8000-000000000000')).status).toBe(404);});
 it('AC-005/006/007 상태 전이와 거부',async()=>{const r=await create();const url=`/api/requests/${r.body.id}/status`;expect((await request(app).patch(url).send({status:'completed'})).status).toBe(409);expect((await request(app).patch(url).send({status:'in_progress'})).status).toBe(200);expect((await request(app).patch(url).send({status:'completed'})).status).toBe(200);expect((await request(app).patch(url).send({status:'in_progress'})).status).toBe(200);});
 it('AC-008 담당자와 우선순위 수정',async()=>{const r=await create();const u=await request(app).patch(`/api/requests/${r.body.id}`).send({assignee:'새 담당자',priority:'low'});expect(u.status).toBe(200);expect(u.body.assignee).toBe('새 담당자');expect(u.body.priority).toBe('low');expect(u.body.title).toBe(payload.title);});
 it('AC-009 저장 후 앱 인스턴스 재생성',async()=>{const r=await create();const another=createApp({dataFile:file});expect((await request(another).get(`/api/requests/${r.body.id}`)).body.title).toBe(payload.title);});
 it('AC-010 손상된 저장 파일은 500이며 보존',async()=>{await writeFile(file,'{invalid');expect((await request(app).get('/api/requests')).status).toBe(500);expect(await readFile(file,'utf8')).toBe('{invalid');});
 it('AC-013 미허용 필드 거부',async()=>{expect((await create({...payload,status:'completed'})).status).toBe(400);});
 it('AC-014 동일 값 수정 시 updatedAt 유지',async()=>{const r=await create();const u=await request(app).patch(`/api/requests/${r.body.id}`).send({priority:'high'});expect(u.body.updatedAt).toBe(r.body.updatedAt);const s=await request(app).patch(`/api/requests/${r.body.id}/status`).send({status:'received'});expect(s.body.updatedAt).toBe(r.body.updatedAt);});
 it('잘못된 JSON과 필터는 400',async()=>{expect((await request(app).get('/api/requests?priority=urgent')).status).toBe(400);expect((await request(app).post('/api/requests').set('Content-Type','application/json').send('{oops')).status).toBe(400);});
});
