const { chromium } = require('playwright');
const started = Date.now();
const mark = (name) => console.error(`[DIAG] ${Date.now() - started}ms ${name}`);
(async () => {
  let browser;
  try {
    mark('TEST_STARTED');
    mark('CHROMIUM_LAUNCH_START');
    browser = await chromium.launch({ headless: true });
    mark('CHROMIUM_LAUNCH_COMPLETE');
    const page = await browser.newPage();
    mark('PAGE_CREATE_COMPLETE');
    await page.goto('about:blank');
    mark('NAVIGATION_COMPLETE');
    if (page.url() !== 'about:blank') throw new Error('Unexpected URL');
    const version = browser.version();
    const url = page.url();
    mark('BROWSER_CLOSE_START');
    await browser.close();
    browser = null;
    mark('BROWSER_CLOSE_COMPLETE');
    console.log(JSON.stringify({status:'PASS',test:'browser-smoke',browser:version,url}));
    mark('TEST_COMPLETE');
  } catch (err) {
    console.error(err.stack || String(err));
    process.exitCode = 1;
    if (browser) await browser.close().catch(() => {});
  }
})();
