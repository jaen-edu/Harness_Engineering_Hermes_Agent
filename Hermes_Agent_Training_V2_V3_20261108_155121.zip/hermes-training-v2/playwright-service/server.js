const http = require('node:http');
const fs = require('node:fs');
const path = require('node:path');
const { spawn } = require('node:child_process');
const ROOT = '/opt/playwright-runtime';
const RESULTS = '/workspace/test-results';
const TESTS = Object.freeze({'browser-smoke': path.join(ROOT, 'browser-smoke.js')});
let running = false;
let lastResult = null;
fs.mkdirSync(RESULTS, {recursive:true});
const reply = (res, code, data) => {
  res.writeHead(code, {'content-type':'application/json; charset=utf-8','cache-control':'no-store'});
  res.end(JSON.stringify(data));
};
function execute(name) {
  return new Promise(resolve => {
    const child = spawn(process.execPath, [TESTS[name]], {cwd:ROOT, shell:false, stdio:['ignore','pipe','pipe']});
    let stdout = '', stderr = '', timedOut = false, settled = false;
    const cap = (s, chunk) => (s + chunk.toString()).slice(-65536);
    child.stdout.on('data', b => { stdout = cap(stdout,b); });
    child.stderr.on('data', b => { stderr = cap(stderr,b); });
    const timer = setTimeout(() => { timedOut = true; child.kill('SIGKILL'); }, 30000);
    const finish = (code, signal, error) => {
      if (settled) return;
      settled = true;
      clearTimeout(timer);
      let reportedPass = false;
      try { reportedPass = JSON.parse(stdout.trim()).status === 'PASS'; } catch {}
      const result = {
        test:name,
        status:code === 0 && !timedOut && reportedPass && !error ? 'PASS' : 'FAIL',
        exitCode:code, signal, timedOut,
        stdout:stdout.trim(), stderr:stderr.trim(),
        ...(error ? {error:String(error)} : {}),
        timestamp:new Date().toISOString()
      };
      try {
        fs.writeFileSync(path.join(RESULTS,'latest.json'),JSON.stringify(result,null,2));
      } catch(e) { result.status = 'FAIL'; result.storageError = e.message; }
      lastResult = result;
      resolve(result);
    };
    child.once('error', err => finish(null,null,err));
    child.once('close', (code,signal) => finish(code,signal));
  });
}
http.createServer(async (req,res) => {
  if (req.method === 'GET' && req.url === '/health')
    return reply(res,200,{status:'ok',service:'playwright-runner',running});
  if (req.method === 'GET' && req.url === '/results')
    return reply(res,200,lastResult || {status:'NO_RESULTS'});
  if (req.method !== 'POST' || req.url !== '/run')
    return reply(res,404,{error:'Not Found'});
  if (running) return reply(res,409,{error:'Test already running'});
  running = true;
  try {
    let body = '';
    for await (const chunk of req) {
      body += chunk.toString();
      if (Buffer.byteLength(body) > 4096) return reply(res,413,{error:'Request too large'});
    }
    let input;
    try { input = JSON.parse(body); } catch { return reply(res,400,{error:'Invalid JSON'}); }
    if (!input || typeof input !== 'object' || !Object.hasOwn(TESTS,input.test))
      return reply(res,400,{error:'Unknown test'});
    const result = await execute(input.test);
    return reply(res,result.status === 'PASS' ? 200 : 500,result);
  } catch(err) {
    return reply(res,500,{status:'FAIL',error:String(err)});
  } finally { running = false; }
}).listen(3000,'0.0.0.0',() => console.log('Playwright Runner listening on port 3000'));
