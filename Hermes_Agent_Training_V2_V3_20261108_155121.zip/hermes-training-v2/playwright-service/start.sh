#!/bin/sh
set -eu
ROOT=/opt/playwright-runtime
mkdir -p "$ROOT"
cp /runner/package.json "$ROOT/package.json"
cp /runner/server.js "$ROOT/server.js"
cp /runner/browser-smoke.js "$ROOT/browser-smoke.js"
cd "$ROOT"
# 고정 버전의 lockfile이 없다면 Linux 볼륨에서 처음 생성한다.
if [ ! -f package-lock.json ]; then
  npm install --package-lock-only --ignore-scripts --no-audit --no-fund
fi
npm ci --ignore-scripts --no-audit --no-fund
node --check server.js
node --check browser-smoke.js
exec node server.js
