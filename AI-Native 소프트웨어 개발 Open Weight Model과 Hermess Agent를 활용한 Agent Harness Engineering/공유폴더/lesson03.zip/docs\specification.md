# 상세 명세 v1.0

## 데이터 필드
`id` UUID v4, `title` 1~100자(앞뒤 공백 제거), `description` 0~2000자(앞뒤 공백 제거), `requester` 1~60자(앞뒤 공백 제거), `assignee` 1~60자(앞뒤 공백 제거), `priority` low/medium/high, `status` received/in_progress/completed, `createdAt`/`updatedAt` UTC ISO 8601. 문자열 길이는 Unicode 코드 포인트 기준이다.

## 생성
요청 필수 필드: title, requester, assignee, priority. description 생략 시 빈 문자열. status는 received. 서버가 id, createdAt, updatedAt을 생성한다. 빈 문자열·공백만 있는 필수 값은 400. 알 수 없는 필드 또는 클라이언트가 전달한 id/status/시각은 400.

## 상태 전이
- received → in_progress
- in_progress → completed
- completed → in_progress (재개)
- 동일 상태로 변경은 200, 데이터 변화 없음(`updatedAt` 유지)
- 그 외 전이는 409 `INVALID_TRANSITION`.

## 수정
`PATCH /api/requests/{id}`는 `assignee`, `priority` 중 하나 이상만 허용한다. `PATCH /api/requests/{id}/status`는 `status`만 허용한다. 수정 시 `updatedAt` 변경; 동일한 값이면 변경하지 않는다. 빈 PATCH 또는 알 수 없는 필드는 400.

## 목록
`GET /api/requests?status=...&priority=...`; 둘 다 선택적으로 사용, 동시에 지정 시 AND. 값이 유효하지 않으면 400. 응답은 `{items:[...],total:N}`. 생성 시각 내림차순, 같으면 ID 오름차순. 모든 필드는 상세와 동일하게 반환한다.

## 저장
저장 파일 기본 경로 `./data/requests.json`(서버 작업 디렉터리 기준), 환경변수 `DATA_FILE`로 변경 가능. 파일 미존재 시 빈 배열로 시작하고 첫 쓰기 시 생성. 임시 파일 작성 후 같은 디렉터리 내 rename으로 교체. 파일 손상/읽기 오류를 조용히 초기화하지 않고 500으로 보고. 단일 서버 프로세스에서 쓰기 직렬화.

## API 오류
`{ "error": { "code": "...", "message": "..." } }` 형식. 코드는 VALIDATION_ERROR, NOT_FOUND, INVALID_TRANSITION, INTERNAL_ERROR. 오류에 스택 추적이나 서버 파일 경로 노출 금지.

## UI
하나의 웹 앱에서 목록/등록/상세/수정 흐름을 제공. 상태·우선순위는 사용자에게 한국어로 표시하되 API에는 영문 enum 사용. 비동기 작업 동안 중복 제출 방지. 오류 발생 시 입력 유지 및 오류 메시지 표시. 성공 시 목록/상세 갱신.

## 테스트 분리
고정 공개 테스트와 강사 전용 최종 인수 테스트를 구분한다. Agent는 두 테스트의 원본을 변경하지 않는다. 구현 세부구조는 자유롭게 선택하되 외부 계약은 변경하지 않는다.
