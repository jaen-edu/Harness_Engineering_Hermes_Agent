# 인수 기준

| ID | 검증 시나리오 | 기대 결과 |
|---|---|---|
| AC-001 | 정상 필드로 생성 | 201, UUID, received, UTC 시각, 저장 반영 |
| AC-002 | 공백 제목·누락 필수 필드·잘못된 priority | 400 VALIDATION_ERROR, 저장 변경 없음 |
| AC-003 | 목록 상태+우선순위 동시 필터 | 두 조건 모두 만족하는 항목만 반환 |
| AC-004 | 상세 존재/미존재 | 200/404 NOT_FOUND |
| AC-005 | received→in_progress→completed | 각 단계 200, 상세 상태 반영 |
| AC-006 | received→completed 직접 전이 | 409 INVALID_TRANSITION, 저장 변경 없음 |
| AC-007 | 완료 상태 재개 | completed→in_progress 200 |
| AC-008 | 담당자·우선순위 수정 | 지정한 필드만 변경, updatedAt 갱신 |
| AC-009 | 서버 프로세스 재시작 | 생성·수정 데이터 유지 |
| AC-010 | 손상된 JSON 저장 파일 | 500, 기존 파일을 빈 배열로 덮어쓰지 않음 |
| AC-011 | 목록→등록→상세→상태변경 UI | 키보드 조작과 화면 표시 정상 |
| AC-012 | 잘못된 입력 UI | 오류 표시, 입력 유지, 중복 제출 없음 |
| AC-013 | 요청 본문에 미허용 필드 | 400, 데이터 변경 없음 |
| AC-014 | 동일 값 PATCH/상태 변경 | 200, updatedAt 유지 |
