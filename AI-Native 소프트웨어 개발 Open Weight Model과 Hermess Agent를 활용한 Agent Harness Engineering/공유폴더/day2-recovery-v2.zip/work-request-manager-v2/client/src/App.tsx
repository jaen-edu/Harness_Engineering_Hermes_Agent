// 앱 라우팅: 라우터 라이브러리 없이 해시 기반 화면 전환
// - '#/' → WF-01 목록, '#/new' → WF-02 등록, '#/requests/:id' → WF-03 상세
// - PATCH 수정과 상태 변경은 다음 교시 범위이므로 상세 화면에 미구현 기능을
//   작동하는 것처럼 표현하지 않는다.
import { useCallback, useEffect, useState } from 'react';
import { RequestList } from './components/RequestList';
import { RequestForm } from './components/RequestForm';
import { RequestDetail } from './components/RequestDetail';

type Route =
  | { name: 'list' }
  | { name: 'new' }
  | { name: 'detail'; id: string };

function parseHash(hash: string): Route {
  const path = hash.replace(/^#/, '');
  if (path === '/new') return { name: 'new' };
  const match = path.match(/^\/requests\/([^/]+)$/);
  if (match) return { name: 'detail', id: decodeURIComponent(match[1]) };
  return { name: 'list' };
}

export function App() {
  const [route, setRoute] = useState<Route>(() => parseHash(window.location.hash));

  useEffect(() => {
    const onHashChange = () => {
      setRoute(parseHash(window.location.hash));
    };
    window.addEventListener('hashchange', onHashChange);
    return () => {
      window.removeEventListener('hashchange', onHashChange);
    };
  }, []);

  const navigate = useCallback((hash: string) => {
    window.location.hash = hash;
  }, []);

  return (
    <div className="app">
      <header className="app-header">
        <h1>AI Work Request Manager 2.0</h1>
        {route.name === 'list' && (
          <div className="app-header__actions">
            <button
              type="button"
              className="btn btn--primary"
              onClick={() => navigate('#/new')}
            >
              요청 등록
            </button>
          </div>
        )}
      </header>
      {route.name === 'list' && <RequestList onNavigate={navigate} />}
      {route.name === 'new' && <RequestForm onNavigate={navigate} />}
      {route.name === 'detail' && <RequestDetail id={route.id} onNavigate={navigate} />}
    </div>
  );
}
