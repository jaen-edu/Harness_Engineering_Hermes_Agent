// API 타입: contracts/openapi.json WorkRequest·Error, schemas/request.schema.json 기준
// 상태·우선순위 enum은 영문 그대로 (API는 영문, UI 표시는 labels.ts에서 한국어)

export type Priority = 'low' | 'medium' | 'high';
export type Status = 'received' | 'in_progress' | 'completed';

export interface WorkRequest {
  id: string;
  title: string;
  description: string;
  requester: string;
  assignee: string;
  priority: Priority;
  status: Status;
  createdAt: string;
  updatedAt: string;
}

export interface WorkRequestList {
  items: WorkRequest[];
  total: number;
}

export interface CreateRequestInput {
  title: string;
  description: string;
  requester: string;
  assignee: string;
  priority: Priority;
}

export interface ListFilters {
  status?: Status;
  priority?: Priority;
}

export type ApiErrorCode =
  | 'VALIDATION_ERROR'
  | 'NOT_FOUND'
  | 'INVALID_TRANSITION'
  | 'INTERNAL_ERROR';

export interface ApiErrorBody {
  error: { code: ApiErrorCode; message: string };
}

export function isApiErrorBody(body: unknown): body is ApiErrorBody {
  if (body === null || typeof body !== 'object') return false;
  const error = (body as { error?: unknown }).error;
  if (error === null || typeof error !== 'object') return false;
  const code = (error as { code?: unknown }).code;
  const message = (error as { message?: unknown }).message;
  return typeof code === 'string' && typeof message === 'string';
}
