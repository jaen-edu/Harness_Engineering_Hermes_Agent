// WF-03 상세 화면: GET /api/requests/{id}
// - 제목 heading의 접근 가능한 이름은 '요청 상세'
// - 제목·설명·요청자·담당자·우선순위·상태·생성/수정 시각 표시
// - 로딩·404·네트워크 오류를 구분하고 목록으로 돌아가는 버튼 제공
// - PATCH 수정과 상태 변경은 다음 교시 범위: 작동하는 것처럼 표현하지 않는다.
import { useCallback, useEffect, useState } from 'react';
import { ApiError, getRequest } from '../api';
import { PRIORITY_LABEL, STATUS_LABEL, formatDateTime } from '../labels';
import type { WorkRequest } from '../types';

type LoadState =
  | { kind: 'loading' }
  | { kind: 'not-found' }
  | { kind: 'error'; message: string }
  | { kind: 'loaded'; request: WorkRequest };

interface Props {
  id: string;
  onNavigate: (hash: string) => void;
}

export function RequestDetail({ id, onNavigate }: Props) {
  const [state, setState] = useState<LoadState>({ kind: 'loading' });
  const [reloadKey, setReloadKey] = useState(0);

  useEffect(() => {
    let cancelled = false;
    setState({ kind: 'loading' });
    getRequest(id)
      .then((request) => {
        if (!cancelled) setState({ kind: 'loaded', request });
      })
      .catch((error: unknown) => {
        if (!cancelled) {
          if (error instanceof ApiError && error.status === 404) {
            setState({ kind: 'not-found' });
          } else {
            const message = error instanceof ApiError ? error.message : '요청을 불러오는 중 오류가 발생했습니다.';
            setState({ kind: 'error', message });
          }
        }
      });
    return () => {
      cancelled = true;
    };
  }, [id, reloadKey]);

  const onRetry = useCallback(() => {
    setReloadKey((key) => key + 1);
  }, []);

  return (
    <section aria-label="요청 상세">
      <p>
        <button type="button" className="btn" onClick={() => onNavigate('#/')}>
          목록으로
        </button>
      </p>

      {state.kind === 'loading' && (
        <div className="state" role="status">로딩 중…</div>
      )}

      {state.kind === 'not-found' && (
        <div className="state state--error" role="alert">
          <p>요청을 찾을 수 없습니다.</p>
          <button type="button" className="btn" onClick={onRetry}>재시도</button>
        </div>
      )}

      {state.kind === 'error' && (
        <div className="state state--error" role="alert">
          <p>요청을 불러오지 못했습니다. {state.message}</p>
          <button type="button" className="btn" onClick={onRetry}>재시도</button>
        </div>
      )}

      {state.kind === 'loaded' && (
        <div className="detail">
          <h2 className="detail__heading">요청 상세</h2>
          <div className="detail__section">
            <dl>
              <dt>제목</dt>
              <dd>{state.request.title}</dd>
              <dt>설명</dt>
              <dd>{state.request.description}</dd>
              <dt>요청자</dt>
              <dd>{state.request.requester}</dd>
              <dt>담당자</dt>
              <dd>{state.request.assignee}</dd>
              <dt>우선순위</dt>
              <dd>{PRIORITY_LABEL[state.request.priority]}</dd>
              <dt>상태</dt>
              <dd>{STATUS_LABEL[state.request.status]}</dd>
              <dt>생성 시각</dt>
              <dd>{formatDateTime(state.request.createdAt)}</dd>
              <dt>수정 시각</dt>
              <dd>{formatDateTime(state.request.updatedAt)}</dd>
            </dl>
          </div>
          {/* PATCH 수정과 상태 변경은 다음 교시 범위이므로 이 화면에서
              작동하는 것처럼 표현하지 않는다. */}
        </div>
      )}
    </section>
  );
}
