// 라우트: REQ-001 (등록), REQ-002 (목록·필터), REQ-003 (상세)
// 이번 교시 범위: POST /api/requests, GET /api/requests, GET /api/requests/:id
// 다음 교시 범위: PATCH /api/requests/:id, PATCH /api/requests/:id/status (REQ-004/005)

import { randomUUID } from 'node:crypto';
import { notFoundError } from './errors.js';
import { validateCreate, validateListFilters, validateId } from './validate.js';

// GET /api/requests 응답: {items, total}. total = 필터 적용 후 items.length (기준 A).
// 정렬: createdAt 내림차순, 동률이면 id 오름차순.
function sortItems(items) {
  return [...items].sort((a, b) => {
    if (a.createdAt !== b.createdAt) {
      return a.createdAt < b.createdAt ? 1 : -1;
    }
    return a.id < b.id ? -1 : 1;
  });
}

function applyFilters(items, filters) {
  return items.filter((item) => {
    if (filters.status !== undefined && item.status !== filters.status) return false;
    if (filters.priority !== undefined && item.priority !== filters.priority) return false;
    return true;
  });
}

export function registerRoutes(app, store) {
  // REQ-001 등록
  app.post('/api/requests', async (req, res, next) => {
    try {
      const input = validateCreate(req.body);
      const now = new Date().toISOString();
      const item = {
        id: randomUUID(),
        title: input.title,
        description: input.description,
        requester: input.requester,
        assignee: input.assignee,
        priority: input.priority,
        status: 'received',
        createdAt: now,
        updatedAt: now,
      };
      const items = await store.mutate((current) => [...current, item]);
      const saved = items.find((it) => it.id === item.id);
      res.status(201).json(saved ?? item);
    } catch (err) {
      next(err);
    }
  });

  // REQ-002 목록·필터
  app.get('/api/requests', async (req, res, next) => {
    try {
      const filters = validateListFilters(req.query);
      const items = await store.read();
      const filtered = sortItems(applyFilters(items, filters));
      res.status(200).json({ items: filtered, total: filtered.length });
    } catch (err) {
      next(err);
    }
  });

  // REQ-003 상세 (기준 C: UUID 형식 검사를 조회보다 먼저)
  app.get('/api/requests/:id', async (req, res, next) => {
    try {
      const id = validateId(req.params.id);
      const items = await store.read();
      const item = items.find((it) => it.id === id);
      if (!item) {
        throw notFoundError('요청을 찾을 수 없습니다.');
      }
      res.status(200).json(item);
    } catch (err) {
      next(err);
    }
  });

  // 다음 교시 범위: PATCH /api/requests/:id, PATCH /api/requests/:id/status
  // 여기에는 구현하지 않는다. 미구현 경로는 Express 기본 404를 거친다.
}
