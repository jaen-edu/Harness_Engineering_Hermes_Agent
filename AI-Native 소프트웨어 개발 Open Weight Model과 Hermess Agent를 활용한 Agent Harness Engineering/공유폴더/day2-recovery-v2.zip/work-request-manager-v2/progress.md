# 프로젝트 진행 상태

## 현재 단계

- Planning 완료, 제5교시 Implementation(등록·목록·상세) 완료. 전체 구현은 제6교시(REQ-004/005 PATCH)까지 남아 있다.
- 제5교시: server/ 6파일 + client/src 9파일 구현 완료. Backend API 11/11 PASS(사용자 제공 PowerShell 결과 기준).
- tests/api.test.js는 배치됨(제5교시). e2e/는 미배치이며, 고정 API 전체 테스트는 Hermes Agent가 직접 실행하지 않았다.

## 완료된 작업

### 제1·2교시 (기존 기록 유지)

- Starter에서 AGENTS.md와 프로젝트 개요(docs/project-overview.md) 적용 완료.
- 새 Chat에서 공통 Harness 규칙 로드 완료 (AGENTS.md, docs/project-overview.md 실제 읽기).
- Harness 수정 허용/금지 영역 구분, Closed-loop 개선 규칙(자동 수정·재검증 최대 3회) 확인.
- AGENTS.md와 docs/project-overview.md 간 충돌 여부 점검 — 충돌 없음 확인.
- 변경 통제 가상 시나리오 판정 완료:
  - A. 승인된 범위 내 client/src/main.tsx 수정 → 허용 (§3, §7)
  - B. 실패한 tests/api.test.js 기대값 변경 → 금지 (§2, §6)
  - C. 명세에 없는 로그인 기능 추가 및 인증 라이브러리 설치 → 사전 승인 필요 (§7)
- 개발 환경 구축 및 브라우저 Smoke Test 완료.

### 제3교시 (고정 Baseline 7개 자산 읽기·분석)

- 고정 자산 7개 실제 읽기 완료: specs/requirements.md, docs/specification.md, specs/acceptance-criteria.md, contracts/openapi.json, schemas/request.schema.json, design/wireframes.md, design/tokens.json.
- 요구사항 REQ-001~REQ-008과 인수 기준 AC-001~AC-014의 대응 관계 확인 완료. 전 REQ가 최소 1개 이상 AC로 커버되고 누락 REQ/AC 없음 (명시적 매핑 표는 Baseline에 없고 내용 대응으로 확인).
- API 엔드포인트 5개(GET/POST /api/requests, GET/PATCH /api/requests/{id}, PATCH /api/requests/{id}/status), WorkRequest 스키마, 오류 응답 형식, WF-01~03 화면 구성, 디자인 토큰(색 9·간격 6·radius 2·타이포그래피·레이아웃) 정리 완료.
- OpenAPI ↔ JSON Schema 필드·필수·제약 완전 동일 확인. API·스키마·와이어프레임·토큰 사이 명백한 모순 없음.
- REQ–AC 추적표와 구현 필수 규칙(데이터·상태 전이·오류·저장·접근성) 요약 작성 완료. Planning 전 제안(작업 분해 5개 항목) 제시.

### 제4교시 (명세 해석 확정 및 Planning 완료)

- 명세 해석 필요 3건에 대한 구현 기준 후보를 고정 문서 근거로 검토하고 사용자가 A·B·C를 확정·승인함 (아래 "승인된 구현 기준" 참조). 과거 미해결 3건은 이 확정으로 해소됨.
- 확정 기준의 REQ/API/UI 영향 범위를 표로 정리하고, 고정 테스트 배치 후 기준 A·C 기대값 교차 확인 필요를 명시함. 테스트 충돌 시 임의 수정 금지·보고 원칙 확인.
- 구현 계획 /workspace/plans/implementation-plan.md 작성 완료: 목표·범위·제외, 수정 금지/허용 영역, REQ-001~008 작업 분해와 대응 AC, server/(저장소→유효성·오류→상태 전이→라우트→index.js)·client/(공통 기반→목록→등록→상세/수정→접근성) 구현 순서, 예정 파일 책임, 완료 조건, 다음 우선순위.
- 검증 계획 /workspace/plans/verification-plan.md 작성 완료: AC-001~014 검증 대상·방법, AGENTS.md §10 검증 순서, §6 반복 한도 3회, 증거 기록 원칙, tests/·e2e/ 미제공·미실행 명시, 테스트 배치 후 기준 A·C 기대값 비교 절차.
- 두 계획 파일을 다시 읽어 필수 항목과 REQ 8개·AC 14개 포함을 확인함 (계획 문서의 ID·문구 검사이며 구현 성공을 보증하지 않는다).

### 제5교시 (Implementation: 등록·목록·상세)

- 준비: AGENTS.md, 두 plans/ 계획, package.json, tests/api.test.js, requirements.md, specification.md, acceptance-criteria.md, contracts/openapi.json, schemas/request.schema.json 실제 읽기. tests/api.test.js에서 createApp({dataFile}) 계약(ESM named export, supertest 포트 없이 검사) 확인.
- Backend (server/ 6파일 생성): app.js(named export createApp(options), JSON 파서 오류→400, 중앙 오류 핸들러), index.js(포트 3001, DATA_FILE 우선 전달), store.js(기본 ./data/requests.json, 상위 디렉터리 생성, rename 원자적 교체, 손상 파일 500·보존, 읽기→수정→쓰기 전체 직렬화 큐), validate.js(trim 후 코드 포인트 길이·enum·UUID v4 형식 검사), errors.js(오류 형식 {error:{code,message}} 4종 코드), routes.js(POST /api/requests, GET /api/requests, GET /api/requests/:id).
- Frontend (client/src 9파일 생성): types.ts, labels.ts, api.ts, styles.css, main.tsx, App.tsx, components/RequestList.tsx, RequestForm.tsx, RequestDetail.tsx. React 18 + TypeScript(strict) + Vite 6, 라우터 라이브러리 없이 해시 기반 화면 전환. WF-01 목록(AND 필터, total=필터 후 개수, 로딩·빈 목록·오류·재시도 구분, 모바일 카드 목록), WF-02 등록(f-title/f-description/f-requester/f-assignee, priority radio 3개, 중복 제출 방지, 오류 시 입력 유지, 201 성공 시 상세 이동), WF-03 읽기 전용 상세('요청 상세' heading, 로딩·404·네트워크 오류 구분, 목록으로 버튼).
- 승인된 구현 기준 A·B·C를 유지했고 고정 Baseline은 변경하지 않았다. server/, client/만 생성·수정했다.
- 테스트 실행은 이번 요청에서 금지되어 있어 Hermes Agent가 직접 실행한 검증은 없다. TypeScript 정적 검사(npx tsc --noEmit)는 Hermes Agent가 직접 실행해 exit 0 PASS.

## 승인된 구현 기준 (사용자 확정 — 고정 Baseline 변경 승인이 아님)

- A. GET /api/requests의 total은 상태·우선순위 필터 적용 후 반환되는 항목 수(items.length)로 계산한다.
- B. 키보드 포커스는 기존 primary 토큰과 브라우저 기본 포커스 동작을 활용하며 디자인 토큰 파일은 변경하지 않는다.
- C. 잘못된 UUID 형식의 요청 ID는 HTTP 400 VALIDATION_ERROR, 형식 유효·미존재 ID는 HTTP 404 NOT_FOUND로 처리한다.

수정 금지 Baseline(docs/, specs/, contracts/, schemas/, design/, traceability/, tests/, e2e/, scripts/)은 읽기 전용이며, 이 확정은 구현 기준 확정일 뿐 Baseline 파일 변경 승인이 아니다.

## 검증 결과

- 제1·2교시: AGENTS.md(178행), docs/project-overview.md(26행) 실제 파일 읽기. 개발 환경 구축 및 브라우저 Smoke Test는 완료 보고된 항목이다.
- 제3교시: 고정 자산 7개 실제 파일 읽기 및 문서 간 대조 분석 수행. 파일 수정·생성·삭제 없음.
- 제4교시: AGENTS.md와 두 계획 파일 등 근거 문서 13개 실제 읽기. plans/ 두 파일만 생성(verification-plan.md 내 오탈자 1건 수정). 그 외 파일 수정 없음.
- JSON 계약(OpenAPI·JSON Schema·디자인 토큰) 구조 검사 PASS — 사용자 제공 PowerShell 실행 결과에 근거한 판정이며, Hermes Agent가 직접 실행·검증한 결과가 아니다.
- Lesson 04 Planning Check: PASS, 종료 코드 0 — 사용자 제공 PowerShell 실행 결과에 근거한 기록이며, Hermes Agent가 직접 실행한 것이 아니다.
- 제5교시 검증 결과(사용자가 제공한 PowerShell 결과를 근거로 한 것임을 명시 — Hermes Agent가 직접 실행한 결과가 아님):
  - Backend API 11/11 PASS, 종료 코드 0.
  - TypeScript 정적 검사 PASS, Vite 프로덕션 빌드 PASS.
  - Backend·Frontend·API 프록시 HTTP 200.
  - Chromium 목록·등록 화면 PASS.
  - Chromium 등록 → POST 201 → 상세 → 목록 복귀 PASS, 종료 코드 0.
  - 고정 tests/api.test.js 전체는 실행하지 않았다. PASS로 기록하지 않는다.
- 제5교시에서 Hermes Agent가 직접 실행한 검증: npx tsc --noEmit → exit 0 PASS (client/src strict).
- e2e/는 미배치 상태이므로 Playwright E2E는 미실행이다. 미검증 항목은 완료로 보고하지 않는다.

## 미해결 문제

- 해석 필요 3건(total의 의미, 포커스 방식, 잘못된 UUID 처리)은 사용자의 구현 기준 A·B·C 승인으로 해소됨.
- 참고(승인 필요, 유지): 목록 정렬 규칙이 API 계약(openapi.json)에는 미표기이고 requirements.md·specification.md에만 존재 — 계약 보완 여부는 변경 통제 대상.
- 고정 테스트 배치 후 기준 A(total=items.length)·C(400/404 매핑)의 기대값이 실제 테스트와 일치하는지 교차 확인 필요. 충돌 시 임의 수정하지 않고 보고한다.

## 다음 작업

- 제6교시: REQ-004 상태 변경 PATCH /api/requests/:id/status, REQ-005 담당자·우선순위 수정 PATCH /api/requests/:id, 상세 화면 수정·상태 변경 UI 구현.
- 고정 API 전체 테스트(vitest run tests), 서버 재시작 영속성 테스트, 후속 E2E 검증을 실행한다.
- 로그인·삭제·검색 등 제외 범위는 구현 대상 아님.
- 검증은 AGENTS.md §10 순서와 §6 반복 한도(최대 3회)를 따른다. 고정 테스트 원본은 수정하지 않는다.
