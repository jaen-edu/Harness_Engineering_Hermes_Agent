$ErrorActionPreference = 'Stop'

$base = 'C:\AI-Native'
$infra = Join-Path $base 'hermes-training-v2'
$app = Join-Path $base 'work-request-manager-v2'

Write-Host "`n=== Day 2 Recovery Verification ===" -ForegroundColor Cyan

$required = @(
    "$infra\compose.yaml",
    "$infra\.env",
    "$infra\playwright-service\server.js",
    "$infra\playwright-service\start.sh",
    "$app\AGENTS.md",
    "$app\package.json",
    "$app\package-lock.json",
    "$app\server\app.js",
    "$app\server\index.js",
    "$app\client\src\main.tsx",
    "$app\tests\api.test.js",
    "$app\design\tokens.json",
    "$app\progress.md",
    "$app\handoff.md"
)

foreach ($file in $required) {
    if (-not (Test-Path -LiteralPath $file -PathType Leaf)) {
        throw "Missing required file: $file"
    }
}

Write-Host '[PASS] Required files' -ForegroundColor Green

Set-Location $infra

docker compose config --quiet
if ($LASTEXITCODE -ne 0) {
    throw 'Docker Compose configuration failed'
}
Write-Host '[PASS] Compose configuration' -ForegroundColor Green

docker compose up -d
if ($LASTEXITCODE -ne 0) {
    throw 'Docker Compose startup failed'
}

docker compose ps

$services = @(docker compose ps --status running --services)
if ($LASTEXITCODE -ne 0) {
    throw 'Docker service status check failed'
}

foreach ($name in @('hermes','playwright')) {
    if ($name -notin $services) {
        throw "Service not running: $name"
    }
}

Write-Host '[PASS] Docker services' -ForegroundColor Green

docker compose exec -T hermes sh -lc '
    set -eu
    cd /workspace

    if [ ! -d node_modules ]; then
        npm ci --no-audit --no-fund
    fi

    node --input-type=module -e "
        import { createApp } from \"./server/app.js\";
        if (typeof createApp !== \"function\") {
            throw Error(\"createApp missing\");
        }
    "
    echo "[PASS] Backend ESM"

    ./node_modules/.bin/tsc --noEmit
    echo "[PASS] TypeScript"

    npm run build
    test -f dist/index.html
    echo "[PASS] Frontend Build"
'

if ($LASTEXITCODE -ne 0) {
    throw 'Application verification failed'
}

# HTTP and Chromium Verification

Write-Host "`n=== HTTP Verification ===" -ForegroundColor Cyan

$httpFile = Join-Path $PSScriptRoot 'verify-http.sh'

docker compose cp $httpFile hermes:/tmp/day2-verify-http.sh
if ($LASTEXITCODE -ne 0) {
    throw 'HTTP script transfer failed'
}

docker compose exec -T hermes sh /tmp/day2-verify-http.sh

if ($LASTEXITCODE -ne 0) {
    throw 'HTTP verification failed'
}

Write-Host "`n=== Chromium Verification ===" -ForegroundColor Cyan

Get-Content -Raw -Encoding UTF8 -LiteralPath (Join-Path $PSScriptRoot 'verify-browser.cjs') |
    docker compose exec -T -w /opt/playwright-runtime playwright node -

if ($LASTEXITCODE -ne 0) {
    throw 'Chromium verification failed'
}
Write-Host "`n[PASS] Day 2 Recovery Verification" -ForegroundColor Green