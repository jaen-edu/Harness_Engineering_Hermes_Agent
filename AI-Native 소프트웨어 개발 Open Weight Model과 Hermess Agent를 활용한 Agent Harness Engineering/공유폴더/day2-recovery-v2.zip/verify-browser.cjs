const { chromium } = require('playwright');

(async () => {
    const browser = await chromium.launch({ headless: true });

    try {
        const page = await browser.newPage({
            viewport: { width: 1365, height: 900 },
            locale: 'ko-KR'
        });

        const errors = [];
        page.on('pageerror', error => errors.push(error.message));

        const response = await page.goto('http://hermes:5173/', {
            waitUntil: 'networkidle',
            timeout: 30000
        });

        if (!response || response.status() !== 200) {
            throw new Error('Frontend HTTP FAIL');
        }

        await page.getByRole('heading', {
            name: 'AI Work Request Manager 2.0'
        }).waitFor();

        console.log('[PASS] List Screen');

        const api = await page.evaluate(async () => {
            const response = await fetch('/api/requests');
            return {
                status: response.status,
                body: await response.json()
            };
        });

        if (api.status !== 200 || !Array.isArray(api.body.items)) {
            throw new Error('Browser API FAIL');
        }

        console.log('[PASS] Browser API');

        await page.getByRole('button', {
            name: /요청 등록/
        }).click();

        await page.getByRole('heading', {
            name: '새 업무 요청'
        }).waitFor();

        for (const id of [
            'f-title',
            'f-description',
            'f-requester',
            'f-assignee'
        ]) {
            if (await page.locator('#' + id).count() !== 1) {
                throw new Error('Missing field: ' + id);
            }
        }

        if (await page.locator('input[name="priority"]').count() !== 3) {
            throw new Error('Priority fields FAIL');
        }

        if (errors.length > 0) {
            throw new Error(errors.join('; '));
        }

        console.log('[PASS] Registration Screen');
        console.log('[PASS] Browser JavaScript Errors: NONE');
        console.log('[PASS] Chromium UI Verification');

    } finally {
        await browser.close();
    }

})().catch(error => {
    console.error('[FAIL] Chromium UI Verification', error);
    process.exitCode = 1;
});