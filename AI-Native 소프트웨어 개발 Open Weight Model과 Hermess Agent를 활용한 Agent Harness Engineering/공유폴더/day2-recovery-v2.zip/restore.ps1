param(
    [string]$BasePath = 'C:\AI-Native',
    [switch]$SkipDocker,
    [switch]$WhatIf
)

$ErrorActionPreference = 'Stop'
$packageRoot = $PSScriptRoot
$projects = @(
    'hermes-training-v2',
    'work-request-manager-v2'
)

$required = @(
    'hermes-training-v2\compose.yaml',
    'hermes-training-v2\playwright-service\server.js',
    'hermes-training-v2\playwright-service\start.sh',
    'work-request-manager-v2\AGENTS.md',
    'work-request-manager-v2\package.json',
    'work-request-manager-v2\package-lock.json',
    'work-request-manager-v2\server\app.js',
    'work-request-manager-v2\server\index.js',
    'work-request-manager-v2\client\src\main.tsx',
    'work-request-manager-v2\tests\api.test.js',
    'work-request-manager-v2\design\tokens.json',
    'work-request-manager-v2\progress.md',
    'work-request-manager-v2\handoff.md'
)

Write-Host "`n=== Day 2 Recovery ===" -ForegroundColor Cyan
Write-Host "Target: $BasePath"

# Validate package and target
foreach ($name in $required) {
    if (-not (Test-Path -LiteralPath (Join-Path $packageRoot $name) -PathType Leaf)) {
        throw "Package file missing: $name"
    }
}

foreach ($project in $projects) {
    $source = Join-Path $packageRoot $project
    $target = Join-Path $BasePath $project
    if (-not (Test-Path -LiteralPath $source -PathType Container)) {
        throw "Package directory missing: $project"
    }
    if (-not (Test-Path -LiteralPath $target -PathType Container)) {
        throw "Existing project missing: $target"
    }
}

$envFile = Join-Path $BasePath 'hermes-training-v2\.env'
if (-not (Test-Path -LiteralPath $envFile -PathType Leaf)) {
    throw 'Existing .env missing'
}

# Reject forbidden package contents
$forbidden = @(
    '.env', 'node_modules', 'dist',
    'data', 'test-results', '.git'
)
foreach ($project in $projects) {
    $source = Join-Path $packageRoot $project
    Get-ChildItem -LiteralPath $source -Force -Recurse |
        ForEach-Object {
            if ($_.Name -in $forbidden -or
                $_.Name -like '*.bak*' -or
                $_.Name -like '*.pem' -or
                $_.Name -like '*.key') {
                throw "Forbidden package item: $($_.FullName)"
            }
        }
}

Write-Host '[PASS] Package precheck'

if ($WhatIf) {
    Write-Host '[PASS] Dry run: no changes made' -ForegroundColor Green
    return
}

$stamp = Get-Date -Format 'yyyyMMdd-HHmmss-fffffff'
$backupRoot = Join-Path $BasePath "day2-recovery-backup-$stamp"
$prepareRoot = Join-Path $BasePath "day2-recovery-prepare-$stamp"

if (Test-Path -LiteralPath $backupRoot) {
    throw 'Backup path collision'
}
if (Test-Path -LiteralPath $prepareRoot) {
    throw 'Prepare path collision'
}

$states = @{}
foreach ($project in $projects) {
    $states[$project] = 'ORIGINAL'
}

New-Item -ItemType Directory -Path $prepareRoot | Out-Null

# Prepare and verify file hashes
try {
    foreach ($project in $projects) {
        $source = Join-Path $packageRoot $project
        $prepared = Join-Path $prepareRoot $project

        Copy-Item -LiteralPath $source -Destination $prepared -Recurse

        $sourceFiles = @(Get-ChildItem -LiteralPath $source -File -Recurse)
        $preparedFiles = @(Get-ChildItem -LiteralPath $prepared -File -Recurse)

        if ($sourceFiles.Count -ne $preparedFiles.Count) {
            throw "File count mismatch: $project"
        }

        foreach ($file in $sourceFiles) {
            $relative = $file.FullName.Substring($source.Length + 1)
            $copy = Join-Path $prepared $relative

            if (-not (Test-Path -LiteralPath $copy -PathType Leaf)) {
                throw "Missing copied file: $relative"
            }

            $hash1 = (Get-FileHash -LiteralPath $file.FullName -Algorithm SHA256).Hash
            $hash2 = (Get-FileHash -LiteralPath $copy -Algorithm SHA256).Hash

            if ($hash1 -ne $hash2) {
                throw "Hash mismatch: $relative"
            }
        }

        Write-Host "[PASS] SHA256: $project"
    }

    Copy-Item -LiteralPath $envFile `
        -Destination (Join-Path $prepareRoot 'hermes-training-v2\.env')

    $dataSource = Join-Path $BasePath 'work-request-manager-v2\data'
    if (Test-Path -LiteralPath $dataSource -PathType Container) {
        Copy-Item -LiteralPath $dataSource `
            -Destination (Join-Path $prepareRoot 'work-request-manager-v2\data') `
            -Recurse
    }

    Write-Host '[PASS] Recovery source prepared'
}
catch {
    Write-Host '[FAIL] Preparation failed; original projects unchanged' -ForegroundColor Red
    throw
}

# Stop services only after preparation succeeds
if (-not $SkipDocker) {
    Push-Location (Join-Path $BasePath 'hermes-training-v2')
    try {
        docker compose stop
        if ($LASTEXITCODE -ne 0) {
            throw 'Docker stop failed'
        }
    }
    finally {
        Pop-Location
    }
}

New-Item -ItemType Directory -Path $backupRoot | Out-Null

try {
    foreach ($project in $projects) {
        $target = Join-Path $BasePath $project
        $backup = Join-Path $backupRoot $project
        $prepared = Join-Path $prepareRoot $project

        Move-Item -LiteralPath $target -Destination $backup
        $states[$project] = 'BACKED_UP'

        Move-Item -LiteralPath $prepared -Destination $target
        $states[$project] = 'REPLACED'

        Write-Host "[PASS] Replaced: $project"
    }

    if (-not (Test-Path -LiteralPath $envFile -PathType Leaf)) {
        throw 'Authentication file missing after replacement'
    }

    Write-Host '[PASS] Source recovery complete' -ForegroundColor Green
}
catch {
    $originalError = $_
    Write-Host '[FAIL] Recovery failed; rollback starting' -ForegroundColor Red

    $rollbackErrors = @()

    foreach ($project in @($projects[1], $projects[0])) {
        $target = Join-Path $BasePath $project
        $backup = Join-Path $backupRoot $project

        try {
            if ($states[$project] -eq 'REPLACED' -and
                (Test-Path -LiteralPath $target)) {
                $failed = Join-Path $backupRoot "$project.failed"
                Move-Item -LiteralPath $target -Destination $failed
            }

            if ($states[$project] -in @('BACKED_UP','REPLACED') -and
                (Test-Path -LiteralPath $backup)) {
                if (Test-Path -LiteralPath $target) {
                    throw "Rollback target occupied: $target"
                }
                Move-Item -LiteralPath $backup -Destination $target
                Write-Host "[PASS] Rolled back: $project"
            }
        }
        catch {
            $rollbackErrors += "$project : $($_.Exception.Message)"
        }
    }

    if ($rollbackErrors.Count -gt 0) {
        Write-Host '[FAIL] Manual recovery required' -ForegroundColor Red
        $rollbackErrors | ForEach-Object { Write-Host $_ }
        Write-Host "Backup: $backupRoot"
    }

    throw $originalError
}

Write-Host "Backup: $backupRoot"
Write-Host "Prepared files: $prepareRoot"
Write-Host '[PASS] Day 2 Recovery'
Write-Host 'Next: run verify.ps1'