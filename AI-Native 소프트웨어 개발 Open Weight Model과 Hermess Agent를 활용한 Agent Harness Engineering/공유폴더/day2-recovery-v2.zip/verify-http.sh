#!/bin/sh
set -eu

cd /workspace

if ! curl --noproxy "*" -fsS --max-time 3 \
    http://127.0.0.1:3001/api/requests >/dev/null 2>&1; then
    nohup node server/index.js \
        >/tmp/day2-backend.log 2>&1 </dev/null &
fi

if ! curl --noproxy "*" -fsS --max-time 5 \
    -H "Host: hermes:5173" \
    http://127.0.0.1:5173/ -o /dev/null 2>/dev/null; then

    export __VITE_ADDITIONAL_SERVER_ALLOWED_HOSTS=hermes

    nohup ./node_modules/.bin/vite \
        --host 0.0.0.0 --port 5173 --strictPort \
        >/tmp/day2-frontend.log 2>&1 </dev/null &
fi

backend_ok=0
frontend_ok=0

i=0
while [ "$i" -lt 20 ]; do
    if curl --noproxy "*" -fsS --max-time 3 \
        http://127.0.0.1:3001/api/requests >/dev/null 2>&1; then
        backend_ok=1
        break
    fi
    i=$((i + 1))
    sleep 1
done

i=0
while [ "$i" -lt 20 ]; do
    if curl --noproxy "*" -fsS --max-time 5 \
        -H "Host: hermes:5173" \
        http://127.0.0.1:5173/ -o /dev/null 2>/dev/null; then
        frontend_ok=1
        break
    fi
    i=$((i + 1))
    sleep 1
done

if [ "$backend_ok" -ne 1 ]; then
    tail -n 30 /tmp/day2-backend.log 2>/dev/null || true
    echo "[FAIL] Backend HTTP"
    exit 1
fi
echo "[PASS] Backend HTTP"

if [ "$frontend_ok" -ne 1 ]; then
    tail -n 30 /tmp/day2-frontend.log 2>/dev/null || true
    echo "[FAIL] Frontend HTTP"
    exit 1
fi
echo "[PASS] Frontend HTTP"

curl --noproxy "*" -fsS --max-time 10 \
    -H "Host: hermes:5173" \
    http://127.0.0.1:5173/api/requests >/dev/null

echo "[PASS] Vite API Proxy"