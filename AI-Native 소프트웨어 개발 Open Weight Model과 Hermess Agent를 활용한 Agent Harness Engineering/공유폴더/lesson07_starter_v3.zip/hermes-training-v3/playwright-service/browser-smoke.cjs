const { chromium } = require('playwright');
(async () => {
  const browser = await chromium.launch({ headless: true, args: ['--no-sandbox'] });
  try {
    const page = await browser.newPage();
    await page.goto('data:text/html,<title>Harness Ready</title><h1>Browser OK</h1>');
    if ((await page.title()) !== 'Harness Ready') throw new Error('Unexpected page title');
    console.log('BROWSER_CLOSE_COMPLETE_PENDING');
  } finally {
    await browser.close();
    console.log('BROWSER_CLOSE_COMPLETE');
  }
  console.log('TEST_COMPLETE');
})().catch(e => { console.error(e); process.exitCode = 1; });
