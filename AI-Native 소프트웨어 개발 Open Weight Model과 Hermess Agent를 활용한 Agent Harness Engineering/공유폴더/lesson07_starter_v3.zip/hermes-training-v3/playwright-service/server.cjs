'use strict';
const http = require('node:http');
const path = require('node:path');
const fs = require('node:fs');
const { spawn } = require('node:child_process');
const TARGET = {
  'browser-smoke': '/runner/browser-smoke.cjs',
  'requests': '/workspace/tests/e2e/requests.spec.cjs',
  'dashboard': '/workspace/tests/e2e/dashboard.spec.cjs'
};
function respond(res, code, data) {
  res.writeHead(code, {'content-type':'application/json; charset=utf-8'});
  res.end(JSON.stringify(data));
}
async function runTest(test) {
  const filename = TARGET[test];
  if (!filename) return { status:'FAIL', exitCode:null, timedOut:false, error:'UNKNOWN_TEST' };
  if (!fs.existsSync(filename)) return { status:'FAIL', exitCode:null, timedOut:false, error:'TEST_NOT_IMPLEMENTED' };
  return await new Promise(resolve => {
    let stdout = '', stderr = '', timedOut = false, done = false;
    const child = spawn(process.execPath,[filename],{cwd:'/workspace', env:{...process.env,NODE_PATH:'/opt/playwright-runtime/node_modules'}, stdio:['ignore','pipe','pipe']});
    child.stdout.on('data', b => {stdout += b.toString().slice(0,100000);});
    child.stderr.on('data', b => {stderr += b.toString().slice(0,100000);});
    const timeout = setTimeout(() => {timedOut = true;child.kill('SIGKILL');},90000);
    child.on('error', e => {stderr += String(e);});
    child.on('close', code => {
      if(done)return;done=true;clearTimeout(timeout);
      resolve({test, status:code===0&&!timedOut?'PASS':'FAIL', exitCode:code, timedOut, stdout:stdout.slice(-100000), stderr:stderr.slice(-100000)});
    });
  });
}
let busy = false;
http.createServer(async(req,res) => {
  if(req.method==='GET' && req.url==='/health') return respond(res,200,{status:'OK',service:'playwright',tests:Object.keys(TARGET)});
  if(req.method==='POST' && req.url==='/run') {
    if(busy)return respond(res,409,{status:'FAIL',error:'RUNNER_BUSY'});
    let body = '';
    for await (const chunk of req) {
      body += chunk.toString();
      if(body.length > 4096)return respond(res,413,{status:'FAIL',error:'BODY_TOO_LARGE'});
    }
    let input;try {input=JSON.parse(body);}catch {return respond(res,400,{status:'FAIL',error:'INVALID_JSON'});}
    if(!input || typeof input.test!=='string' || !Object.hasOwn(TARGET,input.test))return respond(res,400,{status:'FAIL',error:'UNKNOWN_TEST'});
    busy=true;
    try{return respond(res,200,await runTest(input.test));}finally{busy=false;}
  }
  respond(res,404,{status:'FAIL',error:'NOT_FOUND'});
}).listen(3000,'0.0.0.0',()=>console.log('PLAYWRIGHT_SERVICE_READY 3000'));
