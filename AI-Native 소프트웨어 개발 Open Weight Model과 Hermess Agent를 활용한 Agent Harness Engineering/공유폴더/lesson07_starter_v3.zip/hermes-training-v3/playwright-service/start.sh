#!/bin/sh
set -eu
cp /runner/package.json /opt/playwright-runtime/package.json
cd /opt/playwright-runtime
npm install --no-audit --no-fund --ignore-scripts
node --check /runner/server.cjs
node --check /runner/browser-smoke.cjs
exec node /runner/server.cjs
