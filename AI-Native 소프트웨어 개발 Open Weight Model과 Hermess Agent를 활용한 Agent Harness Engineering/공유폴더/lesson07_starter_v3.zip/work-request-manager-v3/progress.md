# 진행 기록

- 제7교시: 환경 검증은 실행 후 AC07-01~06의 결과를 기록합니다. Starter 배포본 자체는 실행 결과를 주장하지 않습니다.
- 제8교시: `NOT_IMPLEMENTED`.
- 제9교시: `NOT_IMPLEMENTED`.
