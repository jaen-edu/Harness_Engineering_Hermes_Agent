# AI Work Request Manager v3 — 프로젝트 개요

Hermes Agent를 활용하여 두 개의 탭을 가진 반응형 웹 애플리케이션을 단계적으로 개발합니다.

- **제7교시:** 독립 Docker/Hermes/Playwright 환경 및 명세 준비. 애플리케이션 구현 금지.
- **제8교시:** Requests 탭의 등록·목록·수정·상태 변경, 자동 테스트와 수정·재검증 반복.
- **제9교시:** Dashboard 탭의 지표·필터, 자동 테스트와 수정·재검증 반복.

이후 구현을 위한 참고 기술 구성(제7교시 산출물 아님): Node.js 백엔드, React + TypeScript + Vite 프런트엔드. 애플리케이션 데이터는 로컬 샘플을 사용하며 외부 유료 데이터 API는 필요하지 않습니다. Hermes 모델 연결은 교육생이 설정한 제공자를 사용합니다.

## 독립 환경
- Compose 프로젝트: `hermes-training-v3`
- 실행 환경: `C:\AI-Native\hermes-training-v3`
- 에이전트 작업공간: `C:\AI-Native\work-request-manager-v3`
- Hermes Dashboard: `http://127.0.0.1:9130`
- 향후 웹 미리보기: `http://127.0.0.1:5174` (제7교시에는 애플리케이션 없음)
- Playwright 내부 API: `http://playwright:3000` (Docker 내부 DNS 전용)

v2 또는 Reference Project 폴더를 마운트하지 않습니다.
