# AI Work Request Manager v3 — 에이전트 작업 지침

## 작업 범위와 격리 원칙
- 이 작업공간은 독립적인 **v3**입니다. 기존 v2 및 Reference Project를 읽거나 쓰거나 수정하지 않습니다. 해당 프로젝트로 향하는 심볼릭 링크도 만들지 않습니다.
- 모든 변경은 승인된 v3 작업공간으로 한정합니다.

## 프로젝트 디렉터리 규칙(제8~9교시 공통)
- 프런트엔드 프로젝트 루트는 **`/workspace/client/`** (`client/`)로 고정합니다. React + TypeScript + Vite의 `package.json`, `index.html`, `vite.config.*` 등 프런트엔드 설정은 `client/` 하위에 배치합니다.
- 프런트엔드 소스는 **`/workspace/client/src/`** (`client/src/`)에 배치합니다. **`/workspace/src/` 등 프로젝트 루트의 별도 `src/` 디렉터리는 계획하거나 생성하지 않습니다.**
- 백엔드 API 및 영속 저장소는 **`/workspace/server/`** (`server/`)에 배치합니다.
- 테스트 디렉터리는 **`/workspace/tests/unit/`**, **`/workspace/tests/integration/`**, **`/workspace/tests/e2e/`**로 고정합니다.
- 검증 증거는 **`/workspace/evidence/`** 또는 **`/workspace/progress.md`**에 기록합니다.
- 구현 계획 문서는 **`/workspace/plans/lesson08-requests-plan.md`**, **`/workspace/plans/lesson09-dashboard-plan.md`** 두 파일로 저장합니다. 제7교시에는 이 두 Markdown 계획 문서만 새로 작성할 수 있습니다.
- 제7교시에는 위 구조를 **계획에만 반영**하고, 실제 애플리케이션 소스·설정·테스트 파일을 생성하지 않습니다.

## 제7교시 — 환경 구성 및 계획 수립만 수행
- `docs/project-overview.md`, `specs/requests.md`, `specs/dashboard.md`, `specs/acceptance-criteria.md`, `docs/ui-guidelines.md`를 읽습니다.
- v3 환경을 점검한 후 제8교시와 제9교시 계획을 **두 개의 파일로 실제 저장**합니다. Chat 응답만으로 계획 수립을 완료했다고 표시하지 않습니다.
- `plans/`가 없으면 생성할 수 있으며, `plans/lesson08-requests-plan.md`와 `plans/lesson09-dashboard-plan.md`만 신규 작성합니다. 이미 존재한다면 덮어쓰기 전에 현재 내용을 확인합니다.
- 두 계획에는 각 교시의 예정 파일 경로(`client/`, `client/src/`, `server/`, `tests/`), 구현 순서, AC08/AC09 대응, 테스트 종류, 실패·수정·재검증 정책, `NOT_IMPLEMENTED` 상태를 포함합니다.
- **제7교시에는 UI, 백엔드 API, `package.json`, Vite 설정, 애플리케이션 테스트 코드, 애플리케이션 소스 파일을 구현하지 않습니다.**
- 테스트를 통과시키기 위해 인수 기준을 약화하거나 기준 명세를 임의 수정하지 않습니다.
- 실제 실행 로그로 확인하지 않은 테스트를 PASS로 표시하지 않습니다. 아직 없는 테스트는 `NOT_IMPLEMENTED`로 기록합니다.

## 제8교시 — Requests 탭 구현
- 먼저 `plans/lesson08-requests-plan.md`를 읽고 반응형 카드 형태의 Requests 탭을 구현합니다.
- 단위·통합·E2E 테스트를 작성하고 고정된 인수 기준에 따라 검증합니다.
- 실패 시 원인을 분석하고 코드를 수정한 후 재검증합니다. 해결되지 않으면 차단 요인을 보고합니다.

## 제9교시 — Dashboard 탭 구현
- 먼저 `plans/lesson09-dashboard-plan.md`를 읽고 동일한 디자인 토큰을 사용하여 Dashboard 탭을 구현합니다.
- 테스트를 작성·실행하고 통과하거나 차단 요인이 확인될 때까지 제한된 범위에서 수정·재검증합니다.

## Playwright Runner 연동 계약
- 컨테이너 내부 주소: `http://playwright:3000`
- `GET /health`: 서비스 상태 확인
- `POST /run`: `{"test":"browser-smoke"}` 요청을 받으며, 제8~9교시에는 `requests`, `dashboard` 테스트를 사용합니다.
- 제8교시 E2E 파일: `tests/e2e/requests.spec.cjs`
- 제9교시 E2E 파일: `tests/e2e/dashboard.spec.cjs`
- 테스트 스크립트는 Node.js 모듈 검색 경로(`NODE_PATH`)로 `playwright`를 불러오며 실패 시 0이 아닌 종료 코드를 반환해야 합니다.
- Playwright는 테스트 실행만 담당합니다. 애플리케이션 코드 수정 및 재시험 반복은 Hermes가 담당합니다.

## 검증 증거
- 각 코드 변경 반복마다 실행 명령, PASS/FAIL 출력, 변경 파일, 남은 문제를 `evidence/` 또는 `progress.md`에 기록합니다.
- 테스트 결과를 임의로 만들지 않습니다.
