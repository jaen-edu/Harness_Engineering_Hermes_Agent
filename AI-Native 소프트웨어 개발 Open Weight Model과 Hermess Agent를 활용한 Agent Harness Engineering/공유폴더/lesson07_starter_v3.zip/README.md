# 제7교시 Starter — AI Work Request Manager v3

이 패키지는 **신규 실습용**입니다. 기존 v2 및 Reference Project를 수정하지 않습니다.

- `hermes-training-v3/` : 통합 `compose.yaml`, Hermes, Playwright Runner
- `work-request-manager-v3/` : `AGENTS.md`, 한국어 명세, 초기 데이터, 비어 있는 구현·테스트 폴더

**`compose.yaml`은 ZIP에 포함되어 있습니다. 별도 YAML 파일을 내려받거나 새로 생성할 필요가 없습니다.**

Windows 11에서는 별도 제공하는 `lesson07_v3_environment_and_planning.md`의 신규 설치 절차를 따릅니다. 이미 v3가 있다면 신규 설치/압축 해제를 다시 하지 말고 '기존 v3 재검증' 절차를 사용하세요.

제7교시는 환경 구성·요구사항 확인·계획 수립만 진행합니다. 애플리케이션 구현은 제8교시부터 시작합니다.

제7교시 마지막 단계에서 Hermes Agent가 `work-request-manager-v3/plans/` 아래에 제8·9교시 계획 Markdown 파일 2개를 생성합니다. Starter에는 빈 plans 폴더만 들어 있습니다.
