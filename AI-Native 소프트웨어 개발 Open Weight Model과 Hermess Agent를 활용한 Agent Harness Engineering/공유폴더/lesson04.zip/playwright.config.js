import { defineConfig, devices } from '@playwright/test';
export default defineConfig({testDir:'./e2e',timeout:30000,retries:0,use:{baseURL:process.env.WEB_BASE_URL||'http://127.0.0.1:5173',...devices['Desktop Chrome']}});
